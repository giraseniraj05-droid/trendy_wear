# Run Trendy Wear in Docker

This is an ASP.NET Web Forms application targeting the .NET Framework. It must run in a **Windows container** with IIS. A Linux container cannot run this application unchanged.

## Requirements

- Windows 10/11 Pro, Enterprise, or Education, or a Windows Server host that supports Windows containers.
- Docker Desktop configured for Windows containers.
- A SQL Server instance reachable from the container over TCP. The current LocalDB connection cannot be used inside the container.
- A locally built `bin/TYBCA_52_PROJECT.dll` and the app's other compiled dependencies.
- A local `secrets.config` with SMTP settings. Keep it out of Git.

## Prepare SQL Server

Attach or restore the project database into a SQL Server instance accessible to the container. Enable TCP/IP and SQL authentication, create a least-privilege application login, and allow that login to use the `TrendyWear` database. Keep the database on the SQL Server host or another persistent SQL Server; do not store the production database in the web container.

## Configure and start

1. Build `TYBCA_52_PROJECT.vbproj` in Visual Studio or with Visual Studio/MSBuild. Docker copies the compiled app from `bin`.
2. Copy `.env.example` to `.env` and replace the sample SQL connection string with the connection to your SQL Server. For SQL Server on the Docker host, `host.docker.internal,1433` is the usual host address. Put the real SQL password only in `.env`.
3. Copy `secrets.config.example` to `secrets.config` and enter the SMTP credentials there. This file is mounted into the container at run time and is excluded from the Docker build context and Git.
4. Switch Docker Desktop to **Windows containers**.
5. From this folder, run:

   ```powershell
   docker compose up --build -d
   ```

6. Open `http://localhost:8080`.

To inspect startup output, run `docker compose logs -f`. To stop the web container, run `docker compose down`. The database remains on SQL Server.

## Keep private files out of Git

The repository ignores `.env`, `secrets.config`, Visual Studio build folders, and local `.mdf`/`.ldf` files. Commit `secrets.config.example` and database schema/seed scripts, not real credentials or the working database.
