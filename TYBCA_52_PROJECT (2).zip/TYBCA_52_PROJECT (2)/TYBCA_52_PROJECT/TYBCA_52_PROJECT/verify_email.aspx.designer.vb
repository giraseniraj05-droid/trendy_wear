Option Strict On
Option Explicit On

Partial Public Class verify_email
    Protected WithEvents lblMessage As Global.System.Web.UI.WebControls.Label
    Protected WithEvents lblCooldown As Global.System.Web.UI.WebControls.Label
    Protected WithEvents txtCode As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents btnVerify As Global.System.Web.UI.WebControls.Button
    Protected WithEvents btnResend As Global.System.Web.UI.WebControls.Button
End Class
