# Trendy Wear - Technical Architecture & Interview Key Points

Use these 12 technical talking points during company interviews to explain the design, security, and architectural choices of the Trendy Wear project confidently:

---

### 1. PBKDF2 Password Security (`Rfc2898DeriveBytes`)
- **Choice**: Utilized `Rfc2898DeriveBytes` with a 128-bit cryptographically secure per-user salt and 100,000 iterations to generate 256-bit password hashes (`Helpers/Security.vb`).
- **Rationale**: Mitigates rainbow table attacks and GPU-based brute forcing compared to legacy unsalted hashes.

---

### 2. Zero-Downtime Password Migration
- **Choice**: Implemented an automated migration path during the login sequence.
- **Rationale**: When legacy users login using plain-text passwords, the system verifies the credential, generates a new PBKDF2 salt + hash, updates the database, and clears the plain-text column automatically without forcing user password resets.

---

### 3. SqlTransaction for Order Execution
- **Choice**: Wrapped order creation, order detail line item inserts, stock deductions, and total updates inside a single `SqlTransaction`.
- **Rationale**: Guarantees ACID properties. If any item fails stock validation or insert, the entire order rolls back to prevent orphaned records or inventory inaccuracies.

---

### 4. Defense-in-Depth SQL Parameterization
- **Choice**: Centralized all ADO.NET interactions into `Helpers/Db.vb` using strongly-typed `SqlParameter` objects.
- **Rationale**: Prevents SQL Injection attacks across search, login, registration, and order forms.

---

### 5. Role-Based Access Control (RBAC) & Folder Security
- **Choice**: Implemented ASP.NET Forms Authentication combined with Web.config `<location path="Customer">` and `<location path="Admin">` authorization elements, supplemented by Master Page role verification.
- **Rationale**: Enforces strict privilege boundaries so non-administrative users cannot access admin tools or orders.

---

### 6. Soft Delete Pattern (`IsActive`)
- **Choice**: Configured soft deletion (`IsActive = 0`) on products and user accounts instead of executing SQL `DELETE`.
- **Rationale**: Prevents foreign key constraint violations on historic order records while maintaining accurate financial reports.

---

### 7. Real-Time Dynamic Theme System
- **Choice**: Built a CSS Custom Properties (`:root` variables) design system driven by `data-theme` HTML attributes.
- **Rationale**: Enables client-side instant theme switching (Light, Dark, Ocean, Forest, Rose) without page refreshes, using cookies to eliminate Flash of Unstyled Content (FOUC).

---

### 8. Token-Based Cryptographic Password Reset
- **Choice**: Engineered password recovery using random URL-safe tokens hashed and stored in `PasswordResets` with 30-minute expiration.
- **Rationale**: Prevents plain-text password exposure on screen and eliminates timing/enumeration attacks by standardizing response messages.

---

### 9. Layered Service Architecture
- **Choice**: Separated entity data models (`Models/`) and business operations (`Services/CartService.vb`) from presentation logic.
- **Rationale**: Ensures ASP.NET Web Forms code-behind files remain slim, maintainable, and readable.

---

### 10. INR (₹) Financial Localization
- **Choice**: Standardized all monetary figures to Indian Rupees using `en-IN` culture formatting (`ToString("N2")`).
- **Rationale**: Ensures accurate financial representation suited for regional e-commerce markets.

---

### 11. Persistent Multi-Device Cart Synchronization
- **Choice**: Synchronizes guest session carts into the persistent `Cart` table upon user login.
- **Rationale**: Guarantees seamless shopping continuity across multiple devices.

---

### 12. Account Lockout & Throttling Defense
- **Choice**: Tracked `FailedAttempts` and `LockoutEnd` timestamps in the `register` table to enforce 15-minute lockouts after 5 consecutive failed login attempts.
- **Rationale**: Protects customer accounts against automated credential stuffing and brute-force dictionary attacks.
