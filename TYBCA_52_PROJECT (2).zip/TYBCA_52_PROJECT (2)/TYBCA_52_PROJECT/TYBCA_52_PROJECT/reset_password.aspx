<%@ Page Title="Reset Password" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" CodeBehind="reset_password.aspx.vb" Inherits="TYBCA_52_PROJECT.reset_password" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="auth-container">
        <div class="fk-card auth-card auth-compact">
            <div class="auth-banner-col auth-compact-banner"><h2 class="auth-banner-title">Secure password reset</h2><p class="auth-banner-sub">Verify your email code to choose a new password.</p></div>
            <div class="fk-card-header text-center">
                <h2 class="fk-card-title m-0">Reset Password</h2>
                <p class="fk-text-muted text-xs mt-1">Follow the steps below to securely reset your account password.</p>
            </div>
            
            <div class="fk-card-body p-4">
                <asp:Label ID="lblMessage" runat="server" CssClass="display-block text-center mb-3" Visible="false"></asp:Label>

                <!-- Step 1: Code Verification Panel -->
                <asp:Panel ID="pnlEnterCode" runat="server">
                    <p class="text-sm text-center mb-3">
                        Please enter the <strong>6-digit verification code</strong> sent to your registered email address. The code expires in 10 minutes.
                    </p>

                    <div class="form-group mb-3">
                        <label class="form-label">Registered Username or Email <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtEmailOrUser" runat="server" CssClass="fk-input" placeholder="e.g. name@example.com"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvEmailOrUser" runat="server" ControlToValidate="txtEmailOrUser" ErrorMessage="Username or Email is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="VerifyCodeGroup" />
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label">6-Digit Code <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtCode" runat="server" CssClass="fk-input code-input-box" MaxLength="6" placeholder="------" autocomplete="off"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvCode" runat="server" ControlToValidate="txtCode" ErrorMessage="Verification code is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="VerifyCodeGroup" />
                        <asp:RegularExpressionValidator ID="revCode" runat="server" ControlToValidate="txtCode" ValidationExpression="^\d{6}$" ErrorMessage="Code must be exactly 6 digits" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="VerifyCodeGroup" />
                    </div>

                    <asp:Button ID="btnVerifyCode" runat="server" Text="Verify Code &rarr;" CssClass="fk-btn fk-btn-buy width-100 p-3 text-base font-bold mb-3" ValidationGroup="VerifyCodeGroup" OnClick="btnVerifyCode_Click" />

                    <div class="flex-between align-center text-sm mt-3">
                        <asp:LinkButton ID="btnResendCode" runat="server" Text="Resend Code" CssClass="fk-link font-bold" CausesValidation="false" OnClick="btnResendCode_Click" />
                        <a href="<%= ResolveUrl("~/forgot_password.aspx") %>" class="fk-link">Request with another account</a>
                    </div>

                    <div class="text-center text-sm mt-3">
                        Remembered your password? <a href="<%= ResolveUrl("~/login.aspx") %>" class="fk-link font-bold">Back to Login</a>
                    </div>
                </asp:Panel>

                <!-- Step 2: New Password Panel (Reachable ONLY after code verification via server-side session) -->
                <asp:Panel ID="pnlReset" runat="server" Visible="false">
                    <p class="text-sm text-center text-success mb-3 font-bold">
                        &check; Code verified! Enter your new password below.
                    </p>

                    <div class="form-group mb-3">
                        <label class="form-label">New Password <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtNewPassword" runat="server" TextMode="Password" CssClass="fk-input" placeholder="Minimum 6 characters"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvNewPassword" runat="server" ControlToValidate="txtNewPassword" ErrorMessage="New password is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ResetGroup" />
                        <asp:RegularExpressionValidator ID="revNewPassword" runat="server" ControlToValidate="txtNewPassword" ValidationExpression="^.{6,}$" ErrorMessage="Password must be at least 6 characters" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ResetGroup" />
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtConfirmPassword" runat="server" TextMode="Password" CssClass="fk-input" placeholder="Re-enter new password"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvConfirmPassword" runat="server" ControlToValidate="txtConfirmPassword" ErrorMessage="Please confirm your password" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ResetGroup" />
                        <asp:CompareValidator ID="cvPassword" runat="server" ControlToValidate="txtConfirmPassword" ControlToCompare="txtNewPassword" ErrorMessage="Passwords do not match" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ResetGroup" />
                    </div>

                    <asp:Button ID="btnReset" runat="server" Text="Update Password &rarr;" CssClass="fk-btn fk-btn-buy width-100 p-3 text-base font-bold mb-3" ValidationGroup="ResetGroup" OnClick="btnReset_Click" />
                </asp:Panel>
            </div>
        </div>
    </div>
</asp:Content>
