Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web.Security
Imports TYBCA_52_PROJECT.Helpers

Public Class WebForm10
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblMsg.Text = ""
        End If
    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        If Not Page.IsValid Then Return

        Dim usernameInput As String = txtUsername.Text.Trim()
        Dim passwordInput As String = txtPassword.Text.Trim()
        lblMsg.Text = ""

        Try
            Dim selectSql As String = "SELECT UserID, Username, Email, EmailVerified, Password, Role, PasswordHash, Salt, IsActive FROM register WHERE Username = @u OR Email = @u"
            Dim dt As DataTable = Db.ExecuteQuery(selectSql, New SqlParameter("@u", usernameInput))

            If dt.Rows.Count = 0 Then
                lblMsg.Text = "Invalid username or password."
                Return
            End If

            Dim row As DataRow = dt.Rows(0)
            Dim userId As Integer = Convert.ToInt32(row("UserID"))
            Dim dbUsername As String = row("Username").ToString()
            Dim dbPassword As String = If(IsDBNull(row("Password")), "", row("Password").ToString())
            Dim role As String = If(IsDBNull(row("Role")), "Customer", row("Role").ToString())
            Dim passwordHash As String = If(IsDBNull(row("PasswordHash")), "", row("PasswordHash").ToString())
            Dim salt As String = If(IsDBNull(row("Salt")), "", row("Salt").ToString())
            Dim isActive As Boolean = If(IsDBNull(row("IsActive")), True, Convert.ToBoolean(row("IsActive")))

            If Not isActive Then
                lblMsg.Text = "Your account has been deactivated. Please contact store administrator."
                Return
            End If

            Dim isPasswordValid As Boolean = False

            ' Check PBKDF2 hash first
            If Not String.IsNullOrEmpty(passwordHash) AndAlso Not String.IsNullOrEmpty(salt) Then
                isPasswordValid = Security.VerifyPassword(passwordInput, passwordHash, salt)
            Else
                ' Fallback for legacy plain-text password
                isPasswordValid = (dbPassword = passwordInput)
                If isPasswordValid Then
                    ' Upgrade to PBKDF2 automatically on successful login
                    Dim newSalt As String = Security.GenerateSalt()
                    Dim newHash As String = Security.HashPassword(passwordInput, newSalt)
                    Db.ExecuteNonQuery("UPDATE register SET Password = '', PasswordHash = @h, Salt = @s WHERE UserID = @id", _
                                       New SqlParameter("@h", newHash), _
                                       New SqlParameter("@s", newSalt), _
                                       New SqlParameter("@id", userId))
                End If
            End If

            If Not isPasswordValid Then
                lblMsg.Text = "Invalid username or password."
                Return
            End If

            Dim emailVerified As Boolean = If(IsDBNull(row("EmailVerified")), True, Convert.ToBoolean(row("EmailVerified")))
            If role.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
                Try
                    Db.ExecuteNonQuery("UPDATE register SET LastLogin=GETDATE() WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", New SqlParameter("@id", userId))
                Catch
                    ' Last-login tracking must never prevent an otherwise successful sign-in.
                End Try
            End If
            Session("username") = dbUsername
            Session("UserID") = userId
            Session("role") = role
            Dim authCookie As HttpCookie = FormsAuthentication.GetAuthCookie(dbUsername, False)
            authCookie.Secure = Request.IsSecureConnection
            Response.Cookies.Add(authCookie)

            If Not emailVerified Then
                Session("EmailVerificationUserID") = userId
                Dim pendingReturnUrl As String = Request.QueryString("ReturnUrl")
                Session("RegistrationReturnUrl") = If(Security.IsLocalReturnUrl(pendingReturnUrl), pendingReturnUrl, "")
                Try
                    EmailVerification.SendVerificationEmail(userId, dbUsername, Convert.ToString(row("Email")))
                Catch verificationEx As Exception
                    Logger.LogError("Error preparing email verification code for UserID " & userId, verificationEx)
                    Session("EmailVerificationSendFailed") = True
                End Try
                Response.Redirect("~/verify_email.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
                Return
            End If

            Dim returnUrl As String = Request.QueryString("ReturnUrl")
            If Security.IsLocalReturnUrl(returnUrl) Then
                Response.Redirect(returnUrl, False)
                Context.ApplicationInstance.CompleteRequest()
            ElseIf role.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
                Response.Redirect("~/Admin/Dashboard.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
            Else
                Response.Redirect("~/Home.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
            End If

        Catch ex As Exception
            Logger.LogError("Login error", ex)
            If TypeOf ex Is ConfigurationErrorsException Then
                lblMsg.Text = "Sign-in is not configured for this hosting server. Please contact the store administrator."
            ElseIf TypeOf ex Is SqlException Then
                lblMsg.Text = "Sign-in is temporarily unavailable. Please try again later or contact the store administrator."
            Else
                lblMsg.Text = "An error occurred during login. Please try again."
            End If
        End Try
    End Sub
End Class
