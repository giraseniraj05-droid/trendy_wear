Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class WebForm9
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadDealsAndNewArrivals()
        End If
    End Sub

    Private Sub LoadDealsAndNewArrivals()
        Try
            ' Featured products
            Dim sqlDeals As String = "SELECT TOP 4 ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " & _
                                    "ISNULL(OldPrice, Price * 1.3) AS OldPrice, Stock, ProductImage AS Image, " & _
                                    "(SELECT ISNULL(AVG(CAST(rv.Rating AS DECIMAL(10,2))), 0) FROM Reviews rv WHERE rv.ProductID = addproduct1.ProductID AND rv.IsApproved = 1) AS AverageRating, " & _
                                    "(SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductID = addproduct1.ProductID AND rv.IsApproved = 1) AS ReviewCount " & _
                                    "FROM addproduct1 WHERE IsActive = 1 AND (IsFeatured = 1 OR NOT EXISTS (SELECT 1 FROM addproduct1 WHERE IsActive = 1 AND IsFeatured = 1)) " & _
                                    "ORDER BY IsFeatured DESC, ProductID DESC"
            Dim dtDeals As DataTable = Db.ExecuteQuery(sqlDeals)
            rptDeals.DataSource = dtDeals
            rptDeals.DataBind()

            ' Show a balanced 20-product storefront preview across all active categories.
            Dim sqlNew As String = "WITH RankedProducts AS (" & _
                                  "SELECT ProductID, ProductName, Category, CategoryID, Price, OldPrice, Stock, ProductImage, " & _
                                  "ROW_NUMBER() OVER (PARTITION BY CategoryID ORDER BY ProductID DESC) AS CategoryRank " & _
                                  "FROM addproduct1 WHERE IsActive = 1) " & _
                                  "SELECT TOP 20 ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " & _
                                  "ISNULL(OldPrice, Price * 1.35) AS OldPrice, Stock, ProductImage AS Image, " & _
                                  "(SELECT ISNULL(AVG(CAST(rv.Rating AS DECIMAL(10,2))), 0) FROM Reviews rv WHERE rv.ProductID = RankedProducts.ProductID AND rv.IsApproved = 1) AS AverageRating, " & _
                                  "(SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductID = RankedProducts.ProductID AND rv.IsApproved = 1) AS ReviewCount " & _
                                  "FROM RankedProducts WHERE CategoryRank <= 7 ORDER BY CategoryRank, CategoryID"
            Dim dtNew As DataTable = Db.ExecuteQuery(sqlNew)
            rptNewArrivals.DataSource = dtNew
            rptNewArrivals.DataBind()

            Dim sqlTopRated As String = "SELECT TOP 4 p.ProductID AS p_id, p.ProductName AS p_name, p.Price AS price, p.ProductImage AS Image, " & _
                                        "(SELECT AVG(CAST(rv.Rating AS DECIMAL(10,2))) FROM Reviews rv WHERE rv.ProductID = p.ProductID AND rv.IsApproved = 1) AS AverageRating, " & _
                                        "(SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductID = p.ProductID AND rv.IsApproved = 1) AS ReviewCount " & _
                                        "FROM addproduct1 p WHERE p.IsActive = 1 AND EXISTS (SELECT 1 FROM Reviews rv WHERE rv.ProductID = p.ProductID AND rv.IsApproved = 1) " & _
                                        "ORDER BY AverageRating DESC, ReviewCount DESC, p.ProductID DESC"
            Dim dtTopRated As DataTable = Db.ExecuteQuery(sqlTopRated)
            rptTopRated.DataSource = dtTopRated
            rptTopRated.DataBind()
        Catch ex As Exception
            Logger.LogError("Error loading home page products", ex)
        End Try
    End Sub

    Protected Sub rptProducts_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim productId As Integer = Convert.ToInt32(e.CommandArgument)

        If e.CommandName = "AddToCart" Then
            If CartService.TryAddToCart(Context, productId, 1) Then
                Toast.Show(Me, "Item added to your shopping cart!", Toast.ToastType.Success)
            Else
                Toast.Show(Me, "This item is out of stock or unavailable.", Toast.ToastType.Warning)
            End If
            ' Refresh navbar cart badge via postback or response script
            Response.Redirect(Request.RawUrl)

        ElseIf e.CommandName = "BuyNow" Then
            If Not CartService.TryAddToCart(Context, productId, 1) Then
                Toast.Show(Me, "This item is out of stock or unavailable.", Toast.ToastType.Warning)
                Return
            End If
            Dim userId As Integer
            If Integer.TryParse(Convert.ToString(Session("UserID")), userId) AndAlso userId > 0 Then
                Response.Redirect("~/Customer/checkout.aspx")
            Else
                Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
            End If
        End If
    End Sub

    Public Function GetDiscountPercentage(ByVal priceVal As Object, ByVal oldPriceVal As Object) As String
        Try
            Dim price As Decimal = Convert.ToDecimal(priceVal)
            Dim oldPrice As Decimal = Convert.ToDecimal(oldPriceVal)
            If oldPrice > price Then
                Dim discount As Integer = CInt(((oldPrice - price) / oldPrice) * 100)
                Return discount.ToString()
            End If
        Catch ex As Exception
        End Try
        Return "25"
    End Function

    Public Function GetRatingSummary(ByVal averageValue As Object, ByVal countValue As Object) As String
        Dim average As Decimal = Convert.ToDecimal(averageValue)
        Dim count As Integer = Convert.ToInt32(countValue)
        Dim stars As Integer = CInt(Math.Round(average, MidpointRounding.AwayFromZero))
        Return New String("★"c, stars) & New String("☆"c, 5 - stars) & " (" & count.ToString() & ")"
    End Function

    Public Function GetStockClass(ByVal stockVal As Object) As String
        Try
            Dim s As Integer = Convert.ToInt32(stockVal)
            If s <= 0 Then Return "text-danger font-bold"
            If s <= 5 Then Return "text-amber font-bold"
            Return "text-success font-bold"
        Catch
            Return "text-success"
        End Try
    End Function

    Public Function GetStockText(ByVal stockVal As Object) As String
        Try
            Dim s As Integer = Convert.ToInt32(stockVal)
            If s <= 0 Then Return "Out of Stock"
            If s <= 5 Then Return "Only " & s & " left in stock!"
            Return "In Stock"
        Catch
            Return "In Stock"
        End Try
    End Function
End Class
