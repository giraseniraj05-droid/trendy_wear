/* Dynamic Theme Switcher & Persistence Script for Trendy Wear */

(function () {
  const savedTheme = localStorage.getItem('tw_theme') || getCookie('tw_theme') || 'forest';
  setTheme(savedTheme);
  const savedAccent = localStorage.getItem('tw_accent');
  if (savedAccent) setCustomAccent(savedAccent);
})();

function setTheme(themeName) {
  const supportedThemes = ['light', 'dark', 'forest', 'rose', 'violet'];
  const theme = supportedThemes.includes(themeName) ? themeName : 'forest';
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('tw_theme', theme);
  setCookie('tw_theme', theme, 30);
}

function setAppTheme(themeName) {
  setTheme(themeName);
  const modal = document.getElementById('themeModal');
  if (modal) modal.classList.remove('show');
}

function toggleThemeModal() {
  const modal = document.getElementById('themeModal');
  if (modal) modal.classList.toggle('show');
}

function closeThemeModal(event) {
  if (event.target === event.currentTarget) {
    event.currentTarget.classList.remove('show');
  }
}

function setCustomAccent(color) {
  if (!/^#[0-9a-f]{6}$/i.test(color)) return;
  document.documentElement.style.setProperty('--primary-blue', color);
  document.documentElement.style.setProperty('--accent-contrast', getAccentContrast(color));
  localStorage.setItem('tw_accent', color);
  const picker = document.getElementById('customAccent');
  if (picker) picker.value = color;
}


function getAccentContrast(hexColor) {
  const values = hexColor.slice(1).match(/.{2}/g).map(value => parseInt(value, 16) / 255);
  const linear = values.map(value => value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4));
  const luminance = 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
  const ratio = foreground => {
    const channels = foreground === '#FFFFFF' ? [1, 1, 1] : [20, 32, 0].map(value => value / 255);
    const bg = luminance;
    const fg = 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
    return (Math.max(bg, fg) + 0.05) / (Math.min(bg, fg) + 0.05);
  };
  return ratio('#FFFFFF') >= ratio('#142000') ? '#FFFFFF' : '#142000';
}
function setCookie(name, value, days) {
  let expires = "";
  if (days) {
    let date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/; SameSite=Lax";
}

function getCookie(name) {
  let nameEQ = name + "=";
  let ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
}
