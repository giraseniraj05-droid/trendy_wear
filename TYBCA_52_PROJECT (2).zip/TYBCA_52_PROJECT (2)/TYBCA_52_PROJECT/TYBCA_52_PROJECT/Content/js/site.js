/* Site Interactions & Cart Badge Utility Script */

document.addEventListener('DOMContentLoaded', function () {
  console.log('Trendy Wear site interactions loaded.');
  document.querySelectorAll('.home-product-grid').forEach(function (grid) {
    if (!grid.querySelector('.fk-product-card')) {
      grid.classList.add('is-empty');
    }
  });
});

function confirmDelete(message) {
  return confirm(message || 'Are you sure you want to delete this item?');
}
