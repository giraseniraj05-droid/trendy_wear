(function () {
  "use strict";

  var slider = document.querySelector("[data-home-slider]");
  if (!slider) return;

  var slides = Array.prototype.slice.call(slider.querySelectorAll(".tw-home-slide"));
  var dots = Array.prototype.slice.call(slider.querySelectorAll("[data-slider-dot]"));
  var previous = slider.querySelector("[data-slider-prev]");
  var next = slider.querySelector("[data-slider-next]");
  if (slides.length < 2) return;

  var activeIndex = 0;
  var timer = null;
  var hovering = false;
  var focusWithin = false;
  var touchStartX = null;
  var reducedMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)");

  function showSlide(index) {
    activeIndex = (index + slides.length) % slides.length;
    slides.forEach(function (slide, i) {
      slide.setAttribute("aria-hidden", i === activeIndex ? "false" : "true");
    });
    dots.forEach(function (dot, i) {
      dot.setAttribute("aria-pressed", i === activeIndex ? "true" : "false");
    });
  }

  function stopTimer() {
    if (timer !== null) {
      window.clearInterval(timer);
      timer = null;
    }
  }

  function startTimer() {
    stopTimer();
    if (hovering || focusWithin || document.hidden || (reducedMotion && reducedMotion.matches)) return;
    timer = window.setInterval(function () {
      showSlide(activeIndex + 1);
    }, 5000);
  }

  function pause() {
    stopTimer();
  }

  function resume() {
    if (!hovering && !focusWithin) startTimer();
  }

  if (previous) previous.addEventListener("click", function () { showSlide(activeIndex - 1); startTimer(); });
  if (next) next.addEventListener("click", function () { showSlide(activeIndex + 1); startTimer(); });
  dots.forEach(function (dot) {
    dot.addEventListener("click", function () {
      var index = parseInt(dot.getAttribute("data-slider-dot"), 10);
      if (!isNaN(index)) showSlide(index);
      startTimer();
    });
  });

  slider.addEventListener("mouseenter", function () { hovering = true; pause(); });
  slider.addEventListener("mouseleave", function () { hovering = false; resume(); });
  slider.addEventListener("focusin", function () { focusWithin = true; pause(); });
  slider.addEventListener("focusout", function () {
    window.setTimeout(function () {
      focusWithin = slider.contains(document.activeElement);
      resume();
    }, 0);
  });

  slider.addEventListener("keydown", function (event) {
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      showSlide(activeIndex - 1);
      startTimer();
    } else if (event.key === "ArrowRight") {
      event.preventDefault();
      showSlide(activeIndex + 1);
      startTimer();
    }
  });

  slider.addEventListener("touchstart", function (event) {
    if (event.changedTouches.length) touchStartX = event.changedTouches[0].clientX;
  }, { passive: true });
  slider.addEventListener("touchend", function (event) {
    if (touchStartX === null || !event.changedTouches.length) return;
    var distance = event.changedTouches[0].clientX - touchStartX;
    touchStartX = null;
    if (Math.abs(distance) < 48) return;
    showSlide(activeIndex + (distance < 0 ? 1 : -1));
    startTimer();
  }, { passive: true });

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) pause();
    else resume();
  });
  if (reducedMotion && reducedMotion.addEventListener) {
    reducedMotion.addEventListener("change", function () {
      if (reducedMotion.matches) pause();
      else resume();
    });
  }

  showSlide(0);
  startTimer();
}());
