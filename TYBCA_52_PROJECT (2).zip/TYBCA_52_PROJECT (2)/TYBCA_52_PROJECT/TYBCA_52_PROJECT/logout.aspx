<%@ Page Title="Logout" Language="vb" AutoEventWireup="false" CodeBehind="logout.aspx.vb" Inherits="TYBCA_52_PROJECT.logout" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <title>Logging out...</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <p>Logging out, please wait...</p>
    </div>
    </form>
</body>
</html>
