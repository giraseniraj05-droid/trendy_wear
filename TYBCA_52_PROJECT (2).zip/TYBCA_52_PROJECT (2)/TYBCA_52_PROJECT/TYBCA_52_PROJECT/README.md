# Trendy Wear - E-Commerce Web Application (ASP.NET Web Forms + VB.NET)

Trendy Wear is a full-featured e-commerce web application built with **ASP.NET Web Forms**, **VB.NET**, **ADO.NET**, and **SQL Server**. It provides a secure, role-based shopping experience for Men, Women, and Kids fashion with currency support in **INR (₹)**.

---

## Technical Features

1. **Security & Authentication**:
   - PBKDF2 Password Hashing (`Rfc2898DeriveBytes` with per-user salts, 100,000 iterations).
   - Automated legacy plain-text password migration on user login.
   - Account Lockout Protection (15-minute lockout after 5 consecutive failed attempts).
   - Token-based Password Reset workflow with 30-minute token expiration.
   - Forms Authentication with HttpOnly, secure cookies.
   - Path-based folder authorization (`/Customer` and `/Admin`).

2. **Database & Architecture**:
   - Centralized ADO.NET abstraction layer (`Helpers/Db.vb`) utilizing parameterized SQL queries (`SqlParameter`) to prevent SQL Injection.
   - Atomic Order Transactions (`SqlTransaction`) for order processing and inventory stock updates.
   - Soft Delete support (`IsActive`) to preserve order history data integrity.
   - Reusable Models (`Models/`) and Business Services (`Services/CartService.vb`).

3. **Dynamic Theme System**:
   - CSS Custom Properties (`:root` variables) for real-time theme switching without page reloads.
   - Multiple built-in themes: Light, Dark, Ocean, Forest, Rose.
   - Client-side persistence via `localStorage` and `cookie` headers to avoid theme flash.

4. **E-Commerce Capabilities**:
   - Product Catalog with Category Filtering, Size Selectors, Price Range Slider, and Sorting.
   - Shopping Cart with live badge updates, item removal, and persistent database synchronization.
   - Promo Coupon Discounts (`WELCOME10`, `FLAT100`).
   - Order Status Tracking & History Timeline (Pending -> Delivered).
   - Rating & Feedback Moderation System.

---

## Setup & Running Instructions

1. **Database Setup**:
   - Open Visual Studio or SQL Server Management Studio.
   - Connect to `App_Data/Myshop.mdf`.
   - Run `Database/upgrade.sql` to apply database schema enhancements and seed initial data.

2. **Default Admin Login**:
   - **Username**: `admin`
   - **Password**: `admin123`

3. **Build & Launch**:
   - Build the solution using Visual Studio or MSBuild.
   - Run using IIS Express or ASP.NET Development Server.

---

## Interview Talking Points (Top 10 Technical Highlights)

1. **PBKDF2 Password Security**: Implemented industry-standard password hashing using `Rfc2898DeriveBytes` with a 128-bit per-user salt and 100,000 iterations.
2. **Seamless Password Migration**: Designed zero-downtime authentication that automatically upgrades legacy plain-text user passwords to PBKDF2 hashes upon successful login.
3. **SqlTransaction Guarantee**: Ensured ACID compliance during checkout by wrapping order creation, order detail line items, stock updates, and total calculations inside a single `SqlTransaction`.
4. **Parameterized SQL Defense**: ELiminated SQL Injection vulnerabilities across all data access operations by building a custom parameterized query builder (`Helpers/Db.vb`).
5. **Role-Based Folder Authorization**: Leveraged Web.config location tags (`<location path="Customer">`) alongside code-behind checks in master pages to enforce strict access control.
6. **Soft Delete Design Pattern**: Replaced hard SQL deletes with `IsActive` bit flags on products, preventing foreign key constraint violations while maintaining historic order reports.
7. **Dynamic Theme System**: Built a CSS variables system driven by `data-theme` HTML attributes, allowing real-time palette toggling with zero server roundtrips.
8. **Token-Based Password Resets**: Engineered a secure password recovery flow using cryptographically strong random tokens (`Security.GenerateRandomToken()`) with 30-minute expiration.
9. **Layered Architecture**: Decoupled database queries into dedicated helper and service classes (`CartService.vb`), keeping Web Forms code-behind focused purely on UI event handlers.
10. **INR (₹) Localization**: Standardized currency display across the application to Indian Rupees (`en-IN`), using `ToString("N2")` formatting.
