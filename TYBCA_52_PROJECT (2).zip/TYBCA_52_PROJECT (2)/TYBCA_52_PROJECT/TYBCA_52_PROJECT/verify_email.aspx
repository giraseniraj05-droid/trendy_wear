<%@ Page Title="Verify Email" Language="VB" MasterPageFile="~/navbar.Master" AutoEventWireup="false" CodeBehind="verify_email.aspx.vb" Inherits="TYBCA_52_PROJECT.verify_email" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="auth-container">
        <div class="fk-card auth-card auth-compact">
            <div class="auth-banner-col auth-compact-banner"><h2 class="auth-banner-title">Verify your email</h2><p class="auth-banner-sub">One more step to secure your Trendy Wear account.</p></div>
            <div class="fk-card-header text-center"><h2 class="fk-card-title m-0">Email verification</h2></div>
            <div class="fk-card-body p-4 text-center">
                <p>Enter the six-digit code we sent to your email. Codes expire after 10 minutes.</p>
                <asp:TextBox ID="txtCode" runat="server" CssClass="fk-input text-center mb-3" MaxLength="6" placeholder="6-digit code" inputmode="numeric" autocomplete="one-time-code"></asp:TextBox>
                <asp:Label ID="lblCooldown" runat="server" CssClass="display-block mb-2"></asp:Label>
                <asp:Label ID="lblMessage" runat="server" CssClass="display-block mb-3"></asp:Label>
                <asp:Button ID="btnVerify" runat="server" Text="Verify email" CssClass="fk-btn fk-btn-primary width-100 mb-2" />
                <asp:Button ID="btnResend" runat="server" Text="Resend code" CssClass="fk-btn width-100 mb-3" />
                <a href="<%= ResolveUrl("~/login.aspx") %>" class="fk-link">Continue to login</a>
            </div>
        </div>
    </div>
</asp:Content>
