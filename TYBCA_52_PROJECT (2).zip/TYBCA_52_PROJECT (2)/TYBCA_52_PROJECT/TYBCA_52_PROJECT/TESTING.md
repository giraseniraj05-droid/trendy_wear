# Trendy Wear - End-to-End Testing Checklist

Use this step-by-step checklist to verify all features and workflows before presenting the application.

---

## 1. Authentication & Security Testing
- [ ] **Registration**:
  - Open `register.aspx`.
  - Enter invalid email (e.g. `user@test`) -> Verify regular expression validator blocks submission.
  - Enter invalid mobile (e.g. `123`) -> Verify 10-digit mobile validator blocks submission.
  - Fill valid details -> Submit -> Verify success message and redirect to `login.aspx`.
  - Check DB `register` table -> Verify `PasswordHash` and `Salt` are populated.

- [ ] **Login & Lockout**:
  - Enter wrong password 5 times -> Verify account lockout message (15-minute lock).
  - Login with valid user credentials -> Verify redirect to `Customer/search_product.aspx`.
  - Check header -> Verify username greeting shows "Hi, [Username]".

- [ ] **Password Reset**:
  - Open `forgot_password.aspx`.
  - Submit registered email -> Verify plain-text password is **not** displayed on screen.
  - Click reset link token -> Set new password on `reset_password.aspx`.
  - Login with new password -> Verify clean authentication.

- [ ] **Logout**:
  - Click "Logout" -> Verify session cleared, auth cookie invalidated, and redirected to `login.aspx`.

---

## 2. Customer E-Commerce Workflows
- [ ] **Product Browse & Search**:
  - Open `Customer/search_product.aspx`.
  - Filter by Category (Men / Women / Kids).
  - Search by keywords -> Verify dynamic filtering.

- [ ] **Cart & Checkout**:
  - Click "Add to Cart" on a product.
  - Navigate to `Customer/checkout.aspx`.
  - Enter shipping details, select COD or Online Payment -> Click "Confirm Order".
  - Verify order is placed inside `SqlTransaction`.

- [ ] **My Orders**:
  - Open `Customer/MyOrders.aspx`.
  - Verify user only sees orders tied to their own UserID (no hardcoded user 1 data).
  - Verify order total displays in INR (₹).

- [ ] **Feedback**:
  - Open `Customer/feedback.aspx`.
  - Select Rating, Type, Comments, and Check/Uncheck "Would you recommend".
  - Click Submit -> Verify submission recorded with real recommend status in `Feedback` table.

---

## 3. Admin Panel Workflows
- [ ] **Admin Access Control**:
  - Try accessing `/Admin/Add_Product.aspx` as a guest or Customer -> Verify access denied / redirect to `login.aspx`.
  - Login as `admin` / `admin123` -> Verify access granted to Admin Dashboard.

- [ ] **Product Management & Soft Delete**:
  - Open `Admin/Add_Product.aspx`.
  - Upload valid image (`.jpg`, `.png`, `.webp` under 2 MB) -> Submit product.
  - Attempt uploading `.exe` or `.txt` -> Verify file validation blocks submission.
  - Click "Delete" on a product with orders -> Verify product is soft-deleted (`IsActive = 0`) without foreign key SQL crash.
