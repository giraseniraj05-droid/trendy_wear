<%@ Page Title="Forgot Password" Language="VB" MasterPageFile="~/navbar.Master" AutoEventWireup="false" CodeBehind="forgot_password.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm8" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="auth-container">
        <div class="fk-card auth-card auth-compact">
            <div class="auth-banner-col auth-compact-banner"><h2 class="auth-banner-title">Account recovery</h2><p class="auth-banner-sub">A secure code helps you regain access to your Trendy Wear account.</p></div>
            <div class="fk-card-header text-center">
                <h2 class="fk-card-title m-0">Password Reset Request</h2>
                <p class="fk-text-muted text-xs mt-1">Enter your registered email address or username to receive a 6-digit verification code.</p>
            </div>
            <div class="fk-card-body p-4">
                <div class="form-group mb-3">
                    <label class="form-label">Registered Username or Email <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtEmailOrUser" runat="server" CssClass="fk-input" placeholder="e.g. name@example.com"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvUser" runat="server" ControlToValidate="txtEmailOrUser" ErrorMessage="Email/Username is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ForgotForm" />
                </div>

                <asp:Label ID="lblMsg" runat="server" CssClass="display-block text-center mb-3"></asp:Label>

                <asp:Button ID="btnSendReset" runat="server" Text="Send Verification Code &rarr;" CssClass="fk-btn fk-btn-buy width-100 p-3 text-base font-bold mb-3" ValidationGroup="ForgotForm" OnClick="btnSendReset_Click" />

                <div class="text-center text-sm mt-3">
                    Already have a 6-digit code? <a href="<%= ResolveUrl("~/reset_password.aspx") %>" class="fk-link font-bold">Enter code here</a>
                </div>

                <div class="text-center text-sm mt-2">
                    Remembered your password? <a href="<%= ResolveUrl("~/login.aspx") %>" class="fk-link font-bold">Back to Login</a>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
