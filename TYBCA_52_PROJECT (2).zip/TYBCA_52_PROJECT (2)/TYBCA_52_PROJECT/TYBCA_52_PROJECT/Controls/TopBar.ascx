<%@ Control Language="VB" AutoEventWireup="false" CodeBehind="TopBar.ascx.vb" Inherits="TYBCA_52_PROJECT.TopBar" %>

<header class="fk-header">
  <div class="fk-header-main">
    <div class="fk-header-container">
      <!-- Logo -->
      <a href="<%= ResolveUrl("~/Home.aspx") %>" class="fk-brand">
        <span class="fk-brand-name">Trendy Wear</span>
        <span class="fk-brand-sub">Explore <span class="fk-gold">Plus</span></span>
      </a>

      <!-- Mobile Menu Toggle -->
      <button type="button" class="fk-mobile-toggle" onclick="toggleMobileNav()">
        ☰
      </button>

      <!-- Search Bar -->
      <div class="fk-search-wrap">
        <select id="ddlNavCategory" class="fk-search-cat" onchange="filterByCategory(this.value)">
          <option value="">All Categories</option>
          <option value="Men">Men</option>
          <option value="Women">Women</option>
          <option value="Kids">Kids</option>
        </select>
        <input type="text" id="txtNavSearch" class="fk-search-input" placeholder="Search for products, brands and more..." onkeypress="handleSearchKey(event)" />
        <button type="button" class="fk-search-btn" onclick="executeSearch()">🔍 Search</button>
      </div>

      <!-- Header Actions -->
      <div class="fk-header-actions" id="fkHeaderActions">
        <!-- Guest vs User State -->
        <asp:PlaceHolder ID="phGuest" runat="server">
          <a href="<%= ResolveUrl("~/login.aspx") %>" class="fk-btn-login">Login</a>
        </asp:PlaceHolder>

        <asp:PlaceHolder ID="phUser" runat="server">
          <div class="fk-dropdown">
            <button type="button" class="fk-dropdown-btn">
              👤 <asp:Literal ID="litUsername" runat="server"></asp:Literal> ▾
            </button>
            <div class="fk-dropdown-menu">
              <asp:PlaceHolder ID="phAdminLink" runat="server" Visible="false">
                <a href="<%= ResolveUrl("~/Admin/Dashboard.aspx") %>">⚡ Admin Dashboard</a>
              </asp:PlaceHolder>
              <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>">🔍 Browse Store</a>
              <a href="<%= ResolveUrl("~/Customer/MyOrders.aspx") %>">📦 My Orders</a>
              <a href="<%= ResolveUrl("~/Customer/wishlist.aspx") %>">❤️ Wishlist</a>
              <a href="<%= ResolveUrl("~/Customer/feedback.aspx") %>">✍️ Feedback</a>
              <hr class="fk-divider" />
              <a href="<%= ResolveUrl("~/logout.aspx") %>" class="fk-text-danger">🚪 Logout</a>
            </div>
          </div>
        </asp:PlaceHolder>

        <!-- Cart Icon -->
        <a href="<%= ResolveUrl("~/Customer/cart.aspx") %>" class="fk-cart-link">
          <span class="fk-cart-icon">🛒</span>
          <span class="fk-cart-label">Cart</span>
          <span class="fk-cart-badge"><asp:Literal ID="litCartCount" runat="server">0</asp:Literal></span>
        </a>

        <!-- Theme Switcher Button -->
        <button type="button" class="fk-theme-btn" onclick="toggleThemeModal()" title="Switch Theme">🎨</button>
      </div>
    </div>
  </div>

  <!-- Sub Navigation Bar -->
  <nav class="fk-sub-nav">
    <div class="fk-sub-container">
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-sub-link">🏷️ All Products</a>
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Men") %>" class="fk-sub-link">👔 Men's Clothing</a>
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Women") %>" class="fk-sub-link">👗 Women's Fashion</a>
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Kids") %>" class="fk-sub-link">🧸 Kids Wear</a>
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx?sort=price_asc") %>" class="fk-sub-link fk-highlight">🔥 Top Deals</a>
      <a href="<%= ResolveUrl("~/Customer/search_product.aspx?sort=rating") %>" class="fk-sub-link">⭐ Top Rated</a>
      <a href="<%= ResolveUrl("~/about.aspx") %>" class="fk-sub-link">ℹ️ About Us</a>
      <a href="<%= ResolveUrl("~/contact.aspx") %>" class="fk-sub-link">📞 Contact</a>
    </div>
  </nav>
</header>

<!-- Theme Picker Modal -->
<div id="themeModal" class="fk-modal-overlay" onclick="closeThemeModal(event)">
  <div class="fk-modal-content" onclick="event.stopPropagation()">
    <div class="fk-modal-header">
      <h3>🎨 Choose Site Theme</h3>
      <button type="button" class="fk-modal-close" onclick="toggleThemeModal()">&times;</button>
    </div>
    <div class="fk-theme-grid">
      <button type="button" class="fk-theme-opt opt-light" onclick="setAppTheme('light')">☀️ Light (Flipkart)</button>
      <button type="button" class="fk-theme-opt opt-dark" onclick="setAppTheme('dark')">🌙 Dark Mode</button>
      <button type="button" class="fk-theme-opt opt-forest" onclick="setAppTheme('forest')">🌲 Emerald Forest</button>
      <button type="button" class="fk-theme-opt opt-rose" onclick="setAppTheme('rose')">🌹 Velvet Rose</button>
      <button type="button" class="fk-theme-opt opt-violet" onclick="setAppTheme('violet')">🍇 Royal Violet</button>
    </div>
    <div style="margin-top: 15px; display: flex; align-items: center; gap: 10px;">
      <label for="customAccent">Custom Accent Color:</label>
      <input type="color" id="customAccent" onchange="setCustomAccent(this.value)" value="#2874f0" />
    </div>
  </div>
</div>

<script>
  function handleSearchKey(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeSearch();
    }
  }
  function executeSearch() {
    var q = document.getElementById('txtNavSearch').value;
    var cat = document.getElementById('ddlNavCategory').value;
    var url = '<%= ResolveUrl("~/Customer/search_product.aspx") %>?q=' + encodeURIComponent(q);
    if (cat) url += '&cat=' + encodeURIComponent(cat);
    window.location.href = url;
  }
  function filterByCategory(cat) {
    window.location.href = '<%= ResolveUrl("~/Customer/search_product.aspx") %>?cat=' + encodeURIComponent(cat);
  }
  function toggleMobileNav() {
    var actions = document.getElementById('fkHeaderActions');
    actions.classList.toggle('show-mobile');
  }
</script>
