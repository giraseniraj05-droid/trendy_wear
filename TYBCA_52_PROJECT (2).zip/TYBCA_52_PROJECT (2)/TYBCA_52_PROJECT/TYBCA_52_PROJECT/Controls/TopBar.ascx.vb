Imports System
Imports System.Web.UI
Imports TYBCA_52_PROJECT.Services

Public Class TopBar
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindUserStatus()
            BindCartBadge()
        End If
    End Sub

    Private Sub BindUserStatus()
        Dim username As String = TryCast(Session("username"), String)
        Dim role As String = TryCast(Session("role"), String)

        If Not String.IsNullOrEmpty(username) Then
            phGuest.Visible = False
            phUser.Visible = True
            litUsername.Text = Server.HtmlEncode(username)
            If role = "Admin" Then
                phAdminLink.Visible = True
            End If
        Else
            phGuest.Visible = True
            phUser.Visible = False
        End If
    End Sub

    Private Sub BindCartBadge()
        Dim count As Integer = CartService.GetCartItemCount(Context)
        litCartCount.Text = count.ToString()
    End Sub
End Class
