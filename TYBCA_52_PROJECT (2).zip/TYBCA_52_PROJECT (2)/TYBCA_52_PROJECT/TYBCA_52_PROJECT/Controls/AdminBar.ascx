<%@ Control Language="VB" AutoEventWireup="false" CodeBehind="AdminBar.ascx.vb" Inherits="TYBCA_52_PROJECT.AdminBar" %>

<aside class="admin-sidebar" id="adminNavMenu" aria-label="Admin navigation">
  <a href="<%= ResolveUrl("~/Admin/Dashboard.aspx") %>" class="admin-brand" onclick="toggleAdminNav()">
    <span class="admin-brand-icon" aria-hidden="true">⚡</span>
    <span class="admin-brand-text">Trendy Wear <small class="admin-badge">ADMIN</small></span>
  </a>

  <nav class="admin-nav-links" aria-label="Admin sections">
    <span class="admin-nav-section">OVERVIEW</span>
    <a href="<%= ResolveUrl("~/Admin/Dashboard.aspx") %>" class="admin-nav-item <%= GetActiveClass("Dashboard.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">📊</span><span>Dashboard</span>
    </a>

    <span class="admin-nav-section">CATALOG</span>
    <a href="<%= ResolveUrl("~/Admin/Add_Product.aspx") %>" class="admin-nav-item <%= GetActiveClass("Add_Product.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">📦</span><span>Products &amp; Stock</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/manage_categories.aspx") %>" class="admin-nav-item <%= GetActiveClass("manage_categories.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">📁</span><span>Categories</span>
    </a>

    <span class="admin-nav-section">OPERATIONS</span>
    <a href="<%= ResolveUrl("~/Admin/manageorder.aspx") %>" class="admin-nav-item <%= GetActiveClass("manageorder.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">🛒</span><span>Orders</span><span class="admin-pill-badge"><asp:Literal ID="litPendingOrders" runat="server">0</asp:Literal></span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/ReturnRequests.aspx") %>" class="admin-nav-item <%= GetActiveClass("ReturnRequests.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">↩️</span><span>Returns</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/Coupons.aspx") %>" class="admin-nav-item <%= GetActiveClass("Coupons.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">🏷️</span><span>Coupons</span>
    </a>

    <span class="admin-nav-section">PEOPLE &amp; INSIGHTS</span>
    <a href="<%= ResolveUrl("~/Admin/customers.aspx") %>" class="admin-nav-item <%= GetActiveClass("customers.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">👥</span><span>Customers</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/customerfeedbacks.aspx") %>" class="admin-nav-item <%= GetActiveClass("customerfeedbacks.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">💬</span><span>Feedbacks</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/Reports.aspx") %>" class="admin-nav-item <%= GetActiveClass("Reports.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">📈</span><span>Reports</span>
    </a>

    <span class="admin-nav-section">SYSTEM</span>
    <a href="<%= ResolveUrl("~/Admin/AdminAccounts.aspx") %>" class="admin-nav-item <%= GetActiveClass("AdminAccounts.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">🔐</span><span>Admin Accounts</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/EmailLog.aspx") %>" class="admin-nav-item <%= GetActiveClass("EmailLog.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">✉️</span><span>Email Log</span>
    </a>
    <a href="<%= ResolveUrl("~/Admin/SiteSettings.aspx") %>" class="admin-nav-item <%= GetActiveClass("SiteSettings.aspx") %>" onclick="toggleAdminNav()">
      <span class="admin-nav-icon" aria-hidden="true">⚙️</span><span>Settings</span>
    </a>
  </nav>
</aside>

<div class="admin-nav-scrim" id="adminNavOverlay" onclick="toggleAdminNav()"></div>

<header class="admin-top-bar">
  <div class="admin-top-inner">
    <button type="button" class="admin-mobile-btn" onclick="toggleAdminNav()" aria-label="Open admin navigation" aria-controls="adminNavMenu">☰</button>
    <div class="admin-top-title">
      <strong>Admin Console</strong>
      <span>Manage your store from one place</span>
    </div>

    <div class="admin-user-menu">
      <button type="button" class="fk-theme-btn" onclick="toggleThemeModal()" title="Switch Theme" aria-label="Switch theme">🎨</button>

      <div class="fk-dropdown">
        <button type="button" class="fk-dropdown-btn admin-profile-btn">
          👑 Admin ▾
        </button>
        <div class="fk-dropdown-menu">
          <a href="<%= ResolveUrl("~/Home.aspx") %>">🛍️ View Storefront</a>
          <hr class="fk-divider" />
          <a href="<%= ResolveUrl("~/logout.aspx") %>" class="fk-text-danger">🚪 Logout</a>
        </div>
      </div>
    </div>
  </div>
</header>

<div id="themeModal" class="fk-modal-overlay" onclick="closeThemeModal(event)">
  <div class="fk-modal-content" onclick="event.stopPropagation()">
    <div class="fk-modal-header">
      <h3>🎨 Choose Site Theme</h3>
      <button type="button" class="fk-modal-close" onclick="toggleThemeModal()">&times;</button>
    </div>
    <div class="fk-theme-grid">
      <button type="button" class="fk-theme-opt opt-light" onclick="setAppTheme('light')">☀️ Light (Flipkart)</button>
      <button type="button" class="fk-theme-opt opt-dark" onclick="setAppTheme('dark')">🌙 Dark Mode</button>
      <button type="button" class="fk-theme-opt opt-forest" onclick="setAppTheme('forest')">🌲 Emerald Forest</button>
      <button type="button" class="fk-theme-opt opt-rose" onclick="setAppTheme('rose')">🌹 Velvet Rose</button>
      <button type="button" class="fk-theme-opt opt-violet" onclick="setAppTheme('violet')">🍇 Royal Violet</button>
    </div>
    <div class="admin-accent-picker">
      <label for="customAccent">Custom Accent Color:</label>
      <input type="color" id="customAccent" onchange="setCustomAccent(this.value)" value="#B4F105" />
    </div>
  </div>
</div>

<script>
  function toggleAdminNav() {
    var nav = document.getElementById('adminNavMenu');
    nav.classList.toggle('show-admin-mobile');
  }
</script>
