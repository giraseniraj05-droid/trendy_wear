Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminBar
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadPendingCount()
        End If
    End Sub

    Private Sub LoadPendingCount()
        Try
            Dim count As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status, '')) = 'pending'"))
            litPendingOrders.Text = count.ToString()
        Catch ex As Exception
            litPendingOrders.Text = "0"
        End Try
    End Sub

    Public Function GetActiveClass(ByVal pageName As String) As String
        Dim currentPath As String = Request.Url.AbsolutePath
        If currentPath.IndexOf(pageName, StringComparison.OrdinalIgnoreCase) >= 0 Then
            Return "active"
        End If
        Return ""
    End Function
End Class
