<%@ Page Title="An Error Occurred" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="error-page-container error-glass-card">
        <h2 class="error-title">An Unexpected Error Occurred</h2>
        <p class="error-desc">We apologize for the inconvenience. Our technical team has been notified.</p>
        <a href='<%= ResolveUrl("~/Home.aspx") %>' class="btn-tw-primary error-home-button">Go Back to Safety</a>
    </div>
</asp:Content>
