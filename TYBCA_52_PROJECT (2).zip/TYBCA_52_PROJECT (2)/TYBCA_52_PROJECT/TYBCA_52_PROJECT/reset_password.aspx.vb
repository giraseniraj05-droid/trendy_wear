Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class reset_password
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' Check if there is a pending notice from forgot_password.aspx
            If Session("ResetNotice") IsNot Nothing Then
                ShowNotice(Session("ResetNotice").ToString())
                Session.Remove("ResetNotice")
            End If

            ' Pre-fill email/username if available in session
            If Session("ResetIdentifier") IsNot Nothing Then
                txtEmailOrUser.Text = Session("ResetIdentifier").ToString()
            End If

            ' Security: URL parameters are completely ignored.
            ' The reset step must not be reachable by guessing a URL:
            ' keep the verified state in a server-side session tied to the verified code, not in a query string.
            UpdateViewState()
        End If
    End Sub

    Private Sub UpdateViewState()
        If IsVerifiedSessionValid() Then
            pnlEnterCode.Visible = False
            pnlReset.Visible = True
        Else
            pnlEnterCode.Visible = True
            pnlReset.Visible = False
        End If
    End Sub

    Private Function IsVerifiedSessionValid() As Boolean
        Dim resetIdObj As Object = Session("ResetVerified_ResetID")
        Dim userIdObj As Object = Session("ResetVerified_UserID")
        Dim tokenHashObj As Object = Session("ResetVerified_TokenHash")

        If resetIdObj Is Nothing OrElse userIdObj Is Nothing OrElse tokenHashObj Is Nothing Then
            Return False
        End If

        Dim resetId As Integer
        Dim userId As Integer
        If Not Integer.TryParse(resetIdObj.ToString(), resetId) OrElse Not Integer.TryParse(userIdObj.ToString(), userId) Then
            Return False
        End If

        Try
            Dim dt As DataTable = Db.ExecuteQuery(
                "SELECT ResetID, UserID, TokenHash, ExpiresAt, IsUsed FROM PasswordResets WHERE ResetID = @ResetID AND UserID = @UserID",
                Db.CreateParam("@ResetID", SqlDbType.Int, resetId),
                Db.CreateParam("@UserID", SqlDbType.Int, userId))

            If dt.Rows.Count = 0 Then Return False

            Dim row As DataRow = dt.Rows(0)
            Dim isUsed As Boolean = Convert.ToBoolean(row("IsUsed"))
            Dim expiresAt As DateTime = Convert.ToDateTime(row("ExpiresAt"))
            Dim storedHash As String = Convert.ToString(row("TokenHash"))

            ' Ensure the code has not expired, is not already marked used, and matches stored hash
            If isUsed OrElse expiresAt < DateTime.Now OrElse Not String.Equals(storedHash, tokenHashObj.ToString(), StringComparison.Ordinal) Then
                Return False
            End If

            Return True
        Catch ex As Exception
            Logger.LogError("Error validating verified session in reset_password", ex)
            Return False
        End Try
    End Function

    Protected Sub btnVerifyCode_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnVerifyCode.Click
        lblMessage.Visible = False
        lblMessage.Text = ""

        Dim code As String = txtCode.Text.Trim()
        If String.IsNullOrEmpty(code) OrElse code.Length <> 6 OrElse Not Regex.IsMatch(code, "^\d{6}$") Then
            ShowError("Please enter a valid 6-digit verification code.")
            Return
        End If

        Dim inputStr As String = txtEmailOrUser.Text.Trim()
        Dim userId As Integer = 0

        Try
            ' Resolve UserID from input username/email or session
            If Not String.IsNullOrEmpty(inputStr) Then
                Dim dtUser As DataTable = Db.ExecuteQuery(
                    "SELECT UserID FROM register WHERE Username = @i OR Email = @i",
                    New SqlParameter("@i", inputStr))
                If dtUser.Rows.Count > 0 Then
                    userId = Convert.ToInt32(dtUser.Rows(0)("UserID"))
                End If
            ElseIf Session("ResetUserId") IsNot Nothing Then
                Integer.TryParse(Session("ResetUserId").ToString(), userId)
            End If

            ' If user still not identified by username/email, try finding active non-expired reset code matching hash
            If userId = 0 Then
                Dim computedHash As String = Security.HashResetCode(code)
                Dim dtLookup As DataTable = Db.ExecuteQuery(
                    "SELECT TOP 1 UserID FROM PasswordResets WHERE TokenHash = @h AND IsUsed = 0 AND ExpiresAt > GETDATE() ORDER BY CreatedAt DESC",
                    Db.CreateParam("@h", SqlDbType.NVarChar, computedHash, 255))
                If dtLookup.Rows.Count > 0 Then
                    userId = Convert.ToInt32(dtLookup.Rows(0)("UserID"))
                Else
                    ShowError("Please enter your registered username or email along with the code.")
                    Return
                End If
            End If

            ' Fetch active reset request for this user
            Dim dtReset As DataTable = Db.ExecuteQuery(
                "SELECT TOP 1 ResetID, UserID, TokenHash, ExpiresAt, IsUsed, Attempts FROM PasswordResets WHERE UserID = @UserID AND IsUsed = 0 ORDER BY CreatedAt DESC",
                Db.CreateParam("@UserID", SqlDbType.Int, userId))

            If dtReset.Rows.Count = 0 Then
                ShowError("No active password reset request was found for this account. Please request a new code.")
                Return
            End If

            Dim resetRow As DataRow = dtReset.Rows(0)
            Dim resetId As Integer = Convert.ToInt32(resetRow("ResetID"))
            Dim storedHash As String = Convert.ToString(resetRow("TokenHash"))
            Dim expiresAt As DateTime = Convert.ToDateTime(resetRow("ExpiresAt"))
            Dim attempts As Integer = Convert.ToInt32(resetRow("Attempts"))

            ' Check expiration (valid for 10 minutes)
            If DateTime.Now > expiresAt Then
                Db.ExecuteNonQuery("UPDATE PasswordResets SET IsUsed = 1 WHERE ResetID = @ResetID",
                                   Db.CreateParam("@ResetID", SqlDbType.Int, resetId))
                ShowError("This verification code has expired (valid for 10 minutes). Please request a new code.")
                Return
            End If

            ' Check if max 5 wrong attempts already reached
            If attempts >= 5 Then
                Db.ExecuteNonQuery("UPDATE PasswordResets SET IsUsed = 1 WHERE ResetID = @ResetID",
                                   Db.CreateParam("@ResetID", SqlDbType.Int, resetId))
                ShowError("Maximum verification attempts exceeded. This code is now invalid. Please request a new code.")
                Return
            End If

            ' Validate code against stored hash
            Dim isCodeValid As Boolean = Security.VerifyResetCode(code, storedHash)

            If Not isCodeValid Then
                attempts += 1
                If attempts >= 5 Then
                    ' Invalidate code on 5 wrong attempts
                    Db.ExecuteNonQuery("UPDATE PasswordResets SET Attempts = @Attempts, IsUsed = 1 WHERE ResetID = @ResetID",
                                       Db.CreateParam("@Attempts", SqlDbType.Int, attempts),
                                       Db.CreateParam("@ResetID", SqlDbType.Int, resetId))
                    ShowError("Incorrect code. You have exceeded the maximum of 5 attempts. This code is now invalid. Please request a new code.")
                Else
                    Db.ExecuteNonQuery("UPDATE PasswordResets SET Attempts = @Attempts WHERE ResetID = @ResetID",
                                       Db.CreateParam("@Attempts", SqlDbType.Int, attempts),
                                       Db.CreateParam("@ResetID", SqlDbType.Int, resetId))
                    Dim remainingAttempts As Integer = 5 - attempts
                    ShowError("Incorrect code. You have " & remainingAttempts & " attempt(s) remaining.")
                End If
                Return
            End If

            ' Code is correct!
            ' Keep the verified state in a server-side session tied to the verified code
            Session("ResetVerified_ResetID") = resetId
            Session("ResetVerified_UserID") = userId
            Session("ResetVerified_TokenHash") = storedHash

            ' Switch to step 2: new password
            pnlEnterCode.Visible = False
            pnlReset.Visible = True
            lblMessage.Visible = False

        Catch ex As Exception
            Logger.LogError("Error verifying password reset code", ex)
            ShowError("An error occurred while verifying the code. Please try again.")
        End Try
    End Sub

    Protected Sub btnReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReset.Click
        If Not Page.IsValid Then Return

        ' Enforce server-side verified session
        If Not IsVerifiedSessionValid() Then
            ShowError("Your password reset session has expired or is invalid. Please enter your code again.")
            ClearVerifiedSession()
            UpdateViewState()
            Return
        End If

        Dim resetId As Integer = Convert.ToInt32(Session("ResetVerified_ResetID"))
        Dim userId As Integer = Convert.ToInt32(Session("ResetVerified_UserID"))

        Dim newPassword As String = txtNewPassword.Text.Trim()
        Dim confirmPassword As String = txtConfirmPassword.Text.Trim()

        ' Enforce the same password rules as register
        Dim ruleError As String = ""
        If Not Security.ValidatePasswordRules(newPassword, ruleError) Then
            ShowError(ruleError)
            Return
        End If

        If Not String.Equals(newPassword, confirmPassword, StringComparison.Ordinal) Then
            ShowError("Passwords do not match.")
            Return
        End If

        Try
            ' Generate new password hash and salt
            Dim salt As String = Security.GenerateSalt()
            Dim hash As String = Security.HashPassword(newPassword, salt)

            ' Update register: clear plain Password, set PasswordHash & Salt, reset FailedAttempts and LockoutEnd
            Db.ExecuteNonQuery(
                "UPDATE register SET Password = '', PasswordHash = @Hash, Salt = @Salt, FailedAttempts = 0, LockoutEnd = NULL WHERE UserID = @UserID",
                Db.CreateParam("@Hash", SqlDbType.NVarChar, hash, 255),
                Db.CreateParam("@Salt", SqlDbType.NVarChar, salt, 255),
                Db.CreateParam("@UserID", SqlDbType.Int, userId))

            ' Mark the code used
            Db.ExecuteNonQuery(
                "UPDATE PasswordResets SET IsUsed = 1 WHERE ResetID = @ResetID",
                Db.CreateParam("@ResetID", SqlDbType.Int, resetId))

            ' Send "password changed" email
            Try
                Dim userDetails As DataTable = Db.ExecuteQuery(
                    "SELECT Username, Email FROM register WHERE UserID = @UserID",
                    Db.CreateParam("@UserID", SqlDbType.Int, userId))
                If userDetails.Rows.Count > 0 Then
                    Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(userDetails.Rows(0)("Username")))
                    Dim userEmail As String = Convert.ToString(userDetails.Rows(0)("Email"))
                    Dim emailBody As String = Mailer.Wrap(
                        "Your password was changed",
                        "<p>Hello " & safeUsername & ",</p>" & _
                        "<p>Your Trendy Wear account password was successfully changed. If you did not perform this action, please contact our support team immediately.</p>")
                    Mailer.SendAsync(userEmail, "Your password was changed - Trendy Wear", emailBody, "PasswordChanged")
                End If
            Catch mailEx As Exception
                Logger.LogError("Error sending password changed notification email for UserID " & userId, mailEx)
            End Try

            ' Clear server-side session
            ClearVerifiedSession()

            ' Show success and redirect
            lblMessage.CssClass = "message-box text-success display-block text-center mb-3 font-bold"
            lblMessage.Style("color") = "#28a745"
            lblMessage.Text = "Your password has been successfully updated! Redirecting to login..."
            lblMessage.Visible = True
            pnlReset.Visible = False
            pnlEnterCode.Visible = False

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "RedirectLogin", "setTimeout(function() { window.location.href='login.aspx'; }, 2000);", True)

        Catch ex As Exception
            Logger.LogError("Error updating password in reset_password", ex)
            ShowError("An error occurred while updating your password. Please try again.")
        End Try
    End Sub

    Protected Sub btnResendCode_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnResendCode.Click
        lblMessage.Visible = False
        lblMessage.Text = ""

        Dim inputStr As String = txtEmailOrUser.Text.Trim()
        If String.IsNullOrEmpty(inputStr) AndAlso Session("ResetIdentifier") IsNot Nothing Then
            inputStr = Session("ResetIdentifier").ToString()
        End If

        If String.IsNullOrEmpty(inputStr) Then
            ShowError("Please enter your username or email address to resend a code.")
            Return
        End If

        Try
            Dim dtUser As DataTable = Db.ExecuteQuery(
                "SELECT UserID, Username, Email FROM register WHERE Username = @i OR Email = @i",
                New SqlParameter("@i", inputStr))

            If dtUser.Rows.Count = 0 Then
                ShowNotice("If an account exists, a code has been sent.")
                Return
            End If

            Dim userId As Integer = Convert.ToInt32(dtUser.Rows(0)("UserID"))
            Dim username As String = Convert.ToString(dtUser.Rows(0)("Username"))
            Dim userEmail As String = Convert.ToString(dtUser.Rows(0)("Email"))

            ' Cooldown: 60 seconds
            Dim recentCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM PasswordResets WHERE UserID = @UserID AND CreatedAt >= DATEADD(second, -60, GETDATE())",
                Db.CreateParam("@UserID", SqlDbType.Int, userId)))

            If recentCount > 0 Then
                ShowError("Please wait at least 60 seconds before requesting another code.")
                Return
            End If

            ' Rate limit: 5 requests per hour
            Dim hourlyCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM PasswordResets WHERE UserID = @UserID AND CreatedAt >= DATEADD(hour, -1, GETDATE())",
                Db.CreateParam("@UserID", SqlDbType.Int, userId)))

            If hourlyCount >= 5 Then
                ShowError("Maximum password reset requests reached for this hour. Please try again later.")
                Return
            End If

            ' Invalidate previous codes
            Db.ExecuteNonQuery("UPDATE PasswordResets SET IsUsed = 1 WHERE UserID = @UserID AND IsUsed = 0",
                               Db.CreateParam("@UserID", SqlDbType.Int, userId))

            ' Generate and store 6-digit code
            Dim code As String = Security.GenerateSixDigitCode()
            Dim tokenHash As String = Security.HashResetCode(code)

            Db.ExecuteNonQuery(
                "INSERT INTO PasswordResets (UserID, TokenHash, ExpiresAt, IsUsed, CreatedAt, Attempts) VALUES (@UserID, @TokenHash, DATEADD(minute, 10, GETDATE()), 0, GETDATE(), 0)",
                Db.CreateParam("@UserID", SqlDbType.Int, userId),
                Db.CreateParam("@TokenHash", SqlDbType.NVarChar, tokenHash, 255))

            ' Send email
            Dim safeUsername As String = HttpUtility.HtmlEncode(username)
            Dim emailBody As String = Mailer.Wrap(
                "Reset your password",
                "<p>Hello " & safeUsername & ",</p>" & _
                "<p>Here is your new 6-digit verification code to reset your password:</p>" & _
                "<div style='font-size:32px;font-weight:bold;letter-spacing:8px;padding:16px;background:#f0f4f8;text-align:center;margin:20px 0;border-radius:8px;color:#253044;'>" & code & "</div>" & _
                "<p>This code will expire in <strong>10 minutes</strong>. For your security, do not share this code with anyone.</p>" & _
                "<p>If you did not make this request, you can safely ignore this email.</p>")
            Mailer.SendAsync(userEmail, "Your Password Reset Code - Trendy Wear", emailBody, "PasswordReset")

            Session("ResetUserId") = userId
            Session("ResetIdentifier") = inputStr
            ShowNotice("A new 6-digit verification code has been sent to your email.")

        Catch ex As Exception
            Logger.LogError("Error resending password reset code", ex)
            ShowNotice("If an account exists, a code has been sent.")
        End Try
    End Sub

    Private Sub ClearVerifiedSession()
        Session.Remove("ResetVerified_ResetID")
        Session.Remove("ResetVerified_UserID")
        Session.Remove("ResetVerified_TokenHash")
    End Sub

    Private Sub ShowError(ByVal message As String)
        lblMessage.CssClass = "message-box text-danger display-block text-center mb-3"
        lblMessage.Style("color") = "#dc3545"
        lblMessage.Text = HttpUtility.HtmlEncode(message)
        lblMessage.Visible = True
    End Sub

    Private Sub ShowNotice(ByVal message As String)
        lblMessage.CssClass = "message-box text-success display-block text-center mb-3"
        lblMessage.Style("color") = "#28a745"
        lblMessage.Text = HttpUtility.HtmlEncode(message)
        lblMessage.Visible = True
    End Sub
End Class
