Imports System.Web.Security

Public Class logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session.Clear()
        Session.Abandon()
        FormsAuthentication.SignOut()

        ' Clear auth cookie explicitly
        If Request.Cookies(FormsAuthentication.FormsCookieName) IsNot Nothing Then
            Dim myCookie As New HttpCookie(FormsAuthentication.FormsCookieName)
            myCookie.Expires = DateTime.Now.AddDays(-1)
            Response.Cookies.Add(myCookie)
        End If

        Response.Redirect("~/login.aspx", False)
        Context.ApplicationInstance.CompleteRequest()
    End Sub
End Class
