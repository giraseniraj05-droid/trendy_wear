<%@ Page Title="About Us" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="about-container info-content-panel">
        <h2>About Trendy Wear</h2>
        <p class="lead">Trendy Wear is your ultimate destination for high-quality, modern, and affordable clothing across Men's, Women's, and Kids' fashion.</p>
        <hr />
        <h4>Our Mission</h4>
        <p>Our mission is to empower individuals to express their personal style with confidence through carefully curated, trendy, and sustainable fashion pieces delivered right to their doorstep in India.</p>
        <h4>Quality & Trust</h4>
        <p>Every garment offered on Trendy Wear undergoes rigorous quality inspection. We take pride in delivering premium fabrics, transparent pricing in Indian Rupees (₹), and fast nationwide shipping.</p>
    </div>
</asp:Content>
