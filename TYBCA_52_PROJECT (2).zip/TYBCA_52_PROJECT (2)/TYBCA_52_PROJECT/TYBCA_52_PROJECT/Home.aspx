<%@ Page Title="Trendy Wear - Online Shopping for Men, Women & Kids" Language="VB" MasterPageFile="~/navbar.Master" AutoEventWireup="false" CodeBehind="Home.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm9" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <script src="<%= ResolveUrl("~/Content/js/slider.js") %>?v=1" defer="defer"></script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <!-- Home page image slideshow -->
    <div class="fk-container mt-3 mb-4">
        <section class="tw-home-slider" data-home-slider role="region" aria-roledescription="carousel" aria-label="Trendy Wear featured collections" tabindex="0">
            <div class="tw-home-slide" role="group" aria-roledescription="slide" aria-label="1 of 5" aria-hidden="false">
                <img src="<%= ResolveUrl("~/Images/p9.jpeg") %>?v=3" alt="A curated rail of new Trendy Wear clothing" onerror="this.onerror=null;this.src='Images/default.jpg';" />
                <div class="tw-home-slide-content">
                    <span class="fk-badge-gold">The Trendy Wear Edit</span>
                    <h1>Find your feel-good fit</h1>
                    <p>Fresh looks, trusted quality, and free shipping on orders over Rs 500. Make every day your kind of style.</p>
                    <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-buy tw-slide-cta">Shop all styles <span aria-hidden="true">&rarr;</span></a>
                </div>
            </div>

            <div class="tw-home-slide" role="group" aria-roledescription="slide" aria-label="2 of 5" aria-hidden="true">
                <img src="<%= ResolveUrl("~/Images/men.jpg") %>?v=3" alt="Men's clothing collection" onerror="this.onerror=null;this.src='Images/default.jpg';" />
                <div class="tw-home-slide-content">
                    <span class="fk-badge-gold">New season for him</span>
                    <h2>Made for your everyday</h2>
                    <p>Easy layers, sharp staples, and comfortable fits to take you from the weekday to the weekend.</p>
                    <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Men") %>" class="fk-btn fk-btn-buy tw-slide-cta">Explore men's wear <span aria-hidden="true">&rarr;</span></a>
                </div>
            </div>

            <div class="tw-home-slide" role="group" aria-roledescription="slide" aria-label="3 of 5" aria-hidden="true">
                <img src="<%= ResolveUrl("~/Images/women.jpg") %>?v=3" alt="Women's clothing collection" onerror="this.onerror=null;this.src='Images/default.jpg';" />
                <div class="tw-home-slide-content">
                    <span class="fk-badge-gold">New arrivals</span>
                    <h2>Your style, your way</h2>
                    <p>Discover polished favourites and standout pieces, selected for quality, comfort, and confidence.</p>
                    <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Women") %>" class="fk-btn fk-btn-buy tw-slide-cta">Shop women's wear <span aria-hidden="true">&rarr;</span></a>
                </div>
            </div>

            <div class="tw-home-slide" role="group" aria-roledescription="slide" aria-label="4 of 5" aria-hidden="true">
                <img src="<%= ResolveUrl("~/Images/kids.jpg") %>?v=3" alt="Kids' clothing collection" onerror="this.onerror=null;this.src='Images/default.jpg';" />
                <div class="tw-home-slide-content">
                    <span class="fk-badge-gold">Little looks, big days</span>
                    <h2>Ready for every adventure</h2>
                    <p>Soft, durable styles for play, parties, and all the moments in between—with easy 7-day returns.</p>
                    <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Kids") %>" class="fk-btn fk-btn-buy tw-slide-cta">Explore kids' wear <span aria-hidden="true">&rarr;</span></a>
                </div>
            </div>

            <div class="tw-home-slide" role="group" aria-roledescription="slide" aria-label="5 of 5" aria-hidden="true">
                <img src="<%= ResolveUrl("~/Uploads/Products/women/03.jpg") %>?v=3" alt="A featured women's outfit from the latest collection" onerror="this.onerror=null;this.src='Images/default.jpg';" />
                <div class="tw-home-slide-content">
                    <span class="fk-badge-gold">A little something new</span>
                    <h2>Good style is just around the corner</h2>
                    <p>Browse fresh finds across the collection, with dependable delivery and simple returns.</p>
                    <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-buy tw-slide-cta">See what's new <span aria-hidden="true">&rarr;</span></a>
                </div>
            </div>

            <div class="tw-slider-controls">
                <button type="button" class="tw-slider-arrow" data-slider-prev aria-label="Previous slide">&#8249;</button>
                <div class="tw-slider-dots" role="group" aria-label="Choose a slide">
                    <button type="button" class="tw-slider-dot" data-slider-dot="0" aria-label="Show slide 1" aria-pressed="true"></button>
                    <button type="button" class="tw-slider-dot" data-slider-dot="1" aria-label="Show slide 2" aria-pressed="false"></button>
                    <button type="button" class="tw-slider-dot" data-slider-dot="2" aria-label="Show slide 3" aria-pressed="false"></button>
                    <button type="button" class="tw-slider-dot" data-slider-dot="3" aria-label="Show slide 4" aria-pressed="false"></button>
                    <button type="button" class="tw-slider-dot" data-slider-dot="4" aria-label="Show slide 5" aria-pressed="false"></button>
                </div>
                <button type="button" class="tw-slider-arrow" data-slider-next aria-label="Next slide">&#8250;</button>
            </div>
        </section>
    </div>

    <!-- About the store -->
    <section class="fk-container mb-5" aria-labelledby="home-about-title">
        <div class="tw-home-about fk-card">
            <div class="fk-card-header"><div><span class="tw-about-eyebrow">A little about us</span><h2 id="home-about-title" class="fk-card-title">About Trendy Wear</h2></div></div>
            <div class="fk-card-body">
                <p class="tw-about-copy">Trendy Wear brings together thoughtful fashion for men, women, and kids. We focus on comfortable fits, dependable quality, and styles you can reach for again and again. Enjoy fast delivery, free shipping on orders over Rs 500, and easy 7-day returns—so finding your next favourite feels simple.</p>
                <div class="tw-about-highlights">
                    <div class="tw-about-highlight"><span aria-hidden="true">✦</span><div><strong>Carefully chosen</strong><small>Styles for every day and every occasion</small></div></div>
                    <div class="tw-about-highlight"><span aria-hidden="true">✓</span><div><strong>Quality you can feel</strong><small>Comfortable materials and considered details</small></div></div>
                    <div class="tw-about-highlight"><span aria-hidden="true">↗</span><div><strong>Fast, reliable delivery</strong><small>Your new favourites, on their way</small></div></div>
                    <div class="tw-about-highlight"><span aria-hidden="true">↺</span><div><strong>Easy 7-day returns</strong><small>Shop with a little more peace of mind</small></div></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Perks Strip -->
    <div class="fk-container mb-4">
        <div class="perks-strip">
            <div class="perk-item">
                <span class="perk-icon">🚚</span>
                <div>
                    <strong>Free Delivery</strong>
                    <small>On orders above Rs 500</small>
                </div>
            </div>
            <div class="perk-item">
                <span class="perk-icon">💵</span>
                <div>
                    <strong>Cash on Delivery</strong>
                    <small>Pay when product arrives</small>
                </div>
            </div>
            <div class="perk-item">
                <span class="perk-icon">🔄</span>
                <div>
                    <strong>Easy 7-Day Returns</strong>
                    <small>No questions asked policy</small>
                </div>
            </div>
            <div class="perk-item">
                <span class="perk-icon">🔒</span>
                <div>
                    <strong>100% Genuine</strong>
                    <small>Guaranteed authentic quality</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Grid Tiles -->
    <div class="fk-container mb-5">
        <h2 class="section-heading mb-3">Shop By Category</h2>
        <div class="category-grid">
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Men") %>" class="cat-tile">
                <div class="cat-img-wrap">
                    <img src="<%= ResolveUrl("~/Images/men.jpg") %>" alt="Men's Fashion" onerror="this.src='Images/default.jpg';" />
                </div>
                <div class="cat-info">
                    <h3>Men's Collection</h3>
                    <span class="cat-link">Up to 50% OFF &rarr;</span>
                </div>
            </a>

            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Women") %>" class="cat-tile">
                <div class="cat-img-wrap">
                    <img src="<%= ResolveUrl("~/Images/women.jpg") %>" alt="Women's Fashion" onerror="this.src='Images/default.jpg';" />
                </div>
                <div class="cat-info">
                    <h3>Women's Collection</h3>
                    <span class="cat-link">Up to 60% OFF &rarr;</span>
                </div>
            </a>

            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Kids") %>" class="cat-tile">
                <div class="cat-img-wrap">
                    <img src="<%= ResolveUrl("~/Images/kids.jpg") %>" alt="Kids Wear" onerror="this.src='Images/default.jpg';" />
                </div>
                <div class="cat-info">
                    <h3>Kids Wear</h3>
                    <span class="cat-link">Flat 40% OFF &rarr;</span>
                </div>
            </a>
        </div>
    </div>

    <!-- Deals of the Day Grid -->
    <div class="fk-container mb-5">
        <div class="flex-between align-center mb-3">
            <div>
                <h2 class="section-heading m-0">✨ Featured Products</h2>
                <p class="fk-text-muted text-sm m-0">A handpicked selection from the Trendy Wear collection</p>
            </div>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-outline-primary text-sm">Explore All Products &rarr;</a>
        </div>

        <div class="product-grid home-product-grid">
            <asp:Repeater ID="rptDeals" runat="server" OnItemCommand="rptProducts_ItemCommand">
                <ItemTemplate>
                    <div class="fk-product-card">
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                            <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) & "?v=2" %>' 
                                 alt='<%# Eval("p_name") %>' class="product-img" onerror="this.src='Images/default.jpg';" />
                            <span class="discount-badge"><%# GetDiscountPercentage(Eval("price"), Eval("OldPrice")) %>% OFF</span>
                        </a>

                        <div class="card-body">
                            <span class="product-cat"><%# Eval("category_name") %></span>
                            <h3 class="product-name">
                                <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%# Eval("p_name") %></a>
                            </h3>

                            <div class="price-row">
                                <span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                                <span class="old-price">Rs <%# String.Format("{0:N0}", Eval("OldPrice")) %></span>
                            </div>
                            <div class="fk-text-warning text-sm mb-2"><%# GetRatingSummary(Eval("AverageRating"), Eval("ReviewCount")) %></div>

                            <div class="stock-status mb-2">
                                <span class='<%# GetStockClass(Eval("Stock")) %>'>
                                    <%# GetStockText(Eval("Stock")) %>
                                </span>
                            </div>

                            <div class="card-actions">
                                <asp:LinkButton ID="btnAddToCart" runat="server" CommandName="AddToCart" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-cart flex-1">
                                    🛒 Add
                                </asp:LinkButton>
                                <asp:LinkButton ID="btnBuyNow" runat="server" CommandName="BuyNow" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-buy flex-1">
                                    ⚡ Buy Now
                                </asp:LinkButton>
                            </div>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>

    <!-- New Arrivals Grid -->
    <div class="fk-container mb-5">
        <div class="flex-between align-center mb-3">
            <div>
                <h2 class="section-heading m-0">✨ New Arrivals</h2>
                <p class="fk-text-muted text-sm m-0">Fresh fashion styles just added to the store</p>
            </div>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-outline-primary text-sm">Explore All &rarr;</a>
        </div>

        <div class="product-grid home-product-grid">
            <asp:Repeater ID="rptNewArrivals" runat="server" OnItemCommand="rptProducts_ItemCommand">
                <ItemTemplate>
                    <div class="fk-product-card">
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                            <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) & "?v=2" %>' 
                                 alt='<%# Eval("p_name") %>' class="product-img" onerror="this.src='Images/default.jpg';" />
                        </a>

                        <div class="card-body">
                            <span class="product-cat"><%# Eval("category_name") %></span>
                            <h3 class="product-name">
                                <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%# Eval("p_name") %></a>
                            </h3>

                            <div class="price-row">
                                <span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                                <span class="old-price">Rs <%# String.Format("{0:N0}", Eval("OldPrice")) %></span>
                            </div>
                            <div class="fk-text-warning text-sm mb-2"><%# GetRatingSummary(Eval("AverageRating"), Eval("ReviewCount")) %></div>

                            <div class="stock-status mb-2">
                                <span class='<%# GetStockClass(Eval("Stock")) %>'>
                                    <%# GetStockText(Eval("Stock")) %>
                                </span>
                            </div>

                            <div class="card-actions">
                                <asp:LinkButton ID="btnAddToCart" runat="server" CommandName="AddToCart" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-cart flex-1">
                                    🛒 Add
                                </asp:LinkButton>
                                <asp:LinkButton ID="btnBuyNow" runat="server" CommandName="BuyNow" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-buy flex-1">
                                    ⚡ Buy Now
                                </asp:LinkButton>
                            </div>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>

    <div class="fk-container mb-5">
        <div class="flex-between align-center mb-3">
            <div>
                <h2 class="section-heading m-0">⭐ Top Rated</h2>
                <p class="fk-text-muted text-sm m-0">Customer favourites, based on approved reviews</p>
            </div>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?sort=rating") %>" class="fk-btn fk-btn-outline-primary text-sm">Browse top rated &rarr;</a>
        </div>
        <div class="product-grid home-product-grid">
            <asp:Repeater ID="rptTopRated" runat="server" OnItemCommand="rptProducts_ItemCommand">
                <ItemTemplate>
                    <div class="fk-product-card">
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                            <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) & "?v=2" %>'
                                 alt='<%# Eval("p_name") %>' class="product-img" onerror="this.src='Images/default.jpg';" />
                        </a>
                        <div class="card-body">
                            <h3 class="product-name"><a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%#: Eval("p_name") %></a></h3>
                            <div class="fk-text-warning text-sm mb-2"><%# GetRatingSummary(Eval("AverageRating"), Eval("ReviewCount")) %></div>
                            <div class="price-row"><span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span></div>
                            <div class="card-actions">
                                <asp:LinkButton runat="server" CommandName="AddToCart" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-cart flex-1">🛒 Add</asp:LinkButton>
                                <asp:LinkButton runat="server" CommandName="BuyNow" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn fk-btn-buy flex-1">⚡ Buy Now</asp:LinkButton>
                            </div>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>
</asp:Content>
