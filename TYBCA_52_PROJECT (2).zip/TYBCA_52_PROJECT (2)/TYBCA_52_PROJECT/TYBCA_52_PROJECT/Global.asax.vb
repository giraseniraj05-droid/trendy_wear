Imports System.Web
Imports System.Web.UI
Imports System.Configuration
Imports TYBCA_52_PROJECT.Helpers

Public Class Global_asax
    Inherits HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Initialize Application state and database schema automatically
        Db.EnsureSchema()
    End Sub

    Sub Application_PreRequestHandlerExecute(ByVal sender As Object, ByVal e As EventArgs)
        Dim page As Page = TryCast(Context.CurrentHandler, Page)
        If page IsNot Nothing AndAlso Context.Session IsNot Nothing Then
            page.ViewStateUserKey = Context.Session.SessionID
        End If
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' HTTPS redirection is opt-in so it can be enabled after the hosting
        ' provider has installed a valid certificate and HTTPS binding.
        Dim forceHttps As Boolean
        Boolean.TryParse(ConfigurationManager.AppSettings("ForceHttps"), forceHttps)
        If Not forceHttps OrElse Request.IsSecureConnection Then Return

        Dim httpsHost As String = ConfigurationManager.AppSettings("CanonicalHttpsHost")
        If String.IsNullOrWhiteSpace(httpsHost) OrElse Uri.CheckHostName(httpsHost) = UriHostNameType.Unknown Then Return

        Response.StatusCode = 301
        Response.RedirectLocation = "https://" & httpsHost & Request.RawUrl
        Context.ApplicationInstance.CompleteRequest()
    End Sub

    Sub Application_EndRequest(ByVal sender As Object, ByVal e As EventArgs)
        If Not Request.IsSecureConnection Then Return

        ' Make cookies issued on HTTPS requests secure even if the app is still
        ' accepting HTTP while the host certificate is being configured.
        For Each cookieName As String In Response.Cookies.AllKeys
            Dim cookie As HttpCookie = Response.Cookies(cookieName)
            If cookie IsNot Nothing Then cookie.Secure = True
        Next

        Dim forceHttps As Boolean
        Boolean.TryParse(ConfigurationManager.AppSettings("ForceHttps"), forceHttps)
        If forceHttps Then Response.Headers("Strict-Transport-Security") = "max-age=86400"
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        Session("Cart") = New System.Collections.Generic.Dictionary(Of String, Integer)()
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        Dim lastError As Exception = Server.GetLastError()
        If lastError IsNot Nothing Then
            Logger.LogException(lastError, "Global Application_Error")
        End If
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
    End Sub
End Class
