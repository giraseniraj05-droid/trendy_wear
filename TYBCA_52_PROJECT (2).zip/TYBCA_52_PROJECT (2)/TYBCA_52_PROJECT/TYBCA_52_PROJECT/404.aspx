<%@ Page Title="Page Not Found" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="error-page-container error-glass-card">
        <div class="error-code">404</div>
        <h2 class="error-title">Oops! Page Not Found</h2>
        <p class="error-desc">The page you are looking for might have been removed or is temporarily unavailable.</p>
        <a href='<%= ResolveUrl("~/Home.aspx") %>' class="btn-tw-primary error-home-button">Return to Home</a>
    </div>
</asp:Content>
