<%@ Page Title="Sign In to Trendy Wear" Language="VB" MasterPageFile="~/navbar.Master" AutoEventWireup="false" CodeBehind="login.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm10" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="auth-container">
        <div class="fk-card auth-card">
            <!-- Left Banner -->
            <div class="auth-banner-col">
                <h2 class="auth-banner-title">Login</h2>
                <p class="auth-banner-sub">Get access to your Orders, Wishlist and Recommendations</p>
                <img src="<%= ResolveUrl("~/Images/default.jpg") %>" alt="Login Banner" class="auth-banner-img" />
            </div>

            <!-- Right Form -->
            <div class="auth-form-col">
                <div class="form-group mb-3">
                    <label class="form-label">Username or Email Address <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtUsername" runat="server" CssClass="fk-input" placeholder="Enter Username"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvUsername" runat="server" ControlToValidate="txtUsername" ErrorMessage="Username is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="LoginForm" />
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtPassword" runat="server" CssClass="fk-input" TextMode="Password" placeholder="Enter Password"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword" ErrorMessage="Password is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="LoginForm" />
                </div>

                <asp:Label ID="lblMsg" runat="server" CssClass="text-danger-sm display-block mb-3"></asp:Label>

                <div class="flex-between align-center mb-4">
                    <a href="<%= ResolveUrl("~/forgot_password.aspx") %>" class="fk-link text-xs">Forgot Password?</a>
                </div>

                <asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="fk-btn fk-btn-buy width-100 p-3 text-base font-bold mb-3" ValidationGroup="LoginForm" OnClick="btnLogin_Click" />

                <div class="text-center text-sm mt-3">
                    New to Trendy Wear? <a href="<%= ResolveUrl("~/register.aspx") %>" class="fk-link font-bold">Create an account</a>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
