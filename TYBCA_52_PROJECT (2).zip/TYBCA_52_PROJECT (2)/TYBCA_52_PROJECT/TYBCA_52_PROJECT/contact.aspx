<%@ Page Title="Contact Us" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" CodeBehind="contact.aspx.vb" Inherits="TYBCA_52_PROJECT.contact" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="contact-container contact-page"><div class="contact-info-card"><h2>We are here to help</h2><p>Our support team can help with orders, delivery, returns, and product questions.</p><div class="contact-info-line"><strong>Email</strong><span><a href="mailto:giraseniraj05@gmail.com">giraseniraj05@gmail.com</a></span></div><div class="contact-info-line"><strong>Phone</strong><span><a href="tel:+916352092774">+91 63520 92774</a></span></div><div class="contact-info-line"><strong>Hours</strong><span>Monday to Saturday</span></div></div><div class="contact-form-panel">
        <h2>Contact Us</h2>
        <p>Have questions? Send us a message and we'll reply shortly.</p>

        <asp:Label ID="lblMsg" runat="server" Visible="false"></asp:Label>

        <div class="form-group">
            <label>Name:</label>
            <asp:TextBox ID="txtName" runat="server" CssClass="form-control" Required="true"></asp:TextBox>
        </div>

        <div class="form-group">
            <label>Email:</label>
            <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" TextMode="Email" Required="true"></asp:TextBox>
        </div>

        <div class="form-group">
            <label>Subject:</label>
            <asp:TextBox ID="txtSubject" runat="server" CssClass="form-control"></asp:TextBox>
        </div>

        <div class="form-group">
            <label>Message:</label>
            <asp:TextBox ID="txtMessage" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="4" Required="true"></asp:TextBox>
        </div>

        <asp:Button ID="btnSend" runat="server" Text="Send Message" CssClass="btn-tw-primary" OnClick="btnSend_Click" />
    </div></div>
</asp:Content>
