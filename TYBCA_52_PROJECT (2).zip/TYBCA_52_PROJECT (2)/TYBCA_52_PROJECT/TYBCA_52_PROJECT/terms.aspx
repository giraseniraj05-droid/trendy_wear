<%@ Page Title="Terms & Conditions" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="terms-container info-content-panel">
        <h2>Terms & Conditions</h2>
        <p>By using Trendy Wear, you agree to comply with the following terms and conditions.</p>
        <hr />
        <h4>1. Orders & Pricing</h4>
        <p>All prices are quoted in Indian Rupees (₹). Orders are subject to stock availability and confirmation.</p>
        <h4>2. Shipping & Delivery</h4>
        <p>Delivery times vary based on shipping destination. Free shipping applies on eligible orders exceeding ₹999.</p>
        <h4>3. Returns & Cancellations</h4>
        <p>Orders can be cancelled while in 'Pending' status directly from the My Orders dashboard.</p>
    </div>
</asp:Content>
