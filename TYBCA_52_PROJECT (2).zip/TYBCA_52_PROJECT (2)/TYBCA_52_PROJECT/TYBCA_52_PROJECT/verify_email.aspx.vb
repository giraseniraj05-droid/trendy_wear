Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers

Public Class verify_email
    Inherits System.Web.UI.Page

    Private Property VerificationUserId As Integer
        Get
            Dim userId As Integer
            Integer.TryParse(Convert.ToString(Session("EmailVerificationUserID")), userId)
            Return userId
        End Get
        Set(ByVal value As Integer)
            Session("EmailVerificationUserID") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim loggedInId As Integer
            If Integer.TryParse(Convert.ToString(Session("UserID")), loggedInId) AndAlso loggedInId > 0 Then VerificationUserId = loggedInId
            If VerificationUserId <= 0 Then
                lblMessage.Text = "Register or log in to verify your email address."
                btnVerify.Enabled = False
                btnResend.Enabled = False
                Return
            End If
            Dim verified As Object = Db.ExecuteScalar("SELECT EmailVerified FROM register WHERE UserID = @UserID", Db.CreateParam("@UserID", SqlDbType.Int, VerificationUserId))
            If verified Is Nothing Then
                lblMessage.Text = "We could not find that account. Please log in again."
                btnVerify.Enabled = False
                btnResend.Enabled = False
            ElseIf Convert.ToBoolean(verified) Then
                lblMessage.Text = "Your email address is already verified."
                btnVerify.Enabled = False
                btnResend.Enabled = False
            Else
                UpdateResendState()
                If Convert.ToBoolean(If(Session("EmailVerificationSendFailed"), False)) Then
                    lblMessage.Text = "We could not deliver your verification email. Wait for the timer, then resend the code. If it still fails, contact the store."
                    Session.Remove("EmailVerificationSendFailed")
                End If
            End If
        End If
    End Sub

    Protected Sub btnVerify_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnVerify.Click
        If VerificationUserId <= 0 Then Return
        Try
            If EmailVerification.VerifyCode(VerificationUserId, txtCode.Text.Trim()) Then
                Dim verifiedUserId As Integer = VerificationUserId
                Dim safeReturnUrl As String = Convert.ToString(Session("RegistrationReturnUrl"))
                If Not Security.IsLocalReturnUrl(safeReturnUrl) Then safeReturnUrl = ""
                Session.Remove("EmailVerificationUserID")
                Session.Remove("RegistrationReturnUrl")
                Dim loggedInId As Integer
                If Integer.TryParse(Convert.ToString(Session("UserID")), loggedInId) AndAlso loggedInId = verifiedUserId Then
                    Response.Redirect(If(String.IsNullOrEmpty(safeReturnUrl), "~/Home.aspx", safeReturnUrl), False)
                    Context.ApplicationInstance.CompleteRequest()
                    Return
                End If
                If Not String.IsNullOrEmpty(safeReturnUrl) Then
                    Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode(safeReturnUrl), False)
                    Context.ApplicationInstance.CompleteRequest()
                    Return
                End If
                lblMessage.Text = "Your email address is verified. You can now log in."
                btnVerify.Enabled = False
                btnResend.Enabled = False
            Else
                lblMessage.Text = "That code is invalid or expired. Check the code or request a new one."
            End If
        Catch ex As Exception
            Logger.LogError("Email code verification error", ex)
            lblMessage.Text = "We could not verify your email right now. Please try again."
        End Try
    End Sub

    Protected Sub btnResend_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnResend.Click
        If VerificationUserId <= 0 Then Return
        Try
            Dim user As DataTable = Db.ExecuteQuery("SELECT Username, Email, EmailVerified FROM register WHERE UserID = @UserID",
                                                    Db.CreateParam("@UserID", SqlDbType.Int, VerificationUserId))
            If user.Rows.Count = 0 OrElse Convert.ToBoolean(user.Rows(0)("EmailVerified")) Then
                lblMessage.Text = "This account is already verified or could not be found."
                btnResend.Enabled = False
                Return
            End If
            Dim sent As Boolean = EmailVerification.SendVerificationEmail(VerificationUserId,
                                                                          Convert.ToString(user.Rows(0)("Username")),
                                                                          Convert.ToString(user.Rows(0)("Email")))
            lblMessage.Text = If(sent, "A new six-digit code has been sent to your email.",
                                 "Please wait 60 seconds between code requests.")
            UpdateResendState()
        Catch ex As Exception
            Logger.LogError("Error resending email verification code", ex)
            Session("EmailVerificationSendFailed") = True
            lblMessage.Text = "We could not deliver a new code. Please wait for the timer, then try again."
            Try
                UpdateResendState()
            Catch stateEx As Exception
                Logger.LogError("Error updating verification resend cooldown", stateEx)
            End Try
        End Try
    End Sub

    Private Sub UpdateResendState()
        Dim remaining As Integer = Convert.ToInt32(Db.ExecuteScalar(
            "SELECT ISNULL((SELECT TOP 1 CASE WHEN DATEDIFF(second, CreatedAt, GETDATE()) >= 60 THEN 0 ELSE 60 - DATEDIFF(second, CreatedAt, GETDATE()) END FROM EmailVerificationTokens WHERE UserID = @UserID ORDER BY CreatedAt DESC), 0)",
            Db.CreateParam("@UserID", SqlDbType.Int, VerificationUserId)))
        btnResend.Enabled = (remaining <= 0)
        If remaining > 0 Then lblCooldown.Text = "You can resend a code in " & remaining.ToString() & " seconds."
    End Sub
End Class
