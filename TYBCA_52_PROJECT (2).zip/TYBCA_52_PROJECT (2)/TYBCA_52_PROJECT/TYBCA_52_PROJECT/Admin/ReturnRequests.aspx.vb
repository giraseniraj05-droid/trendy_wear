Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminReturnRequests
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx")
            Return
        End If
        If Not IsPostBack Then BindRequests()
    End Sub

    Private Sub BindRequests()
        gvRequests.DataSource = Db.ExecuteQuery("SELECT rr.ReturnRequestID, rr.OrderID, r.Username AS CustomerName, r.Email, rr.CreatedAt, rr.Reason, rr.RequestStatus FROM OrderReturnRequests rr INNER JOIN register r ON r.UserID = rr.UserID ORDER BY CASE WHEN rr.RequestStatus = 'Pending' THEN 0 ELSE 1 END, rr.CreatedAt DESC")
        gvRequests.DataBind()
    End Sub

    Protected Sub gvRequests_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName <> "ApproveRequest" AndAlso e.CommandName <> "RejectRequest" Then Return
        Dim requestId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), requestId) Then Return
        Dim decision As String = If(e.CommandName = "ApproveRequest", "Approved", "Rejected")
        Try
            Using connection As SqlConnection = Db.GetConnection()
                Using transaction As SqlTransaction = connection.BeginTransaction()
                    Dim orderId As Integer
                    Dim userId As Integer
                    Dim requestFound As Boolean = False
                    Using command As New SqlCommand("SELECT OrderID, UserID FROM OrderReturnRequests WITH (UPDLOCK, ROWLOCK) WHERE ReturnRequestID = @RequestID AND RequestStatus = 'Pending'", connection, transaction)
                        command.Parameters.Add(Db.CreateParam("@RequestID", SqlDbType.Int, requestId))
                        Using reader As SqlDataReader = command.ExecuteReader()
                            If reader.Read() Then
                                orderId = Convert.ToInt32(reader("OrderID"))
                                userId = Convert.ToInt32(reader("UserID"))
                                requestFound = True
                            End If
                        End Using
                    End Using
                    If Not requestFound Then
                        transaction.Rollback()
                        lblMessage.Text = "This request has already been processed."
                        Return
                    End If
                    Using updateRequest As New SqlCommand("UPDATE OrderReturnRequests SET RequestStatus = @Status, UpdatedAt = GETDATE() WHERE ReturnRequestID = @RequestID AND RequestStatus = 'Pending'", connection, transaction)
                        updateRequest.Parameters.Add(Db.CreateParam("@Status", SqlDbType.NVarChar, decision, 20))
                        updateRequest.Parameters.Add(Db.CreateParam("@RequestID", SqlDbType.Int, requestId))
                        updateRequest.ExecuteNonQuery()
                    End Using
                    If decision = "Approved" Then
                        Using refund As New SqlCommand("UPDATE orders SET PaymentStatus = 'Refunded' WHERE OrderID = @OrderID", connection, transaction)
                            refund.Parameters.Add(Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                            refund.ExecuteNonQuery()
                        End Using
                    End If
                    transaction.Commit()
                    SendDecisionEmail(userId, orderId, decision)
                End Using
            End Using
            lblMessage.Text = "Request " & decision.ToLowerInvariant() & ". The customer was emailed."
            BindRequests()
        Catch ex As Exception
            Logger.LogError("Error processing return request", ex)
            lblMessage.Text = "The request could not be processed. Please try again."
        End Try
    End Sub

    Private Sub SendDecisionEmail(ByVal userId As Integer, ByVal orderId As Integer, ByVal decision As String)
        Dim customer As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE UserID = @UserID",
                                                    Db.CreateParam("@UserID", SqlDbType.Int, userId))
        If customer.Rows.Count = 0 Then Return
        Dim name As String = HttpUtility.HtmlEncode(Convert.ToString(customer.Rows(0)("Username")))
        Dim message As String = If(decision = "Approved",
                                   "Your request was approved and the order payment status is now refunded.",
                                   "Your request was not approved. Contact support if you need help.")
        Mailer.SendAsync(Convert.ToString(customer.Rows(0)("Email")), "Return request " & decision.ToLowerInvariant() & " for order #" & orderId.ToString(),
                         Mailer.Wrap("Return request " & decision.ToLowerInvariant(), "<p>Hello " & name & ",</p><p>" & message & "</p><p>Order #" & orderId.ToString() & "</p>"),
                         "ReturnRequestDecision")
    End Sub
End Class
