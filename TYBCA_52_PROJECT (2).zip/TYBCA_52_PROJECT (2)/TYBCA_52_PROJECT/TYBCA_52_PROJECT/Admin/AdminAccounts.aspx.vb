Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail
Imports System.Text.RegularExpressions
Imports System.Web.Security
Imports TYBCA_52_PROJECT.Helpers

    Public Partial Class AdminAccounts
        Inherits System.Web.UI.Page

        Private Const TokenSessionKey As String = "AdminAccountsPostToken"

        Protected Sub Page_Init(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Init
            ViewStateUserKey = If(Session IsNot Nothing, Convert.ToString(Session.SessionID), String.Empty)
        End Sub

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
            If Not IsAdmin() Then
                Response.Redirect("~/login.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
                Return
            End If

            If Not IsPostBack Then
                RotateRequestToken()
                LoadMyAccount()
                LoadAdmins()
            End If
        End Sub

        Private Function IsAdmin() As Boolean
            Return String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase) AndAlso Session("UserID") IsNot Nothing
        End Function

        Private Function CurrentUserId() As Integer
            Return Convert.ToInt32(Session("UserID"))
        End Function

        Private Sub RotateRequestToken()
            Dim token As String = Guid.NewGuid().ToString("N")
            Session(TokenSessionKey) = token
            hfRequestToken.Value = token
        End Sub

        Private Function ConsumeRequestToken() As Boolean
            Dim sessionToken As String = Convert.ToString(Session(TokenSessionKey))
            Dim postedToken As String = hfRequestToken.Value
            If String.IsNullOrEmpty(sessionToken) OrElse String.IsNullOrEmpty(postedToken) OrElse Not String.Equals(sessionToken, postedToken, StringComparison.Ordinal) Then
                RotateRequestToken()
                ShowMessage("This request has expired. Please submit again.", True)
                Return False
            End If
            RotateRequestToken()
            Return True
        End Function

        Private Sub ShowMessage(ByVal message As String, ByVal isError As Boolean)
            Toast.ShowMessage(Me, message, If(isError, Helpers.ToastType.Error, Helpers.ToastType.Success), lblMsg)
        End Sub

        Private Sub LoadMyAccount()
            Try
                Dim dt As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", Db.CreateParam("@id", SqlDbType.Int, CurrentUserId()))
                If dt.Rows.Count = 1 Then
                    txtMyUsername.Text = Convert.ToString(dt.Rows(0)("Username"))
                    txtMyEmail.Text = Convert.ToString(dt.Rows(0)("Email"))
                End If
            Catch
                ShowMessage("Could not load your account details.", True)
            End Try
        End Sub

        Private Sub LoadAdmins()
            Try
                Dim dt As DataTable = Db.ExecuteQuery("SELECT UserID, Username, FullName, Email, IsActive, CASE WHEN IsActive=1 THEN 'Active' ELSE 'Inactive' END AS ActiveState, CreatedOn, LastLogin FROM register WHERE LOWER(ISNULL(Role,''))='admin' ORDER BY UserID")
                gvAdmins.DataSource = dt
                gvAdmins.DataBind()
            Catch
                ShowMessage("Could not load administrator accounts. Run the supplied database upgrade script, then retry.", True)
            End Try
        End Sub

        Private Function ValidEmail(ByVal email As String) As Boolean
            Try
                Dim address As New MailAddress(email)
                Return String.Equals(address.Address, email, StringComparison.OrdinalIgnoreCase)
            Catch
                Return False
            End Try
        End Function

        Private Function StrongPassword(ByVal password As String) As Boolean
            Return password IsNot Nothing AndAlso Regex.IsMatch(password, "^(?=.*[A-Za-z])(?=.*\d).{8,}$")
        End Function

        Private Function IsUnique(ByVal conn As SqlConnection, ByVal tx As SqlTransaction, ByVal columnName As String, ByVal value As String, ByVal excludedUserId As Integer) As Boolean
            Dim sql As String = "SELECT COUNT(*) FROM register WHERE " & columnName & "=@value AND UserID<>@id"
            Using cmd As New SqlCommand(sql, conn, tx)
                cmd.Parameters.Add("@value", SqlDbType.NVarChar, If(columnName = "Email", 255, 100)).Value = value
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = excludedUserId
                Return Convert.ToInt32(cmd.ExecuteScalar()) = 0
            End Using
        End Function

        Private Function IsUnique(ByVal conn As SqlConnection, ByVal tx As SqlTransaction, ByVal columnName As String, ByVal value As String) As Boolean
            Return IsUnique(conn, tx, columnName, value, 0)
        End Function

        Private Sub WriteAudit(ByVal conn As SqlConnection, ByVal tx As SqlTransaction, ByVal action As String, ByVal details As String)
            Const sql As String = "INSERT INTO AuditLog (UserID, Username, Action, Details, IpAddress, [Timestamp]) VALUES (@uid, @username, @action, @details, @ip, GETDATE())"
            Using cmd As New SqlCommand(sql, conn, tx)
                cmd.Parameters.Add("@uid", SqlDbType.Int).Value = CurrentUserId()
                cmd.Parameters.Add("@username", SqlDbType.NVarChar, 100).Value = Convert.ToString(Session("username"))
                cmd.Parameters.Add("@action", SqlDbType.NVarChar, 255).Value = action
                cmd.Parameters.Add("@details", SqlDbType.NVarChar).Value = details
                cmd.Parameters.Add("@ip", SqlDbType.NVarChar, 50).Value = If(Request.UserHostAddress, String.Empty)
                cmd.ExecuteNonQuery()
            End Using
        End Sub

        Protected Sub btnAddAdmin_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Not IsAdmin() OrElse Not ConsumeRequestToken() Then Return
            Dim fullName As String = txtNewFullName.Text.Trim()
            Dim username As String = txtNewUsername.Text.Trim()
            Dim email As String = txtNewEmail.Text.Trim()
            Dim mobile As String = txtNewMobile.Text.Trim()
            Dim password As String = txtNewPassword.Text
            If fullName.Length = 0 OrElse username.Length = 0 OrElse email.Length = 0 OrElse mobile.Length = 0 OrElse password.Length = 0 Then
                ShowMessage("Complete all fields to create an administrator.", True)
            ElseIf Not ValidEmail(email) Then
                ShowMessage("Enter a valid email address.", True)
            ElseIf Not StrongPassword(password) Then
                ShowMessage("Password must be at least 8 characters and include a letter and a number.", True)
            ElseIf Not String.Equals(password, txtNewConfirmPassword.Text, StringComparison.Ordinal) Then
                ShowMessage("The passwords do not match.", True)
            Else
                Try
                    Dim salt As String = Security.GenerateSalt()
                    Dim passwordHash As String = Security.HashPassword(password, salt)
                    Using conn As SqlConnection = Db.GetConnection()
                        Using tx As SqlTransaction = conn.BeginTransaction(IsolationLevel.Serializable)
                            If Not IsUnique(conn, tx, "Username", username) OrElse Not IsUnique(conn, tx, "Email", email) Then
                                tx.Rollback()
                                ShowMessage("That username or email is already in use.", True)
                                Return
                            End If
                            Using cmd As New SqlCommand("INSERT INTO register (Username, Password, PasswordHash, Salt, Email, EmailVerified, Mobileno, FullName, Role, IsActive, CreatedOn) VALUES (@username, '', @hash, @salt, @email, 1, @mobile, @name, 'Admin', 1, GETDATE())", conn, tx)
                                cmd.Parameters.Add("@username", SqlDbType.NVarChar, 100).Value = username
                                cmd.Parameters.Add("@hash", SqlDbType.NVarChar, 255).Value = passwordHash
                                cmd.Parameters.Add("@salt", SqlDbType.NVarChar, 255).Value = salt
                                cmd.Parameters.Add("@email", SqlDbType.NVarChar, 255).Value = email
                                cmd.Parameters.Add("@mobile", SqlDbType.NVarChar, 15).Value = mobile
                                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 100).Value = fullName
                                cmd.ExecuteNonQuery()
                            End Using
                            WriteAudit(conn, tx, "Admin created", "A new administrator account was created.")
                            tx.Commit()
                        End Using
                    End Using
                    txtNewFullName.Text = "" : txtNewUsername.Text = "" : txtNewEmail.Text = "" : txtNewMobile.Text = ""
                    txtNewPassword.Text = "" : txtNewConfirmPassword.Text = ""
                    ShowMessage("Administrator account created.", False)
                    LoadAdmins()
                Catch
                    ShowMessage("Could not create the administrator. Check for duplicate username or email and try again.", True)
                End Try
            End If
            LoadAdmins()
        End Sub

        Protected Sub btnSaveMyAccount_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Not IsAdmin() OrElse Not ConsumeRequestToken() Then Return
            Dim username As String = txtMyUsername.Text.Trim()
            Dim email As String = txtMyEmail.Text.Trim()
            Dim newPassword As String = txtMyNewPassword.Text
            If username.Length = 0 OrElse email.Length = 0 Then
                ShowMessage("Username and email are required.", True) : Return
            End If
            If Not ValidEmail(email) Then
                ShowMessage("Enter a valid email address.", True) : Return
            End If
            If newPassword.Length > 0 AndAlso (Not StrongPassword(newPassword) OrElse Not String.Equals(newPassword, txtMyConfirmPassword.Text, StringComparison.Ordinal)) Then
                ShowMessage("Use a password of at least 8 characters with a letter and number, and confirm it correctly.", True) : Return
            End If
            If newPassword.Length = 0 AndAlso txtCurrentPassword.Text.Length > 0 Then
                ShowMessage("Enter a new password and confirmation, or clear the current password field.", True) : Return
            End If

            Try
                Using conn As SqlConnection = Db.GetConnection()
                    Using tx As SqlTransaction = conn.BeginTransaction(IsolationLevel.Serializable)
                        Dim id As Integer = CurrentUserId()
                        If Not IsUnique(conn, tx, "Username", username, id) OrElse Not IsUnique(conn, tx, "Email", email, id) Then
                            tx.Rollback() : ShowMessage("That username or email is already in use.", True) : Return
                        End If
                        If newPassword.Length > 0 Then
                            Dim storedHash As String = "" : Dim storedSalt As String = ""
                            Using checkCmd As New SqlCommand("SELECT PasswordHash, Salt FROM register WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin' AND IsActive=1", conn, tx)
                                checkCmd.Parameters.Add("@id", SqlDbType.Int).Value = id
                                Using reader As SqlDataReader = checkCmd.ExecuteReader()
                                    If Not reader.Read() Then
                                        reader.Close() : tx.Rollback() : ShowMessage("Your administrator account is unavailable.", True) : Return
                                    End If
                                    storedHash = If(reader.IsDBNull(0), "", reader.GetString(0))
                                    storedSalt = If(reader.IsDBNull(1), "", reader.GetString(1))
                                End Using
                            End Using
                            If storedHash.Length = 0 OrElse storedSalt.Length = 0 OrElse Not Security.VerifyPassword(txtCurrentPassword.Text, storedHash, storedSalt) Then
                                tx.Rollback() : ShowMessage("The current password is incorrect. Sign in once first if this legacy account has not yet upgraded to a secure password.", True) : Return
                            End If
                        End If
                        Using cmd As New SqlCommand("UPDATE register SET Username=@username, Email=@email WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", conn, tx)
                            cmd.Parameters.Add("@username", SqlDbType.NVarChar, 100).Value = username
                            cmd.Parameters.Add("@email", SqlDbType.NVarChar, 255).Value = email
                            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id
                            cmd.ExecuteNonQuery()
                        End Using
                        If newPassword.Length > 0 Then
                            Dim salt As String = Security.GenerateSalt()
                            Dim hash As String = Security.HashPassword(newPassword, salt)
                            Using cmd As New SqlCommand("UPDATE register SET Password='', PasswordHash=@hash, Salt=@salt WHERE UserID=@id", conn, tx)
                                cmd.Parameters.Add("@hash", SqlDbType.NVarChar, 255).Value = hash
                                cmd.Parameters.Add("@salt", SqlDbType.NVarChar, 255).Value = salt
                                cmd.Parameters.Add("@id", SqlDbType.Int).Value = id
                                cmd.ExecuteNonQuery()
                            End Using
                            WriteAudit(conn, tx, "Admin password changed", "An administrator changed their own password.")
                        End If
                        tx.Commit()
                    End Using
                End Using
                Session("username") = username
                Dim authCookie As HttpCookie = FormsAuthentication.GetAuthCookie(username, False)
                authCookie.Secure = Request.IsSecureConnection
                Response.Cookies.Add(authCookie)
                txtCurrentPassword.Text = "" : txtMyNewPassword.Text = "" : txtMyConfirmPassword.Text = ""
                ShowMessage("Your account details were saved.", False)
                LoadAdmins()
            Catch
                ShowMessage("Could not save your account details. Check for duplicate username or email and retry.", True)
            End Try
        End Sub

        Protected Sub gvAdmins_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
            If Not IsAdmin() Then Return
            Dim targetId As Integer
            If Not Integer.TryParse(Convert.ToString(e.CommandArgument), targetId) Then Return
            If e.CommandName = "EditAdmin" Then
                If targetId = CurrentUserId() Then
                    ShowMessage("Use My account to update your own details.", True) : Return
                End If
                Try
                    Dim dt As DataTable = Db.ExecuteQuery("SELECT FullName, Email FROM register WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", Db.CreateParam("@id", SqlDbType.Int, targetId))
                    If dt.Rows.Count = 1 Then
                        hfEditAdminId.Value = targetId.ToString()
                        txtEditFullName.Text = Convert.ToString(dt.Rows(0)("FullName"))
                        txtEditEmail.Text = Convert.ToString(dt.Rows(0)("Email"))
                        pnlEditAdmin.Visible = True : pnlResetPassword.Visible = False
                    End If
                Catch
                    ShowMessage("Could not load this administrator.", True)
                End Try
            ElseIf e.CommandName = "ResetAdmin" Then
                If targetId = CurrentUserId() Then
                    ShowMessage("Use My account to change your own password.", True) : Return
                End If
                hfResetAdminId.Value = targetId.ToString()
                txtResetPassword.Text = "" : txtResetConfirm.Text = ""
                pnlResetPassword.Visible = True : pnlEditAdmin.Visible = False
            ElseIf e.CommandName = "ToggleAdmin" Then
                If Not ConsumeRequestToken() Then Return
                ToggleAdmin(targetId)
            End If
        End Sub

        Protected Sub btnSaveEdit_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Not IsAdmin() OrElse Not ConsumeRequestToken() Then Return
            Dim targetId As Integer
            If Not Integer.TryParse(hfEditAdminId.Value, targetId) OrElse targetId = CurrentUserId() Then
                ShowMessage("Select another administrator to edit.", True) : Return
            End If
            Dim fullName As String = txtEditFullName.Text.Trim()
            Dim email As String = txtEditEmail.Text.Trim()
            If fullName.Length = 0 OrElse Not ValidEmail(email) Then
                ShowMessage("Enter a full name and valid email address.", True) : Return
            End If
            Try
                Using conn As SqlConnection = Db.GetConnection()
                    Using tx As SqlTransaction = conn.BeginTransaction(IsolationLevel.Serializable)
                        If Not IsUnique(conn, tx, "Email", email, targetId) Then
                            tx.Rollback() : ShowMessage("That email address is already in use.", True) : Return
                        End If
                        Using cmd As New SqlCommand("UPDATE register SET FullName=@name, Email=@email WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", conn, tx)
                            cmd.Parameters.Add("@name", SqlDbType.NVarChar, 100).Value = fullName
                            cmd.Parameters.Add("@email", SqlDbType.NVarChar, 255).Value = email
                            cmd.Parameters.Add("@id", SqlDbType.Int).Value = targetId
                            If cmd.ExecuteNonQuery() <> 1 Then Throw New InvalidOperationException()
                        End Using
                        tx.Commit()
                    End Using
                End Using
                pnlEditAdmin.Visible = False : ShowMessage("Administrator details updated.", False)
            Catch
                ShowMessage("Could not update that administrator. Check that the email is unique.", True)
            End Try
            LoadAdmins()
        End Sub

        Protected Sub btnSaveReset_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Not IsAdmin() OrElse Not ConsumeRequestToken() Then Return
            Dim targetId As Integer
            Dim password As String = txtResetPassword.Text
            If Not Integer.TryParse(hfResetAdminId.Value, targetId) OrElse targetId = CurrentUserId() Then
                ShowMessage("Select another administrator to reset.", True) : Return
            End If
            If Not StrongPassword(password) OrElse Not String.Equals(password, txtResetConfirm.Text, StringComparison.Ordinal) Then
                ShowMessage("Use a password of at least 8 characters with a letter and number, and confirm it correctly.", True) : Return
            End If
            Try
                Dim salt As String = Security.GenerateSalt()
                Dim hash As String = Security.HashPassword(password, salt)
                Using conn As SqlConnection = Db.GetConnection()
                    Using tx As SqlTransaction = conn.BeginTransaction(IsolationLevel.Serializable)
                        Using cmd As New SqlCommand("UPDATE register SET Password='', PasswordHash=@hash, Salt=@salt WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", conn, tx)
                            cmd.Parameters.Add("@hash", SqlDbType.NVarChar, 255).Value = hash
                            cmd.Parameters.Add("@salt", SqlDbType.NVarChar, 255).Value = salt
                            cmd.Parameters.Add("@id", SqlDbType.Int).Value = targetId
                            If cmd.ExecuteNonQuery() <> 1 Then Throw New InvalidOperationException()
                        End Using
                        WriteAudit(conn, tx, "Admin password changed", "An administrator password was reset by another administrator.")
                        tx.Commit()
                    End Using
                End Using
                pnlResetPassword.Visible = False : txtResetPassword.Text = "" : txtResetConfirm.Text = ""
                ShowMessage("Administrator password was reset.", False)
            Catch
                ShowMessage("Could not reset that administrator password.", True)
            End Try
            LoadAdmins()
        End Sub

        Private Sub ToggleAdmin(ByVal targetId As Integer)
            If targetId = CurrentUserId() Then
                ShowMessage("You cannot deactivate your own administrator account.", True) : Return
            End If
            Try
                Using conn As SqlConnection = Db.GetConnection()
                    Using tx As SqlTransaction = conn.BeginTransaction(IsolationLevel.Serializable)
                        Dim isActive As Boolean
                        Using lockCmd As New SqlCommand("SELECT IsActive FROM register WITH (UPDLOCK, HOLDLOCK) WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", conn, tx)
                            lockCmd.Parameters.Add("@id", SqlDbType.Int).Value = targetId
                            Dim state As Object = lockCmd.ExecuteScalar()
                            If state Is Nothing Then Throw New InvalidOperationException()
                            isActive = Convert.ToBoolean(state)
                        End Using
                        Dim nextActive As Boolean = Not isActive
                        If isActive Then
                            Using countCmd As New SqlCommand("SELECT COUNT(*) FROM register WITH (UPDLOCK, HOLDLOCK) WHERE LOWER(ISNULL(Role,''))='admin' AND IsActive=1", conn, tx)
                                If Convert.ToInt32(countCmd.ExecuteScalar()) <= 1 Then
                                    tx.Rollback() : ShowMessage("The last active administrator cannot be deactivated.", True) : Return
                                End If
                            End Using
                        End If
                        Using cmd As New SqlCommand("UPDATE register SET IsActive=@active WHERE UserID=@id AND LOWER(ISNULL(Role,''))='admin'", conn, tx)
                            cmd.Parameters.Add("@active", SqlDbType.Bit).Value = nextActive
                            cmd.Parameters.Add("@id", SqlDbType.Int).Value = targetId
                            cmd.ExecuteNonQuery()
                        End Using
                        WriteAudit(conn, tx, If(nextActive, "Admin activated", "Admin deactivated"), If(nextActive, "An administrator account was activated.", "An administrator account was deactivated."))
                        tx.Commit()
                        ShowMessage(If(nextActive, "Administrator activated.", "Administrator deactivated."), False)
                    End Using
                End Using
            Catch
                ShowMessage("Could not change the administrator status.", True)
            End Try
            LoadAdmins()
        End Sub

        Protected Sub btnCancelEdit_Click(ByVal sender As Object, ByVal e As EventArgs)
            pnlEditAdmin.Visible = False
        End Sub

        Protected Sub btnCancelReset_Click(ByVal sender As Object, ByVal e As EventArgs)
            pnlResetPassword.Visible = False
            txtResetPassword.Text = "" : txtResetConfirm.Text = ""
        End Sub
    End Class
