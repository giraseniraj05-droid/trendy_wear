<%@ Page Title="Admin Dashboard" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="Dashboard.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminDashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header with Quick Action Buttons -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">📊 Admin Dashboard</h1>
            <p class="dash-subtitle">Overview of sales, inventory stock, and customer activity | Today: <strong><%= DateTime.Now.ToString("dd MMM yyyy") %></strong></p>
        </div>
        <div class="dash-actions flex-gap">
            <asp:DropDownList ID="ddlDateRange" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlDateRange_SelectedIndexChanged" CssClass="fk-select width-auto">
                <asp:ListItem Value="7">Last 7 Days</asp:ListItem>

                <asp:ListItem Value="30" Selected="True">Last 30 Days</asp:ListItem>

                <asp:ListItem Value="month">This Month</asp:ListItem>

                <asp:ListItem Value="all">All Time</asp:ListItem>

            </asp:DropDownList>
            <a href="<%= ResolveUrl("~/Admin/Add_Product.aspx") %>" class="fk-btn fk-btn-primary">+ Add Product</a>
            <a href="<%= ResolveUrl("~/Admin/manageorder.aspx") %>" class="fk-btn fk-btn-outline">🛒 View Orders</a>
            <a href="<%= ResolveUrl("~/Home.aspx") %>" class="fk-btn fk-btn-secondary" target="_blank">🛍️ View Store</a>
        </div>
    </div>

    <!-- KPI Cards Row -->
    <div class="kpi-grid mb-4">
        <div class="kpi-card">
            <div class="kpi-icon icon-blue">💰</div>
            <div class="kpi-details">
                <span class="kpi-label">Total Revenue</span>
                <h2 class="kpi-value"><asp:Literal ID="litTotalSales" runat="server">Rs 0</asp:Literal></h2>
                <span class="kpi-trend trend-up">▲ Active Period</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-purple">📦</div>
            <div class="kpi-details">
                <span class="kpi-label">Total Orders</span>
                <h2 class="kpi-value"><asp:Literal ID="litTotalOrders" runat="server">0</asp:Literal></h2>
                <span class="kpi-sub">Completed &amp; Pending</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-amber">⏳</div>
            <div class="kpi-details">
                <span class="kpi-label">Pending Orders</span>
                <h2 class="kpi-value"><asp:Literal ID="litPendingOrders" runat="server">0</asp:Literal></h2>
                <span class="kpi-trend trend-amber">Requires Dispatch</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-green">👥</div>
            <div class="kpi-details">
                <span class="kpi-label">Total Customers</span>
                <h2 class="kpi-value"><asp:Literal ID="litTotalCustomers" runat="server">0</asp:Literal></h2>
                <span class="kpi-sub">Registered Users</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-teal">👕</div>
            <div class="kpi-details">
                <span class="kpi-label">Units in Stock</span>
                <h2 class="kpi-value"><asp:Literal ID="litUnitsInStock" runat="server">0</asp:Literal></h2>
                <span class="kpi-sub">Available Inventory</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-red">⚠️</div>
            <div class="kpi-details">
                <span class="kpi-label">Low / Out of Stock</span>
                <h2 class="kpi-value"><asp:Literal ID="litLowStockCount" runat="server">0</asp:Literal></h2>
                <span class="kpi-trend trend-danger">Restock Needed</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-amber">★</div>
            <div class="kpi-details">
                <span class="kpi-label">Average Product Rating</span>
                <h2 class="kpi-value"><asp:Literal ID="litAverageReviewRating" runat="server">0.0</asp:Literal> / 5</h2>
                <span class="kpi-sub">Approved Reviews</span>
            </div>
        </div>

        <div class="kpi-card">
            <div class="kpi-icon icon-purple">💬</div>
            <div class="kpi-details">
                <span class="kpi-label">Pending Reviews</span>
                <h2 class="kpi-value"><asp:Literal ID="litPendingReviewCount" runat="server">0</asp:Literal></h2>
                <a class="kpi-sub" href="<%= ResolveUrl("~/Admin/customerfeedbacks.aspx") %>">Moderate reviews</a>
            </div>
        </div>
    </div>

    <div class="grid-2-col mb-4">
        <div class="fk-card">
            <div class="fk-card-header"><h3 class="fk-card-title">Sales by day · last 7 days</h3></div>
            <asp:Repeater ID="rptDailySales" runat="server">
                <HeaderTemplate><div class="admin-table-scroll"><table class="fk-table"><thead><tr><th>Date</th><th>Orders</th><th>Revenue</th></tr></thead><tbody></HeaderTemplate>
                <ItemTemplate><tr><td><%#: Eval("PeriodLabel") %></td><td><%#: Eval("OrderCount") %></td><td>Rs <%#: Eval("Revenue", "{0:N2}") %></td></tr></ItemTemplate>
                <FooterTemplate></tbody></table></div></FooterTemplate>
            </asp:Repeater>
        </div>
        <div class="fk-card">
            <div class="fk-card-header"><h3 class="fk-card-title">Sales by month · last 6 months</h3></div>
            <asp:Repeater ID="rptMonthlySales" runat="server">
                <HeaderTemplate><div class="admin-table-scroll"><table class="fk-table"><thead><tr><th>Month</th><th>Orders</th><th>Revenue</th></tr></thead><tbody></HeaderTemplate>
                <ItemTemplate><tr><td><%#: Eval("PeriodLabel") %></td><td><%#: Eval("OrderCount") %></td><td>Rs <%#: Eval("Revenue", "{0:N2}") %></td></tr></ItemTemplate>
                <FooterTemplate></tbody></table></div></FooterTemplate>
            </asp:Repeater>
        </div>
    </div>

    <!-- Available Clothes Per-Product Horizontal Bar Panel -->
    <div class="fk-card mb-4">
        <div class="fk-card-header flex-between">
            <h3 class="fk-card-title">👕 Available Clothes Stock Monitor</h3>
                <div class="stock-legend chart-legend flex-gap">
                <span class="badge badge-success">● High (20+)</span>
                <span class="badge badge-warning">● Medium (6-19)</span>
                <span class="badge badge-danger">● Low (1-5)</span>
                <span class="badge badge-secondary">● Out of Stock (0)</span>
            </div>
        </div>
        <div class="fk-card-body p-0">
            <div class="stock-scroll-list" style="max-height: 400px; overflow-y: auto;">
                <asp:Repeater ID="rptStockItems" runat="server" OnItemCommand="rptStockItems_ItemCommand">
                    <HeaderTemplate>
                        <table class="fk-table stock-monitor-table">
                            <thead>
                                <tr>
                                    <th style="width: 60px;">Image</th>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th style="width: 280px;">Stock Availability</th>
                                    <th>Remaining</th>
                                    <th style="text-align: right;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td>
                                <img src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' 
                                     alt='<%# Eval("p_name") %>' class="thumb-small" onerror="this.src='../Images/default.jpg';" />
                            </td>
                            <td>
                                <strong><%# Eval("p_name") %></strong>
                            </td>
                            <td><span class="fk-pill"><%# Eval("category_name") %></span></td>
                            <td>
                                <div class="stock-bar-wrap">
                                    <div class='<%# GetStockBarClass(Eval("Stock")) %>' style='<%# "width: " & GetStockPercentage(Eval("Stock")) & "%;" %>'></div>
                                </div>
                            </td>
                            <td>
                                <span class='<%# GetStockBadgeClass(Eval("Stock")) %>'>
                                    <%# Eval("Stock") %> left
                                </span>
                            </td>
                            <td style="text-align: right;">
                                <asp:LinkButton ID="btnRestock" runat="server" CommandName="Restock" CommandArgument='<%# Eval("p_id") %>' 
                                                CssClass="fk-btn-sm fk-btn-outline" ToolTip="Quick Add +10 Stock">
                                    ⚡ Restock +10
                                </asp:LinkButton>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                            </tbody>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </div>
        </div>
    </div>

    <!-- Charts Grid (CSS / SVG) -->
    <div class="grid-2-col mb-4">
        <!-- Stock Health Donut Chart -->
        <div class="fk-card">
            <div class="fk-card-header">
                <h3 class="fk-card-title">🍩 Stock Health Overview</h3>
            </div>
            <div class="fk-card-body flex-center flex-column">
                <svg width="220" height="220" viewBox="0 0 42 42" class="donut-chart">
                    <circle class="donut-hole" cx="21" cy="21" r="15.91549430918954" fill="var(--bg-card)"></circle>
                    <circle class="donut-ring" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke="var(--border-color)" stroke-width="5"></circle>
                    <!-- Donut segments rendered dynamically via inline stroke-dasharray -->
                    <circle class="donut-segment segment-green" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke="var(--text-success)" stroke-width="5" 
                            stroke-dasharray='<%= GetDonutDashArray("green") %>' stroke-dashoffset="25"></circle>
                    <circle class="donut-segment segment-amber" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke="var(--buy-orange)" stroke-width="5" 
                            stroke-dasharray='<%= GetDonutDashArray("amber") %>' stroke-dashoffset='<%= GetDonutOffset("amber") %>'></circle>
                    <circle class="donut-segment segment-red" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke="var(--text-danger)" stroke-width="5" 
                            stroke-dasharray='<%= GetDonutDashArray("red") %>' stroke-dashoffset='<%= GetDonutOffset("red") %>'></circle>
                    <text x="50%" y="50%" class="donut-number" text-anchor="middle" dy="0.3em"><asp:Literal ID="litDonutTotal" runat="server">0</asp:Literal></text>
                </svg>
                <div class="flex-gap chart-legend mt-3">
                    <span class="legend-green">■ High Stock (<asp:Literal ID="litHighCount" runat="server">0</asp:Literal>)</span>
                    <span class="legend-amber">■ Med Stock (<asp:Literal ID="litMedCount" runat="server">0</asp:Literal>)</span>
                    <span class="legend-red">■ Low/Out (<asp:Literal ID="litLowCount" runat="server">0</asp:Literal>)</span>
                </div>
            </div>
        </div>

        <!-- Orders Status Donut Chart -->
        <div class="fk-card">
            <div class="fk-card-header">
                <h3 class="fk-card-title">📊 Orders by Status</h3>
            </div>
            <div class="fk-card-body">
                <div class="chart-bars-wrap">
                    <div class="chart-bar-row">
                        <span class="bar-label">Pending</span>
                        <div class="bar-bg">
                            <div class="bar-fill bar-amber" style='<%# "width:" & GetStatusPercent("Pending") & "%;" %>'></div>
                        </div>
                        <span class="bar-val"><asp:Literal ID="litPendingStat" runat="server">0</asp:Literal></span>
                    </div>
                    <div class="chart-bar-row">
                        <span class="bar-label">Confirmed</span>
                        <div class="bar-bg">
                            <div class="bar-fill bar-blue" style='<%# "width:" & GetStatusPercent("Confirmed") & "%;" %>'></div>
                        </div>
                        <span class="bar-val"><asp:Literal ID="litConfirmedStat" runat="server">0</asp:Literal></span>
                    </div>
                    <div class="chart-bar-row">
                        <span class="bar-label">Shipped</span>
                        <div class="bar-bg">
                            <div class="bar-fill bar-purple" style='<%# "width:" & GetStatusPercent("Shipped") & "%;" %>'></div>
                        </div>
                        <span class="bar-val"><asp:Literal ID="litShippedStat" runat="server">0</asp:Literal></span>
                    </div>
                    <div class="chart-bar-row">
                        <span class="bar-label">Delivered</span>
                        <div class="bar-bg">
                            <div class="bar-fill bar-green" style='<%# "width:" & GetStatusPercent("Delivered") & "%;" %>'></div>
                        </div>
                        <span class="bar-val"><asp:Literal ID="litDeliveredStat" runat="server">0</asp:Literal></span>
                    </div>
                    <div class="chart-bar-row">
                        <span class="bar-label">Cancelled</span>
                        <div class="bar-bg">
                            <div class="bar-fill bar-red" style='<%# "width:" & GetStatusPercent("Cancelled") & "%;" %>'></div>
                        </div>
                        <span class="bar-val"><asp:Literal ID="litCancelledStat" runat="server">0</asp:Literal></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders & Best Sellers Grid -->
    <div class="grid-2-col mb-4">
        <!-- Recent Orders -->
        <div class="fk-card">
            <div class="fk-card-header flex-between">
                <h3 class="fk-card-title">🛒 Recent Orders</h3>
                <a href="<%= ResolveUrl("~/Admin/manageorder.aspx") %>" class="fk-link">View All &rarr;</a>
            </div>
            <div class="fk-card-body p-0">
                <asp:Repeater ID="rptRecentOrders" runat="server">
                    <HeaderTemplate>
                        <div class="admin-table-scroll"><table class="fk-table">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td><strong>#<%# Eval("order_id") %></strong></td>
                            <td><%# Eval("u_name") %></td>
                            <td>Rs <%# String.Format("{0:N0}", Eval("total_price")) %></td>
                            <td>
                                <span class='<%# GetStatusBadgeClass(Eval("status")) %>'>
                                    <%# Eval("status") %>
                                </span>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                            </tbody>
                        </table></div>
                    </FooterTemplate>
                </asp:Repeater>
                <asp:PlaceHolder ID="phNoRecentOrders" runat="server" Visible="false">
                    <div class="empty-state p-4 text-center">
                        <p class="fk-text-muted">No orders found for this period.</p>
                    </div>
                </asp:PlaceHolder>
            </div>
        </div>

        <!-- Best Selling Products -->
        <div class="fk-card">
            <div class="fk-card-header flex-between">
                <h3 class="fk-card-title">🔥 Top Selling Products</h3>
                <a href="<%= ResolveUrl("~/Admin/Add_Product.aspx") %>" class="fk-link">Manage Products &rarr;</a>
            </div>
            <div class="fk-card-body p-0">
                <asp:Repeater ID="rptBestSellers" runat="server">
                    <HeaderTemplate>
                        <div class="admin-table-scroll"><table class="fk-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Stock Left</th>
                                    <th>Units Sold</th>
                                </tr>
                            </thead>
                            <tbody>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td>
                                <div class="flex-gap-sm align-center">
                                    <img src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' 
                                         class="thumb-small" onerror="this.src='../Images/default.jpg';" />
                                    <span><strong><%# Eval("p_name") %></strong></span>
                                </div>
                            </td>
                            <td>Rs <%# String.Format("{0:N0}", Eval("price")) %></td>
                            <td>
                                <span class='<%# GetStockBadgeClass(Eval("Stock")) %>'>
                                    <%# Eval("Stock") %> left
                                </span>
                            </td>
                            <td><%#: Eval("UnitsSold") %></td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                            </tbody>
                        </table></div>
                    </FooterTemplate>
                </asp:Repeater>
            </div>
        </div>
    </div>

    <!-- Newest Customers Section -->
    <div class="fk-card">
        <div class="fk-card-header flex-between">
            <h3 class="fk-card-title">👥 Newest Registered Customers</h3>
            <a href="<%= ResolveUrl("~/Admin/customers.aspx") %>" class="fk-link">Manage Customers &rarr;</a>
        </div>
        <div class="fk-card-body p-0">
            <asp:Repeater ID="rptNewCustomers" runat="server">
                <HeaderTemplate>
                    <div class="admin-table-scroll"><table class="fk-table">
                        <thead>
                            <tr>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                </HeaderTemplate>
                <ItemTemplate>
                    <tr>
                        <td><strong><%# Eval("u_name") %></strong></td>
                        <td><%# Eval("email") %></td>
                        <td><%# Eval("mobile") %></td>
                        <td><span class="badge badge-info"><%# Eval("Role") %></span></td>
                    </tr>
                </ItemTemplate>
                <FooterTemplate>
                        </tbody>
                    </table></div>
                </FooterTemplate>
            </asp:Repeater>
        </div>
    </div>
</asp:Content>
