Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminCoupons
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx")
            Return
        End If
        If Not IsPostBack Then BindCoupons()
    End Sub

    Protected Sub btnCreate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCreate.Click
        Dim code As String = txtCode.Text.Trim().ToUpperInvariant()
        Dim value As Decimal
        Dim minimum As Decimal
        Dim maximum As Decimal
        Dim usageLimit As Integer
        Dim expiry As DateTime
        If Not System.Text.RegularExpressions.Regex.IsMatch(code, "^[A-Z0-9_-]{3,50}$") OrElse
           Not Decimal.TryParse(txtDiscountValue.Text, value) OrElse value <= 0D OrElse
           Not Decimal.TryParse(txtMinimum.Text, minimum) OrElse minimum < 0D OrElse
           Not Integer.TryParse(txtUsageLimit.Text, usageLimit) OrElse usageLimit < 1 OrElse
           Not DateTime.TryParse(txtExpiry.Text, CultureInfo.InvariantCulture, DateTimeStyles.None, expiry) OrElse expiry.Date < DateTime.Today OrElse
           (Not String.IsNullOrWhiteSpace(txtMaximum.Text) AndAlso (Not Decimal.TryParse(txtMaximum.Text, maximum) OrElse maximum <= 0D)) Then
            lblMessage.Text = "Enter a valid code, discount, minimum, expiry date, usage limit, and optional discount cap."
            Return
        End If
        If ddlDiscountType.SelectedValue = "Percentage" AndAlso value > 100D Then
            lblMessage.Text = "Percentage discount cannot be over 100."
            Return
        End If
        Try
            Db.ExecuteNonQuery("INSERT INTO Coupons (CouponCode, DiscountType, DiscountValue, MinOrderAmount, MaxDiscountAmount, ExpiryDate, UsageLimit, IsActive) VALUES (@Code, @Type, @Value, @Minimum, @Maximum, @Expiry, @UsageLimit, 1)",
                               Db.CreateParam("@Code", SqlDbType.NVarChar, code, 50),
                               Db.CreateParam("@Type", SqlDbType.NVarChar, ddlDiscountType.SelectedValue, 20),
                               Db.CreateParam("@Value", SqlDbType.Decimal, value),
                               Db.CreateParam("@Minimum", SqlDbType.Decimal, minimum),
                               Db.CreateParam("@Maximum", SqlDbType.Decimal, If(String.IsNullOrWhiteSpace(txtMaximum.Text), CType(DBNull.Value, Object), maximum)),
                               Db.CreateParam("@Expiry", SqlDbType.DateTime, expiry.Date.AddDays(1).AddSeconds(-1)),
                               Db.CreateParam("@UsageLimit", SqlDbType.Int, usageLimit))
            lblMessage.Text = "Coupon created."
            txtCode.Text = ""
            BindCoupons()
        Catch ex As SqlException When ex.Number = 2601 OrElse ex.Number = 2627
            lblMessage.Text = "That coupon code already exists."
        Catch ex As Exception
            Logger.LogError("Error creating coupon", ex)
            lblMessage.Text = "Could not create the coupon."
        End Try
    End Sub

    Protected Sub gvCoupons_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName <> "DisableCoupon" Then Return
        Dim couponId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), couponId) Then Return
        Db.ExecuteNonQuery("UPDATE Coupons SET IsActive = 0 WHERE CouponID = @CouponID",
                           Db.CreateParam("@CouponID", SqlDbType.Int, couponId))
        lblMessage.Text = "Coupon disabled."
        BindCoupons()
    End Sub

    Private Sub BindCoupons()
        gvCoupons.DataSource = Db.ExecuteQuery("SELECT CouponID, CouponCode, DiscountType, DiscountValue, MinOrderAmount, ExpiryDate, CAST(TimesUsed AS NVARCHAR(20)) + ' / ' + CAST(UsageLimit AS NVARCHAR(20)) AS Usage, IsActive FROM Coupons ORDER BY CreatedOn DESC")
        gvCoupons.DataBind()
    End Sub
End Class
