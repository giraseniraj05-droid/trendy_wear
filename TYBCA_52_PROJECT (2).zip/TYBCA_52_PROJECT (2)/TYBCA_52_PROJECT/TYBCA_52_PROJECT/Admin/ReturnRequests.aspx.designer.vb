Option Strict On
Option Explicit On

Partial Public Class AdminReturnRequests
    Protected WithEvents lblMessage As Global.System.Web.UI.WebControls.Label
    Protected WithEvents gvRequests As Global.System.Web.UI.WebControls.GridView
End Class
