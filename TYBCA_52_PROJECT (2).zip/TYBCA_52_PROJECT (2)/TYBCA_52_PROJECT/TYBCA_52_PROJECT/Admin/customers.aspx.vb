Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminCustomers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim role As String = Convert.ToString(Session("role"))
        If Not role.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadCustomers()
        End If
    End Sub

    Private Sub ShowMessage(ByVal message As String, ByVal isError As Boolean)
        lblMsg.Text = Server.HtmlEncode(message)
        lblMsg.CssClass = If(isError, "alert alert-danger mb-3", "alert alert-success mb-3")
        lblMsg.Visible = True
    End Sub

    Private Sub LoadCustomers()
        Try
            Dim search As String = txtSearch.Text.Trim()
            Dim sql As String = "SELECT r.UserID AS u_id, r.Username AS u_name, r.FullName, r.Email AS email, r.Mobileno AS mobile, r.IsActive, " & _
                                "ISNULL(r.CreatedOn, GETDATE()) AS CreatedOn, " & _
                                "(SELECT COUNT(*) FROM orders o WHERE o.UserID = r.UserID) AS OrderCount, " & _
                                "(SELECT ISNULL(SUM(o.TotalAmount), 0) FROM orders o WHERE o.UserID = r.UserID AND LOWER(ISNULL(o.Status,'')) <> 'cancelled') AS TotalSpent " & _
                                "FROM register r WHERE LOWER(ISNULL(r.Role, 'Customer')) = 'customer' "

            Dim params As New List(Of SqlParameter)()
            If Not String.IsNullOrEmpty(search) Then
                sql &= " AND (r.Username LIKE @q OR r.FullName LIKE @q OR r.Email LIKE @q OR r.Mobileno LIKE @q) "
                params.Add(New SqlParameter("@q", "%" & search & "%"))
            End If

            sql &= " ORDER BY r.UserID DESC"

            Dim dt As DataTable = Db.ExecuteQuery(sql, params.ToArray())
            gvCustomers.DataSource = dt
            gvCustomers.DataBind()

            phEmptyCustomers.Visible = (dt.Rows.Count = 0)

            Dim totalCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM register WHERE LOWER(ISNULL(Role,'Customer')) = 'customer'"))
            litTotalCustCount.Text = totalCount.ToString()
        Catch ex As Exception
            Logger.LogError("Error loading customers", ex)
            ShowMessage("Could not load customer accounts. Please try again.", True)
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs)
        gvCustomers.PageIndex = 0
        LoadCustomers()
    End Sub

    Protected Sub btnReset_Click(ByVal sender As Object, ByVal e As EventArgs)
        txtSearch.Text = ""
        gvCustomers.PageIndex = 0
        LoadCustomers()
    End Sub

    Protected Sub gvCustomers_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvCustomers.PageIndex = e.NewPageIndex
        LoadCustomers()
    End Sub

    Protected Sub gvCustomers_RowEditing(ByVal sender As Object, ByVal e As GridViewEditEventArgs)
        gvCustomers.EditIndex = e.NewEditIndex
        LoadCustomers()
    End Sub

    Protected Sub gvCustomers_RowCancelingEdit(ByVal sender As Object, ByVal e As GridViewCancelEditEventArgs)
        gvCustomers.EditIndex = -1
        LoadCustomers()
    End Sub

    Protected Sub gvCustomers_RowUpdating(ByVal sender As Object, ByVal e As GridViewUpdateEventArgs)
        Dim userId As Integer = Convert.ToInt32(gvCustomers.DataKeys(e.RowIndex).Value)
        Dim row As GridViewRow = gvCustomers.Rows(e.RowIndex)
        Dim fullName As String = CType(row.FindControl("txtFullName"), TextBox).Text.Trim()
        Dim username As String = CType(row.FindControl("txtUsername"), TextBox).Text.Trim()
        Dim email As String = CType(row.FindControl("txtEmail"), TextBox).Text.Trim()
        Dim mobile As String = CType(row.FindControl("txtMobile"), TextBox).Text.Trim()

        If String.IsNullOrWhiteSpace(fullName) OrElse String.IsNullOrWhiteSpace(username) OrElse String.IsNullOrWhiteSpace(email) Then
            ShowMessage("Full name, username, and email are required.", True)
            e.Cancel = True
            Return
        End If
        Try
            Dim emailAddress As New MailAddress(email)
            If Not String.Equals(emailAddress.Address, email, StringComparison.OrdinalIgnoreCase) Then
                ShowMessage("Enter a valid email address.", True)
                e.Cancel = True
                Return
            End If
        Catch
            ShowMessage("Enter a valid email address.", True)
            e.Cancel = True
            Return
        End Try

        Try
            Dim duplicateCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM register WHERE UserID <> @UserID AND (Username = @Username OR Email = @Email)",
                Db.CreateParam("@UserID", SqlDbType.Int, userId),
                Db.CreateParam("@Username", SqlDbType.NVarChar, username, 100),
                Db.CreateParam("@Email", SqlDbType.NVarChar, email, 255)))

            If duplicateCount > 0 Then
                ShowMessage("That username or email address is already used by another account.", True)
                e.Cancel = True
                Return
            End If

            Dim currentEmail As Object = Db.ExecuteScalar("SELECT Email FROM register WHERE UserID = @UserID",
                                                           Db.CreateParam("@UserID", SqlDbType.Int, userId))
            If currentEmail Is Nothing OrElse currentEmail Is DBNull.Value Then
                ShowMessage("The customer account could not be found.", True)
                e.Cancel = True
                Return
            End If
            Dim emailChanged As Boolean = Not String.Equals(Convert.ToString(currentEmail), email, StringComparison.OrdinalIgnoreCase)

            Using connection As SqlConnection = Db.GetConnection()
                Using transaction As SqlTransaction = connection.BeginTransaction()
                    Using updateCommand As New SqlCommand(
                        "UPDATE register SET FullName = @FullName, Username = @Username, Email = @Email, EmailVerified = CASE WHEN @EmailChanged = 1 THEN 0 ELSE EmailVerified END, Mobileno = @Mobile " & _
                        "WHERE UserID = @UserID AND LOWER(ISNULL(Role, 'Customer')) = 'customer'",
                        connection, transaction)
                        updateCommand.Parameters.Add(Db.CreateParam("@FullName", SqlDbType.NVarChar, fullName, 100))
                        updateCommand.Parameters.Add(Db.CreateParam("@Username", SqlDbType.NVarChar, username, 100))
                        updateCommand.Parameters.Add(Db.CreateParam("@Email", SqlDbType.NVarChar, email, 255))
                        updateCommand.Parameters.Add(Db.CreateParam("@EmailChanged", SqlDbType.Bit, emailChanged))
                        updateCommand.Parameters.Add(Db.CreateParam("@Mobile", SqlDbType.NVarChar, mobile, 15))
                        updateCommand.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, userId))
                        If updateCommand.ExecuteNonQuery() <> 1 Then
                            transaction.Rollback()
                            ShowMessage("The customer account could not be found or updated.", True)
                            e.Cancel = True
                            Return
                        End If
                    End Using

                    If emailChanged Then
                        Using revokeCommand As New SqlCommand("UPDATE EmailVerificationTokens SET IsUsed = 1 WHERE UserID = @UserID AND IsUsed = 0", connection, transaction)
                            revokeCommand.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, userId))
                            revokeCommand.ExecuteNonQuery()
                        End Using
                    End If
                    transaction.Commit()
                End Using
            End Using

            If emailChanged Then
                Try
                    EmailVerification.SendVerificationEmail(userId, username, email)
                Catch verificationEx As Exception
                    Logger.LogError("Error preparing updated-email verification for UserID " & userId, verificationEx)
                End Try
            End If

            gvCustomers.EditIndex = -1
            ShowMessage(If(emailChanged,
                           "Customer details updated. The new email address must be verified before sign-in.",
                           "Customer details updated."), False)
            LoadCustomers()
        Catch ex As Exception
            Logger.LogError("Error updating customer UserID " & userId, ex)
            ShowMessage("Could not update this customer. Check that the username and email are valid and unique.", True)
            e.Cancel = True
        End Try
    End Sub

    Protected Sub gvCustomers_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim isActive As Boolean
        If String.Equals(e.CommandName, "DeleteCustomer", StringComparison.Ordinal) Then
            isActive = False
        ElseIf String.Equals(e.CommandName, "ReactivateCustomer", StringComparison.Ordinal) Then
            isActive = True
        Else
            Return
        End If

        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), userId) Then
            ShowMessage("Invalid customer account.", True)
            Return
        End If

        Try
            Dim affected As Integer = Db.ExecuteNonQuery(
                "UPDATE register SET IsActive = @IsActive " & _
                "WHERE UserID = @UserID AND LOWER(ISNULL(Role, 'Customer')) = 'customer'",
                Db.CreateParam("@IsActive", SqlDbType.Bit, isActive),
                Db.CreateParam("@UserID", SqlDbType.Int, userId))

            If affected <> 1 Then
                ShowMessage("The customer account could not be found.", True)
                Return
            End If

            Try
                Dim customer As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE UserID = @UserID",
                                                            Db.CreateParam("@UserID", SqlDbType.Int, userId))
                If customer.Rows.Count > 0 Then
                    Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(customer.Rows(0)("Username")))
                    Dim statusText As String = If(isActive, "unblocked and active again", "blocked and deactivated")
                    Mailer.SendAsync(Convert.ToString(customer.Rows(0)("Email")), "Your Trendy Wear account status changed",
                                     Mailer.Wrap("Account status updated",
                                                 "<p>Hello " & safeUsername & ", your account has been " & statusText & " by the store administrator.</p>"),
                                     If(isActive, "AccountUnblocked", "AccountBlocked"))
                End If
            Catch notificationEx As Exception
                Logger.LogError("Error preparing account status notification for UserID " & userId, notificationEx)
            End Try

            ShowMessage(If(isActive, "Customer account reactivated.", "Customer account deleted (deactivated); order history retained."), False)
            LoadCustomers()
        Catch ex As Exception
            Logger.LogError("Error changing customer account status for UserID " & userId, ex)
            ShowMessage("Could not update this customer account status. Please try again.", True)
        End Try
    End Sub
End Class
