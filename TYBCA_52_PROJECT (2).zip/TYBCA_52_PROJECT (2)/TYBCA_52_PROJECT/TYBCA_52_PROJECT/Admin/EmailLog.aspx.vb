Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminEmailLog
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadEmailLog()
        End If
    End Sub

    Private Sub LoadEmailLog()
        Try
            Dim entries As DataTable = Db.ExecuteQuery("SELECT TOP 500 Id, ToEmail, Subject, Type, Success, LEFT([Error], 1000) AS [Error], CreatedOn FROM EmailLog ORDER BY CreatedOn DESC, Id DESC")
            gvEmailLog.DataSource = entries
            gvEmailLog.DataBind()
            phEmptyLog.Visible = (entries.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading email log", ex)
            Toast.Show(Me, "Could not load email history. Apply Database/upgrade_phase2.sql and try again.", ToastType.Error)
        End Try
    End Sub

    Protected Sub btnSendTest_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim adminEmail As String = ConfigurationManager.AppSettings("AdminEmail")
        If String.IsNullOrWhiteSpace(adminEmail) Then
            Toast.Show(Me, "Set AdminEmail in Web.config before sending a test.", ToastType.Error)
            Return
        End If

        If Mailer.SendTestEmail(adminEmail) Then
            Toast.Show(Me, "Test email sent to " & adminEmail & ".", ToastType.Success)
        Else
            Toast.Show(Me, "Test email failed. Check the Email Log for the SMTP error.", ToastType.Error)
        End If
        LoadEmailLog()
    End Sub

    Protected Sub gvEmailLog_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvEmailLog.PageIndex = e.NewPageIndex
        LoadEmailLog()
    End Sub
End Class
