<%@ Page Title="Manage Orders" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="manageorder.aspx.vb" Inherits="TYBCA_52_PROJECT.manageorder" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">🛒 Order Management Workflow</h1>
            <p class="dash-subtitle">Track customer orders, update delivery status through workflow stages, or cancel orders.</p>
        </div>
    </div>

    <!-- Filter Bar / Status Filter Tabs -->
    <div class="fk-card mb-4 admin-order-filter-card">
        <div class="fk-card-body p-3">
            <div class="flex-between flex-wrap gap-2">
                <div class="status-tabs flex-gap">
                    <asp:LinkButton ID="tabAll" runat="server" OnClick="FilterStatus_Click" CommandArgument="ALL" CssClass="fk-tab active">All Orders</asp:LinkButton>
                    <asp:LinkButton ID="tabPending" runat="server" OnClick="FilterStatus_Click" CommandArgument="Pending" CssClass="fk-tab">⏳ Pending</asp:LinkButton>
                    <asp:LinkButton ID="tabConfirmed" runat="server" OnClick="FilterStatus_Click" CommandArgument="Confirmed" CssClass="fk-tab">✓ Confirmed</asp:LinkButton>
                    <asp:LinkButton ID="tabShipped" runat="server" OnClick="FilterStatus_Click" CommandArgument="Shipped" CssClass="fk-tab">🚚 Shipped</asp:LinkButton>
                    <asp:LinkButton ID="tabOutForDelivery" runat="server" OnClick="FilterStatus_Click" CommandArgument="Out for delivery" CssClass="fk-tab">📍 Out for delivery</asp:LinkButton>
                    <asp:LinkButton ID="tabDelivered" runat="server" OnClick="FilterStatus_Click" CommandArgument="Delivered" CssClass="fk-tab">🎉 Delivered</asp:LinkButton>
                    <asp:LinkButton ID="tabCancelled" runat="server" OnClick="FilterStatus_Click" CommandArgument="Cancelled" CssClass="fk-tab">❌ Cancelled</asp:LinkButton>
                </div>

                <div class="search-box-wrap flex-gap admin-search-bar">
                    <asp:TextBox ID="txtOrderSearch" runat="server" CssClass="fk-input text-sm admin-search-input" placeholder="Order ID or customer..."></asp:TextBox>
                    <asp:Button ID="btnSearchOrder" runat="server" Text="Search" CssClass="fk-btn-sm fk-btn-primary" OnClick="btnSearchOrder_Click" />
                </div>
            </div>
        </div>
    </div>

    <!-- Orders Grid -->
    <div class="fk-card">
        <div class="fk-card-body p-0">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvOrders" runat="server" AutoGenerateColumns="False" 
                          CssClass="fk-table" DataKeyNames="order_id" 
                          OnRowCommand="gvOrders_RowCommand" AllowPaging="True" PageSize="10" 
                          OnPageIndexChanging="gvOrders_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="order_id" HeaderText="Order #" SortExpression="order_id" ItemStyle-Width="80px" />
                    
                    <asp:TemplateField HeaderText="Customer & Contact">
                        <ItemTemplate>
                            <strong><%# Eval("u_name") %></strong>
                            <div class="text-xs fk-text-muted"><%# Eval("mobile") %></div>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:BoundField DataField="p_name" HeaderText="Product" />
                    
                    <asp:BoundField DataField="qty" HeaderText="Qty" ItemStyle-HorizontalAlign="Center" />
                    
                    <asp:TemplateField HeaderText="Total Amount">
                        <ItemTemplate>
                            <strong>Rs <%# String.Format("{0:N0}", Eval("total_price")) %></strong>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Delivery Address">
                        <ItemTemplate>
                            <span class="text-xs"><%# Eval("address") %>, <%# Eval("city") %> (<%# Eval("pincode") %>)</span>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:BoundField DataField="order_date" HeaderText="Order Date" DataFormatString="{0:dd MMM yyyy HH:mm}" />

                    <asp:TemplateField HeaderText="Payment">
                        <ItemTemplate>
                            <div class="text-xs">
                                <strong><%# GetPaymentMethodDisplay(Eval("payment_type")) %></strong>
                            </div>
                            <span class='<%# GetPaymentStatusBadgeClass(Eval("payment_status")) %>'>
                                <%# Eval("payment_status") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Current Status">
                        <ItemTemplate>
                            <span class='<%# GetStatusBadgeClass(Eval("status")) %>'>
                                <%# Eval("status") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Workflow Actions" ItemStyle-HorizontalAlign="Right" ItemStyle-Width="260px">
                        <ItemTemplate>
                            <asp:PlaceHolder ID="phActions" runat="server">
                                <asp:LinkButton ID="btnConfirm" runat="server" CommandName="SetStatus" CommandArgument='<%# Eval("order_id") & "|Confirmed" %>' 
                                                CssClass="fk-btn-sm fk-btn-primary mr-1" Visible='<%# Eval("status").ToString().ToLower() = "pending" %>'>
                                    ✓ Confirm
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnShip" runat="server" CommandName="SetStatus" CommandArgument='<%# Eval("order_id") & "|Shipped" %>' 
                                                CssClass="fk-btn-sm fk-btn-info mr-1" Visible='<%# Eval("status").ToString().ToLower() = "confirmed" %>'>
                                    🚚 Ship
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnOutForDelivery" runat="server" CommandName="SetStatus" CommandArgument='<%# Eval("order_id") & "|Out for delivery" %>' 
                                                CssClass="fk-btn-sm fk-btn-info mr-1" Visible='<%# Eval("status").ToString().ToLower() = "shipped" %>'>
                                    📍 Out for delivery
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnDeliver" runat="server" CommandName="SetStatus" CommandArgument='<%# Eval("order_id") & "|Delivered" %>' 
                                                CssClass="fk-btn-sm fk-btn-success mr-1" Visible='<%# Eval("status").ToString().ToLower() = "out for delivery" %>'>
                                    🎉 Deliver
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnMarkPaid" runat="server" CommandName="SetPaymentStatus" CommandArgument='<%# Eval("order_id") & "|Paid" %>'
                                                CssClass="fk-btn-sm fk-btn-success mr-1" Visible='<%# Eval("payment_status").ToString().ToLower() <> "paid" AndAlso Eval("status").ToString().ToLower() <> "cancelled" %>'>
                                    ✓ Mark Paid
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnRefund" runat="server" CommandName="SetPaymentStatus" CommandArgument='<%# Eval("order_id") & "|Refunded" %>'
                                                CssClass="fk-btn-sm fk-btn-warning mr-1" OnClientClick="return confirm('Refund this order payment?');"
                                                Visible='<%# Eval("payment_status").ToString().ToLower() = "paid" %>'>
                                    ↩ Refund
                                </asp:LinkButton>

                                <asp:LinkButton ID="btnCancel" runat="server" CommandName="SetStatus" CommandArgument='<%# Eval("order_id") & "|Cancelled" %>' 
                                                CssClass="fk-btn-sm fk-btn-danger" OnClientClick="return confirm('Cancel this order and restore stock?');"
                                                Visible='<%# Eval("status").ToString().ToLower() <> "delivered" AndAlso Eval("status").ToString().ToLower() <> "cancelled" %>'>
                                    ❌ Cancel
                                </asp:LinkButton>
                            </asp:PlaceHolder>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <PagerStyle CssClass="fk-pagination" />
            </asp:GridView>
            </div>

            <asp:PlaceHolder ID="phEmptyOrders" runat="server" Visible="false">
                <div class="empty-state p-4 text-center">
                    <p class="fk-text-muted">No orders found matching the filter.</p>
                </div>
            </asp:PlaceHolder>
        </div>
    </div>
</asp:Content>
