<%@ Page Title="Sales & Inventory Reports" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="Reports.aspx.vb" Inherits="TYBCA_52_PROJECT.Reports" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">📈 Business Analytics &amp; Reports</h1>
            <p class="dash-subtitle">Generate custom sales reports, export order history to CSV, or print summary sheets.</p>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="fk-card mb-4">
        <div class="fk-card-header">
            <h3 class="fk-card-title">Report Filter Criteria</h3>
        </div>
        <div class="fk-card-body">
            <div class="grid-3-col mb-3">
                <div class="form-group">
                    <label class="form-label">Start Date:</label>
                    <asp:TextBox ID="txtStartDate" runat="server" TextMode="Date" CssClass="fk-input"></asp:TextBox>
                </div>

                <div class="form-group">
                    <label class="form-label">End Date:</label>
                    <asp:TextBox ID="txtEndDate" runat="server" TextMode="Date" CssClass="fk-input"></asp:TextBox>
                </div>

                <div class="form-group">
                    <label class="form-label">Order Status:</label>
                    <asp:DropDownList ID="ddlStatusFilter" runat="server" CssClass="fk-select">
                        <asp:ListItem Value="ALL">All Statuses</asp:ListItem>
                        <asp:ListItem Value="Pending">Pending</asp:ListItem>
                        <asp:ListItem Value="Confirmed">Confirmed</asp:ListItem>
                        <asp:ListItem Value="Shipped">Shipped</asp:ListItem>
                        <asp:ListItem Value="Delivered">Delivered</asp:ListItem>
                        <asp:ListItem Value="Cancelled">Cancelled</asp:ListItem>
                    </asp:DropDownList>
                </div>
            </div>

            <div class="form-actions flex-gap">
                <asp:Button ID="btnGenerateReport" runat="server" Text="⚡ Generate Report" CssClass="fk-btn fk-btn-primary" OnClick="btnGenerateReport_Click" />
                <asp:Button ID="btnExportCSV" runat="server" Text="📥 Export to CSV" CssClass="fk-btn fk-btn-success" OnClick="btnExportCSV_Click" />
                <button type="button" class="fk-btn fk-btn-outline" onclick="window.print();">🖨️ Print Report</button>
            </div>
        </div>
    </div>

    <!-- Report Results Grid -->
    <div class="fk-card">
        <div class="fk-card-header flex-between">
            <h3 class="fk-card-title">Report Summary</h3>
            <div>
                <strong>Total Revenue: <span class="fk-text-success text-lg"><asp:Literal ID="litReportTotal" runat="server">Rs 0</asp:Literal></span></strong>
            </div>
        </div>
        <div class="fk-card-body p-0" id="printArea">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvReport" runat="server" AutoGenerateColumns="False" 
                          CssClass="fk-table" AllowPaging="True" PageSize="15" 
                          OnPageIndexChanging="gvReport_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="order_id" HeaderText="Order #" />
                    <asp:BoundField DataField="u_name" HeaderText="Customer" />
                    <asp:BoundField DataField="mobile" HeaderText="Mobile" />
                    <asp:BoundField DataField="p_name" HeaderText="Product" />
                    <asp:BoundField DataField="qty" HeaderText="Qty" ItemStyle-HorizontalAlign="Center" />
                    <asp:TemplateField HeaderText="Total Price">
                        <ItemTemplate>
                            Rs <%# String.Format("{0:N0}", Eval("total_price")) %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="order_date" HeaderText="Order Date" DataFormatString="{0:dd MMM yyyy}" />
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='<%# GetStatusBadgeClass(Eval("status")) %>'>
                                <%# Eval("status") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <PagerStyle CssClass="fk-pagination" />
            </asp:GridView>
            </div>
            <asp:PlaceHolder ID="phEmptyReport" runat="server" Visible="false">
                <div class="empty-state p-4 text-center">
                    <p class="fk-text-muted">No records match the report criteria.</p>
                </div>
            </asp:PlaceHolder>
        </div>
    </div>
</asp:Content>
