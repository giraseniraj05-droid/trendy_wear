Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Globalization
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadCategories()
            LoadProducts()

            Select Case Request.QueryString("status")
                Case "saved"
                    Toast.Show(Me, "New product created successfully!", Toast.ToastType.Success)
                Case "updated"
                    Toast.Show(Me, "Product updated successfully!", Toast.ToastType.Success)
            End Select
        End If
    End Sub

    Private Sub LoadCategories()
        Try
            ddlCategory.Items.Clear()
            ddlCategory.Items.Add(New ListItem("-- Select Category --", ""))

            Dim dt As DataTable = Db.ExecuteQuery("SELECT CategoryID AS category_id, CategoryName AS category_name FROM Categories WHERE IsActive = 1 ORDER BY CategoryName ASC")
            For Each row As DataRow In dt.Rows
                ddlCategory.Items.Add(New ListItem(row("category_name").ToString(), row("category_name").ToString()))
            Next

            ' Fallback default items if DB categories are empty
            If ddlCategory.Items.Count <= 1 Then
                ddlCategory.Items.Add(New ListItem("Men", "Men"))
                ddlCategory.Items.Add(New ListItem("Women", "Women"))
                ddlCategory.Items.Add(New ListItem("Kids", "Kids"))
            End If
        Catch ex As Exception
            Logger.LogError("Error loading categories", ex)
        End Try
    End Sub

    Private Sub LoadProducts()
        Try
            Dim search As String = txtSearchFilter.Text.Trim()
            Dim sql As String = "SELECT ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " & _
                                "ISNULL(OldPrice, Price * 1.3) AS OldPrice, Size, Stock, ProductImage AS Image, Description AS details " & _
                                "FROM addproduct1 WHERE IsActive = 1 "
            Dim params As New List(Of SqlParameter)()

            If Not String.IsNullOrEmpty(search) Then
                sql &= " AND (ProductName LIKE @q OR Category LIKE @q) "
                params.Add(New SqlParameter("@q", "%" & search & "%"))
            End If

            sql &= " ORDER BY Stock ASC, ProductID DESC"

            Dim dt As DataTable = Db.ExecuteQuery(sql, params.ToArray())
            gvProducts.DataSource = dt
            gvProducts.DataBind()
        Catch ex As Exception
            Logger.LogError("Error loading products grid", ex)
        End Try
    End Sub

    Protected Sub btnSaveProduct_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSaveProduct.Click
        If Not Page.IsValid Then Return

        Dim pName As String = Nothing
        Dim cat As String = Nothing
        Dim productSize As String = Nothing
        Dim price As Decimal
        Dim oldPrice As Decimal
        Dim stock As Integer
        Dim details As String = Nothing
        Dim validationError As String = Nothing
        If Not TryReadProductForm(pName, cat, productSize, price, oldPrice, stock, details, validationError) Then
            Toast.Show(Me, validationError, Toast.ToastType.Error)
            Return
        End If

        Try
            Dim imgFileName As String = SaveUploadedImage(fuImage, "")

            Dim sql As String = "INSERT INTO addproduct1 (ProductName, Category, CategoryID, Size, Price, OldPrice, Stock, Description, ProductImage, IsActive) " & _
                               "VALUES (@p_name, @category_name, (SELECT CategoryID FROM Categories WHERE CategoryName = @category_name), @Size, @price, @OldPrice, @Stock, @details, @Image, 1)"

            Dim params As SqlParameter() = New SqlParameter() {
                New SqlParameter("@p_name", pName),
                New SqlParameter("@category_name", cat),
                New SqlParameter("@Size", productSize),
                New SqlParameter("@price", price),
                New SqlParameter("@OldPrice", oldPrice),
                New SqlParameter("@Stock", stock),
                New SqlParameter("@details", details),
                New SqlParameter("@Image", imgFileName)
            }

            Db.ExecuteNonQuery(sql, params)
            Response.Redirect("~/Admin/Add_Product.aspx?status=saved", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        Catch ex As Exception
            Logger.LogError("Error adding product", ex)
            Toast.Show(Me, "Error saving product: " & ex.Message, Toast.ToastType.Error)
        End Try
    End Sub

    Protected Sub btnUpdateProduct_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdateProduct.Click
        If Not Page.IsValid Then Return

        Dim pName As String = Nothing
        Dim cat As String = Nothing
        Dim productSize As String = Nothing
        Dim price As Decimal
        Dim oldPrice As Decimal
        Dim stock As Integer
        Dim details As String = Nothing
        Dim validationError As String = Nothing
        If Not TryReadProductForm(pName, cat, productSize, price, oldPrice, stock, details, validationError) Then
            Toast.Show(Me, validationError, Toast.ToastType.Error)
            Return
        End If

        Try
            Dim pId As Integer = Convert.ToInt32(hfProductID.Value)

            Dim existingImg As String = Convert.ToString(Db.ExecuteScalar("SELECT ProductImage FROM addproduct1 WHERE ProductID = @id", New SqlParameter("@id", pId)))
            Dim imgFileName As String = SaveUploadedImage(fuImage, existingImg)

            Dim sql As String = "UPDATE addproduct1 SET ProductName = @p_name, Category = @category_name, " & _
                               "CategoryID = (SELECT CategoryID FROM Categories WHERE CategoryName = @category_name), Size = @Size, Price = @price, " & _
                               "OldPrice = @OldPrice, Stock = @Stock, Description = @details, ProductImage = @Image WHERE ProductID = @id"

            Dim params As SqlParameter() = New SqlParameter() {
                New SqlParameter("@p_name", pName),
                New SqlParameter("@category_name", cat),
                New SqlParameter("@Size", productSize),
                New SqlParameter("@price", price),
                New SqlParameter("@OldPrice", oldPrice),
                New SqlParameter("@Stock", stock),
                New SqlParameter("@details", details),
                New SqlParameter("@Image", imgFileName),
                New SqlParameter("@id", pId)
            }

            Db.ExecuteNonQuery(sql, params)
            If stock > 0 Then StockNotificationService.NotifyIfBackInStock(pId, Me)
            Response.Redirect("~/Admin/Add_Product.aspx?status=updated", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        Catch ex As Exception
            Logger.LogError("Error updating product", ex)
            Toast.Show(Me, "Error updating product: " & ex.Message, Toast.ToastType.Error)
        End Try
    End Sub

    Private Function TryReadProductForm(ByRef pName As String, ByRef cat As String, ByRef productSize As String,
                                        ByRef price As Decimal, ByRef oldPrice As Decimal, ByRef stock As Integer,
                                        ByRef details As String, ByRef validationError As String) As Boolean
        pName = txtPName.Text.Trim()
        cat = ddlCategory.SelectedValue
        productSize = ddlSize.SelectedValue
        details = txtDetails.Text.Trim()
        validationError = Nothing

        If String.IsNullOrWhiteSpace(pName) OrElse String.IsNullOrWhiteSpace(cat) OrElse String.IsNullOrWhiteSpace(productSize) Then
            validationError = "Enter a product name and select both a category and size."
            Return False
        End If

        If Not Decimal.TryParse(txtPrice.Text.Trim(), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, price) OrElse price <= 0D Then
            validationError = "Enter a valid price greater than zero."
            Return False
        End If

        Dim oldPriceText As String = txtOldPrice.Text.Trim()
        If String.IsNullOrEmpty(oldPriceText) Then
            oldPrice = price
        ElseIf Not Decimal.TryParse(oldPriceText, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, oldPrice) OrElse oldPrice <= 0D Then
            validationError = "Enter a valid old price greater than zero, or leave it blank."
            Return False
        End If

        If Not Integer.TryParse(txtStock.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, stock) OrElse stock < 0 Then
            validationError = "Enter a valid stock quantity of zero or more."
            Return False
        End If

        Return True
    End Function

    Protected Sub gvProducts_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim pId As Integer = Convert.ToInt32(e.CommandArgument)

        If e.CommandName = "EditProduct" Then
            Try
                Dim dt As DataTable = Db.ExecuteQuery("SELECT ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " & _
                                                      "Size, OldPrice, Stock, Description AS details, ProductImage AS Image FROM addproduct1 WHERE ProductID = @id", _
                                                      New SqlParameter("@id", pId))
                If dt.Rows.Count > 0 Then
                    Dim row As DataRow = dt.Rows(0)
                    hfProductID.Value = pId.ToString()
                    txtPName.Text = row("p_name").ToString()
                    If ddlCategory.Items.FindByValue(row("category_name").ToString()) IsNot Nothing Then
                        ddlCategory.SelectedValue = row("category_name").ToString()
                    End If
                    Dim productSize As String = row("Size").ToString()
                    If ddlSize.Items.FindByValue(productSize) Is Nothing Then
                        ddlSize.Items.Add(New ListItem(productSize, productSize))
                    End If
                    ddlSize.SelectedValue = productSize
                    txtPrice.Text = Convert.ToDecimal(row("price")).ToString("0")
                    txtOldPrice.Text = If(IsDBNull(row("OldPrice")), "", Convert.ToDecimal(row("OldPrice")).ToString("0"))
                    txtStock.Text = row("Stock").ToString()
                    txtDetails.Text = If(IsDBNull(row("details")), "", row("details").ToString())
                    lblCurrentImg.Text = "Current Image: " & row("Image").ToString()

                    litFormTitle.Text = "Edit Product #" & pId
                    btnSaveProduct.Visible = False
                    btnUpdateProduct.Visible = True
                    btnCancelEdit.Visible = True
                End If
            Catch ex As Exception
                Logger.LogError("Error loading product for edit", ex)
            End Try

        ElseIf e.CommandName = "DeleteProduct" Then
            Try
                ' Soft delete setting IsActive = 0
                Db.ExecuteNonQuery("UPDATE addproduct1 SET IsActive = 0 WHERE ProductID = @id", New SqlParameter("@id", pId))
                Toast.Show(Me, "Product deactivated successfully!", Toast.ToastType.Info)
                LoadProducts()
            Catch ex As Exception
                Logger.LogError("Error deleting product", ex)
            End Try
        End If
    End Sub

    Protected Sub gvProducts_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs)
        ' Handled in RowCommand
    End Sub

    Protected Sub btnCancelEdit_Click(ByVal sender As Object, ByVal e As EventArgs)
        ClearForm()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As EventArgs)
        gvProducts.PageIndex = 0
        LoadProducts()
    End Sub

    Protected Sub gvProducts_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvProducts.PageIndex = e.NewPageIndex
        LoadProducts()
    End Sub

    Private Sub ClearForm()
        hfProductID.Value = "0"
        txtPName.Text = ""
        ddlCategory.SelectedIndex = 0
        ddlSize.SelectedIndex = 0
        txtPrice.Text = ""
        txtOldPrice.Text = ""
        txtStock.Text = "10"
        txtDetails.Text = ""
        lblCurrentImg.Text = ""

        litFormTitle.Text = "Add New Clothing Product"
        btnSaveProduct.Visible = True
        btnUpdateProduct.Visible = False
        btnCancelEdit.Visible = False
    End Sub

    Private Function SaveUploadedImage(ByVal fileUpload As FileUpload, ByVal fallbackImg As String) As String
        If Not fileUpload.HasFile Then
            Return If(String.IsNullOrEmpty(fallbackImg), "default.jpg", fallbackImg)
        End If

        Dim ext As String = Path.GetExtension(fileUpload.FileName).ToLower()
        If ext <> ".jpg" AndAlso ext <> ".jpeg" AndAlso ext <> ".png" AndAlso ext <> ".webp" Then
            Throw New Exception("Only JPG, PNG, and WebP image formats are supported.")
        End If

        If fileUpload.PostedFile.ContentLength > (2 * 1024 * 1024) Then
            Throw New Exception("Product image file size cannot exceed 2 MB.")
        End If

        Dim uploadsFolder As String = Server.MapPath("~/Uploads/")
        If Not Directory.Exists(uploadsFolder) Then
            Directory.CreateDirectory(uploadsFolder)
        End If

        Dim newFileName As String = "prod_" & Guid.NewGuid().ToString("N").Substring(0, 10) & ext
        Dim fullPath As String = Path.Combine(uploadsFolder, newFileName)
        fileUpload.SaveAs(fullPath)

        Return newFileName
    End Function

    Public Function GetStockBarClass(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        If s >= 20 Then Return "bar-fill bar-green"
        If s >= 6 Then Return "bar-fill bar-amber"
        If s >= 1 Then Return "bar-fill bar-red"
        Return "bar-fill bar-grey"
    End Function

    Public Function GetStockTextClass(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        If s >= 20 Then Return "fk-text-success"
        If s >= 6 Then Return "fk-text-warning"
        If s >= 1 Then Return "fk-text-danger"
        Return "fk-text-muted"
    End Function

    Public Function GetStockPercentage(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        Dim pct As Integer = CInt(Math.Min(100, (s / 50.0) * 100))
        Return pct.ToString()
    End Function
End Class
