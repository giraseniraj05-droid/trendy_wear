<%@ Page Title="Admin Accounts" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="AdminAccounts.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminAccounts" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header mb-4"><div><h1 class="dash-title">Admin Accounts</h1><p class="dash-subtitle">Manage store administrators and your own sign-in details.</p></div></div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" CssClass="alert mb-3" />
    <asp:HiddenField ID="hfRequestToken" runat="server" />
    <asp:HiddenField ID="hfEditAdminId" runat="server" />
    <asp:HiddenField ID="hfResetAdminId" runat="server" />

    <div class="admin-card fk-card mb-4"><div class="fk-card-header"><h2>My account</h2></div><div class="fk-card-body">
        <div class="grid-3-col">
            <div class="form-group"><label class="form-label">Username</label><asp:TextBox ID="txtMyUsername" runat="server" CssClass="form-control" MaxLength="100" /></div>
            <div class="form-group"><label class="form-label">Email</label><asp:TextBox ID="txtMyEmail" runat="server" CssClass="form-control" MaxLength="255" TextMode="Email" /></div>
            <div class="form-group"><label class="form-label">Current password (required to change password)</label><asp:TextBox ID="txtCurrentPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div>
            <div class="form-group"><label class="form-label">New password</label><asp:TextBox ID="txtMyNewPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div>
            <div class="form-group"><label class="form-label">Confirm new password</label><asp:TextBox ID="txtMyConfirmPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div>
        </div><asp:Button ID="btnSaveMyAccount" runat="server" Text="Save my account" CssClass="btn fk-btn fk-btn-primary mt-3" OnClick="btnSaveMyAccount_Click" />
    </div></div>

    <div class="admin-card fk-card mb-4"><div class="fk-card-header"><h2>Add an administrator</h2></div><div class="fk-card-body">
        <div class="grid-3-col">
            <div class="form-group"><label class="form-label">Full name</label><asp:TextBox ID="txtNewFullName" runat="server" CssClass="form-control" MaxLength="100" /></div>
            <div class="form-group"><label class="form-label">Username</label><asp:TextBox ID="txtNewUsername" runat="server" CssClass="form-control" MaxLength="100" /></div>
            <div class="form-group"><label class="form-label">Email</label><asp:TextBox ID="txtNewEmail" runat="server" CssClass="form-control" MaxLength="255" TextMode="Email" /></div>
            <div class="form-group"><label class="form-label">Mobile</label><asp:TextBox ID="txtNewMobile" runat="server" CssClass="form-control" MaxLength="15" /></div>
            <div class="form-group"><label class="form-label">Password (8+ characters, letter and number)</label><asp:TextBox ID="txtNewPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div>
            <div class="form-group"><label class="form-label">Confirm password</label><asp:TextBox ID="txtNewConfirmPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div>
        </div><asp:Button ID="btnAddAdmin" runat="server" Text="Create admin" CssClass="btn fk-btn fk-btn-primary mt-3" OnClick="btnAddAdmin_Click" />
    </div></div>

    <asp:Panel ID="pnlEditAdmin" runat="server" Visible="false" CssClass="admin-card fk-card mb-4"><div class="fk-card-header"><h2>Edit administrator</h2></div><div class="fk-card-body">
        <div class="grid-2-col"><div class="form-group"><label class="form-label">Full name</label><asp:TextBox ID="txtEditFullName" runat="server" CssClass="form-control" MaxLength="100" /></div><div class="form-group"><label class="form-label">Email</label><asp:TextBox ID="txtEditEmail" runat="server" CssClass="form-control" MaxLength="255" TextMode="Email" /></div></div>
        <asp:Button ID="btnSaveEdit" runat="server" Text="Save changes" CssClass="btn fk-btn fk-btn-primary mt-3" OnClick="btnSaveEdit_Click" /><asp:Button ID="btnCancelEdit" runat="server" Text="Cancel" CssClass="btn fk-btn fk-btn-secondary mt-3" CausesValidation="false" OnClick="btnCancelEdit_Click" />
    </div></asp:Panel>
    <asp:Panel ID="pnlResetPassword" runat="server" Visible="false" CssClass="admin-card fk-card mb-4"><div class="fk-card-header"><h2>Set administrator password</h2></div><div class="fk-card-body">
        <div class="grid-2-col"><div class="form-group"><label class="form-label">New password (8+ characters, letter and number)</label><asp:TextBox ID="txtResetPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div><div class="form-group"><label class="form-label">Confirm password</label><asp:TextBox ID="txtResetConfirm" runat="server" CssClass="form-control" TextMode="Password" MaxLength="128" /></div></div>
        <asp:Button ID="btnSaveReset" runat="server" Text="Set password" CssClass="btn fk-btn fk-btn-primary mt-3" OnClick="btnSaveReset_Click" /><asp:Button ID="btnCancelReset" runat="server" Text="Cancel" CssClass="btn fk-btn fk-btn-secondary mt-3" CausesValidation="false" OnClick="btnCancelReset_Click" />
    </div></asp:Panel>

    <div class="admin-card fk-card"><div class="fk-card-header"><h2>Administrators</h2></div><div class="fk-card-body"><div class="admin-table-scroll">
        <asp:GridView ID="gvAdmins" runat="server" AutoGenerateColumns="False" DataKeyNames="UserID" CssClass="fk-table" GridLines="None" OnRowCommand="gvAdmins_RowCommand">
            <Columns>
                <asp:BoundField DataField="UserID" HeaderText="ID" /><asp:BoundField DataField="Username" HeaderText="Username" /><asp:BoundField DataField="FullName" HeaderText="Full name" /><asp:BoundField DataField="Email" HeaderText="Email" /><asp:BoundField DataField="ActiveState" HeaderText="Status" /><asp:BoundField DataField="CreatedOn" HeaderText="Created" DataFormatString="{0:dd MMM yyyy}" /><asp:BoundField DataField="LastLogin" HeaderText="Last login" DataFormatString="{0:dd MMM yyyy HH:mm}" />
                <asp:TemplateField HeaderText="Actions"><ItemTemplate><asp:LinkButton ID="btnEditAdmin" runat="server" Text="Edit" CommandName="EditAdmin" CommandArgument='<%# Eval("UserID") %>' CssClass="fk-btn-sm fk-btn-secondary" CausesValidation="false" /><asp:LinkButton ID="btnResetAdmin" runat="server" Text="Set password" CommandName="ResetAdmin" CommandArgument='<%# Eval("UserID") %>' CssClass="fk-btn-sm fk-btn-secondary" CausesValidation="false" /><asp:LinkButton ID="btnToggleAdmin" runat="server" Text='<%# If(Convert.ToBoolean(Eval("IsActive")), "Deactivate", "Activate") %>' CommandName="ToggleAdmin" CommandArgument='<%# Eval("UserID") %>' CssClass="fk-btn-sm fk-btn-secondary" CausesValidation="false" OnClientClick="return confirm('Change this administrator account status?');" /></ItemTemplate></asp:TemplateField>
            </Columns>
            <EmptyDataTemplate>No administrator accounts found.</EmptyDataTemplate>
        </asp:GridView>
    </div></div></div>
</asp:Content>
