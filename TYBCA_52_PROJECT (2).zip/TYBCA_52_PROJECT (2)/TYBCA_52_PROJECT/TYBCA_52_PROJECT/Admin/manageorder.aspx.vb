Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class manageorder
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            ViewState("SelectedStatus") = "ALL"
            LoadOrders()
        End If
    End Sub

    Private Sub LoadOrders()
        Try
            Dim selectedStatus As String = TryCast(ViewState("SelectedStatus"), String)
            Dim search As String = txtOrderSearch.Text.Trim()

            Dim sql As String = "SELECT o.OrderID AS order_id, r.Username AS u_name, r.Mobileno AS mobile, o.ShippingAddress AS address, o.City AS city, o.Pincode AS pincode, " & _
                                "p.ProductName AS p_name, od.Quantity AS qty, od.TotalPrice AS total_price, o.OrderDate AS order_date, o.Status AS status, " & _
                                "ISNULL(o.PaymentType, 'COD') AS payment_type, ISNULL(o.PaymentStatus, 'Pending') AS payment_status " & _
                                "FROM orders o INNER JOIN register r ON o.UserID = r.UserID INNER JOIN order_details od ON o.OrderID = od.OrderID " & _
                                "INNER JOIN addproduct1 p ON od.ProductID = p.ProductID WHERE 1=1 "
            Dim params As New List(Of SqlParameter)()

            If Not String.IsNullOrEmpty(selectedStatus) AndAlso selectedStatus <> "ALL" Then
                sql &= " AND LOWER(ISNULL(o.Status,'')) = @st "
                params.Add(New SqlParameter("@st", selectedStatus.ToLower()))
            End If

            If Not String.IsNullOrEmpty(search) Then
                sql &= " AND (r.Username LIKE @q OR p.ProductName LIKE @q OR CAST(o.OrderID AS NVARCHAR) LIKE @q) "
                params.Add(New SqlParameter("@q", "%" & search & "%"))
            End If

            sql &= " ORDER BY o.OrderID DESC"

            Dim dt As DataTable = Db.ExecuteQuery(sql, params.ToArray())
            gvOrders.DataSource = dt
            gvOrders.DataBind()

            phEmptyOrders.Visible = (dt.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading orders", ex)
        End Try
    End Sub

    Protected Sub FilterStatus_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim btn As LinkButton = CType(sender, LinkButton)
        ViewState("SelectedStatus") = btn.CommandArgument

        ' Highlight active tab
        tabAll.CssClass = "fk-tab"
        tabPending.CssClass = "fk-tab"
        tabConfirmed.CssClass = "fk-tab"
        tabShipped.CssClass = "fk-tab"
        tabOutForDelivery.CssClass = "fk-tab"
        tabDelivered.CssClass = "fk-tab"
        tabCancelled.CssClass = "fk-tab"
        btn.CssClass = "fk-tab active"

        gvOrders.PageIndex = 0
        LoadOrders()
    End Sub

    Protected Sub btnSearchOrder_Click(ByVal sender As Object, ByVal e As EventArgs)
        gvOrders.PageIndex = 0
        LoadOrders()
    End Sub

    Protected Sub gvOrders_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SetPaymentStatus" Then
            Dim args() As String = Convert.ToString(e.CommandArgument).Split("|"c)
            Dim orderId As Integer
            If args.Length <> 2 OrElse Not Integer.TryParse(args(0), orderId) Then Return
            Dim newPaymentStatus As String = PaymentStatusNames.Normalize(args(1))
            If Not PaymentStatusNames.IsValid(newPaymentStatus) Then Return

            Try
                Dim affected As Integer = Db.ExecuteNonQuery("UPDATE orders SET PaymentStatus = @PaymentStatus WHERE OrderID = @OrderID AND LOWER(ISNULL(PaymentStatus,'')) <> @NewStatusLower",
                                                            Db.CreateParam("@PaymentStatus", SqlDbType.NVarChar, newPaymentStatus, 50),
                                                            Db.CreateParam("@OrderID", SqlDbType.Int, orderId),
                                                            Db.CreateParam("@NewStatusLower", SqlDbType.NVarChar, newPaymentStatus.ToLower(), 50))
                If affected = 0 Then
                    Toast.Show(Me, "Payment status is already " & newPaymentStatus & ".", Toast.ToastType.Warning)
                    Return
                End If

                Dim customer As DataTable = Db.ExecuteQuery("SELECT r.Username, r.Email, o.PaymentType, o.TotalAmount FROM orders o INNER JOIN register r ON r.UserID = o.UserID WHERE o.OrderID = @OrderID",
                                                            Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                If customer.Rows.Count > 0 Then
                    Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(customer.Rows(0)("Username")))
                    Dim userEmail As String = Convert.ToString(customer.Rows(0)("Email"))
                    Dim payMethod As String = PaymentService.GetPaymentMethodDisplay(Convert.ToString(customer.Rows(0)("PaymentType")))
                    Dim totalAmt As String = If(Not IsDBNull(customer.Rows(0)("TotalAmount")), Convert.ToDecimal(customer.Rows(0)("TotalAmount")).ToString("N2"), "0.00")
                    Dim invoiceUrl As String = Request.Url.GetLeftPart(UriPartial.Authority) & ResolveUrl("~/Customer/invoice.aspx?id=" & orderId)

                    Dim emailSubject As String = "Payment status updated for order #" & orderId.ToString()
                    Dim emailBody As String = Mailer.Wrap("Payment Status Updated",
                        "<p>Hello " & safeUsername & ",</p>" & _
                        "<p>The payment status for your order <strong>#" & orderId.ToString() & "</strong> has been updated to: <span style='font-size:16px;font-weight:bold;color:#253044;'>" & HttpUtility.HtmlEncode(newPaymentStatus) & "</span>.</p>" & _
                        "<p><strong>Payment Method:</strong> " & HttpUtility.HtmlEncode(payMethod) & "<br/>" & _
                        "<strong>Total Amount:</strong> Rs " & totalAmt & "</p>" & _
                        "<p><a href='" & HttpUtility.HtmlAttributeEncode(invoiceUrl) & "' style='display:inline-block;background:#253044;color:#fff;padding:12px 20px;text-decoration:none;border-radius:6px;'>View Order Invoice</a></p>")

                    Mailer.SendAsync(userEmail, emailSubject, emailBody, "PaymentStatus")
                End If

                ' Record update in order history
                Db.ExecuteNonQuery("INSERT INTO OrderStatusHistory (OrderID, Status, Notes, UpdatedBy) " & _
                                   "SELECT OrderID, Status, @Notes, @UserID FROM orders WHERE OrderID = @OrderID",
                                   Db.CreateParam("@Notes", SqlDbType.NVarChar, "Payment status updated to " & newPaymentStatus, 255),
                                   Db.CreateParam("@UserID", SqlDbType.Int, If(Session("UserID") IsNot Nothing, Convert.ToInt32(Session("UserID")), 0)),
                                   Db.CreateParam("@OrderID", SqlDbType.Int, orderId))

                Toast.Show(Me, "Payment status updated to " & newPaymentStatus & " for order #" & orderId.ToString() & ".", Toast.ToastType.Success)
                LoadOrders()
            Catch ex As Exception
                Logger.LogError("Error updating payment status for order " & orderId, ex)
                Toast.Show(Me, "Could not update payment status. Please try again.", Toast.ToastType.Error)
            End Try
            Return
        End If

        If e.CommandName = "SetStatus" Then
            Dim args() As String = Convert.ToString(e.CommandArgument).Split("|"c)
            If args.Length = 2 Then
                Dim orderId As Integer = Convert.ToInt32(args(0))
                Dim newStatus As String = args(1)
                If Not {"Confirmed", "Shipped", "Out for delivery", "Delivered", "Cancelled"}.Contains(newStatus) Then Return

                Try
                    ' If cancelling, restore product stock
                    Using conn As SqlConnection = Db.GetConnection()
                        Using transaction As SqlTransaction = conn.BeginTransaction()
                            If newStatus.Equals("Cancelled", StringComparison.OrdinalIgnoreCase) Then
                                Using statusCmd As New SqlCommand("UPDATE orders SET Status = 'Cancelled' WHERE OrderID = @OrderID AND Status <> 'Cancelled' AND Status <> 'Delivered'", conn, transaction)
                                    statusCmd.Parameters.AddWithValue("@OrderID", orderId)
                                    If statusCmd.ExecuteNonQuery() = 0 Then
                                        transaction.Rollback()
                                        Toast.Show(Me, "This order can no longer be cancelled.", Toast.ToastType.Warning)
                                        Return
                                    End If
                                End Using

                                Using detailsCmd As New SqlCommand("SELECT ProductID, Quantity FROM order_details WHERE OrderID = @OrderID", conn, transaction)
                                    detailsCmd.Parameters.AddWithValue("@OrderID", orderId)
                                    Dim details As New DataTable()
                                    Using adapter As New SqlDataAdapter(detailsCmd)
                                        adapter.Fill(details)
                                    End Using
                                    For Each detail As DataRow In details.Rows
                                        Using stockCmd As New SqlCommand("UPDATE addproduct1 SET Stock = Stock + @Quantity WHERE ProductID = @ProductID", conn, transaction)
                                            stockCmd.Parameters.AddWithValue("@Quantity", Convert.ToInt32(detail("Quantity")))
                                            stockCmd.Parameters.AddWithValue("@ProductID", Convert.ToInt32(detail("ProductID")))
                                            stockCmd.ExecuteNonQuery()
                                        End Using
                                    Next
                                End Using
                            Else
                                Using statusCmd As New SqlCommand("UPDATE orders SET Status = @Status WHERE OrderID = @OrderID AND Status <> 'Cancelled'", conn, transaction)
                                    statusCmd.Parameters.AddWithValue("@Status", newStatus)
                                    statusCmd.Parameters.AddWithValue("@OrderID", orderId)
                                    If statusCmd.ExecuteNonQuery() = 0 Then
                                        transaction.Rollback()
                                        Toast.Show(Me, "The order status could not be changed.", Toast.ToastType.Warning)
                                        Return
                                    End If

                                    If newStatus.Equals("Delivered", StringComparison.OrdinalIgnoreCase) Then
                                        Using codPaymentCmd As New SqlCommand("UPDATE orders SET PaymentStatus = 'Paid' WHERE OrderID = @OrderID AND PaymentType = 'COD' AND LOWER(ISNULL(PaymentStatus,'')) = 'pending'", conn, transaction)
                                            codPaymentCmd.Parameters.AddWithValue("@OrderID", orderId)
                                            codPaymentCmd.ExecuteNonQuery()
                                        End Using
                                    End If
                                End Using
                            End If
                            Using historyCmd As New SqlCommand("INSERT INTO OrderStatusHistory (OrderID, Status, Notes) VALUES (@OrderID, @Status, @Notes)", conn, transaction)
                                historyCmd.Parameters.AddWithValue("@OrderID", orderId)
                                historyCmd.Parameters.AddWithValue("@Status", newStatus)
                                historyCmd.Parameters.AddWithValue("@Notes", "Order status updated by admin")
                                historyCmd.ExecuteNonQuery()
                            End Using
                            transaction.Commit()
                        End Using
                    End Using
                    If newStatus.Equals("Cancelled", StringComparison.OrdinalIgnoreCase) Then
                        Dim restoredProducts As DataTable = Db.ExecuteQuery("SELECT DISTINCT ProductID FROM order_details WHERE OrderID = @OrderID", Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                        For Each restoredProduct As DataRow In restoredProducts.Rows
                            StockNotificationService.NotifyIfBackInStock(Convert.ToInt32(restoredProduct("ProductID")), Me)
                        Next
                    End If
                    Try
                        Dim orderCustomer As DataTable = Db.ExecuteQuery("SELECT o.UserID, r.Username, r.Email FROM orders o INNER JOIN register r ON o.UserID = r.UserID WHERE o.OrderID = @OrderID",
                                                                         Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                        If orderCustomer.Rows.Count > 0 Then
                            Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(orderCustomer.Rows(0)("Username")))
                            Dim ratingButton As String = ""
                            If newStatus.Equals("Delivered", StringComparison.OrdinalIgnoreCase) Then
                                Dim reviewUrl As String = Request.Url.GetLeftPart(UriPartial.Authority) & ResolveUrl("~/Customer/feedback.aspx")
                                ratingButton = "<p><a href='" & HttpUtility.HtmlAttributeEncode(reviewUrl) & "' style='display:inline-block;background:#253044;color:#fff;padding:12px 20px;text-decoration:none;border-radius:6px;'>Rate your products</a></p>"
                            End If
                            Mailer.SendAsync(Convert.ToString(orderCustomer.Rows(0)("Email")), "Order #" & orderId.ToString() & " " & newStatus,
                                             Mailer.Wrap("Order status updated",
                                                         "<p>Hello " & safeUsername & ", the status of your order #" & orderId.ToString() & " is now <strong>" & HttpUtility.HtmlEncode(newStatus) & "</strong>.</p>" & ratingButton),
                                             "OrderStatus")
                        End If
                    Catch notificationEx As Exception
                        Logger.LogError("Error preparing status notification for order " & orderId, notificationEx)
                    End Try
                    Toast.Show(Me, "Order #" & orderId & " status updated to " & newStatus, Toast.ToastType.Success)
                    LoadOrders()
                Catch ex As Exception
                    Logger.LogError("Error updating order status", ex)
                    Toast.Show(Me, "Failed to update order status: " & ex.Message, Toast.ToastType.Error)
                End Try
            End If
        End If
    End Sub

    Protected Sub gvOrders_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvOrders.PageIndex = e.NewPageIndex
        LoadOrders()
    End Sub

    Public Function GetPaymentStatusBadgeClass(ByVal pStatus As Object) As String
        Dim st As String = Convert.ToString(pStatus).ToLower()
        If st = "paid" Then Return "badge badge-success"
        If st = "pending" Then Return "badge badge-warning"
        If st = "refunded" Then Return "badge badge-info"
        If st = "failed" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function

    Public Function GetPaymentMethodDisplay(ByVal methodVal As Object) As String
        Return PaymentService.GetPaymentMethodDisplay(Convert.ToString(methodVal))
    End Function

    Public Function GetStatusBadgeClass(ByVal statusVal As Object) As String
        Dim st As String = Convert.ToString(statusVal).ToLower()
        If st = "pending" Then Return "badge badge-warning"
        If st = "confirmed" Then Return "badge badge-primary"
        If st = "shipped" Then Return "badge badge-info"
        If st = "out for delivery" Then Return "badge badge-info"
        If st = "delivered" Then Return "badge badge-success"
        If st = "cancelled" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function
End Class
