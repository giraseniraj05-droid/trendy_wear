Public Class Admin
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim role As String = Convert.ToString(Session("role"))
        If Not role.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
        End If
    End Sub
End Class
