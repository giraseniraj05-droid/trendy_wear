<%@ Page Title="Coupons" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="Coupons.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminCoupons" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header mb-4"><h1 class="dash-title">Coupons</h1><p class="dash-subtitle">Create offers and disable coupons that should no longer be used.</p></div>
    <asp:Label ID="lblMessage" runat="server" CssClass="display-block mb-3"></asp:Label>
    <div class="fk-card mb-4 admin-form-card admin-coupon-form">
        <div class="fk-card-header"><h2 class="fk-card-title">Create coupon</h2></div>
        <div class="fk-card-body">
            <div class="grid-3-col mb-3">
                <div class="form-group"><label class="form-label">Code</label><asp:TextBox ID="txtCode" runat="server" CssClass="fk-input" MaxLength="50"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Discount type</label><asp:DropDownList ID="ddlDiscountType" runat="server" CssClass="fk-select"><asp:ListItem>Percentage</asp:ListItem><asp:ListItem>Fixed</asp:ListItem></asp:DropDownList></div>
                <div class="form-group"><label class="form-label">Discount value</label><asp:TextBox ID="txtDiscountValue" runat="server" CssClass="fk-input" TextMode="Number"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Minimum order amount</label><asp:TextBox ID="txtMinimum" runat="server" CssClass="fk-input" TextMode="Number" Text="0"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Maximum discount (optional)</label><asp:TextBox ID="txtMaximum" runat="server" CssClass="fk-input" TextMode="Number"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Expires on</label><asp:TextBox ID="txtExpiry" runat="server" CssClass="fk-input" TextMode="Date"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Usage limit</label><asp:TextBox ID="txtUsageLimit" runat="server" CssClass="fk-input" TextMode="Number" Text="100"></asp:TextBox></div>
            </div>
            <asp:Button ID="btnCreate" runat="server" Text="Create coupon" CssClass="fk-btn fk-btn-primary" OnClick="btnCreate_Click" />
        </div>
    </div>
    <div class="fk-card admin-data-card"><div class="fk-card-header"><h2 class="fk-card-title">Coupon list</h2></div><div class="fk-card-body p-0"><div class="admin-table-scroll">
        <asp:GridView ID="gvCoupons" runat="server" AutoGenerateColumns="False" CssClass="fk-table" DataKeyNames="CouponID" OnRowCommand="gvCoupons_RowCommand">
            <Columns>
                <asp:BoundField DataField="CouponCode" HeaderText="Code" />
                <asp:BoundField DataField="DiscountType" HeaderText="Type" />
                <asp:BoundField DataField="DiscountValue" HeaderText="Value" />
                <asp:BoundField DataField="MinOrderAmount" HeaderText="Minimum" />
                <asp:BoundField DataField="ExpiryDate" HeaderText="Expiry" DataFormatString="{0:dd MMM yyyy}" />
                <asp:BoundField DataField="Usage" HeaderText="Used / Limit" />
                <asp:BoundField DataField="IsActive" HeaderText="Active" />
                <asp:TemplateField><ItemTemplate><asp:LinkButton ID="btnDisable" runat="server" CommandName="DisableCoupon" CommandArgument='<%# Eval("CouponID") %>' CssClass="fk-btn-sm fk-btn-danger" Visible='<%# Convert.ToBoolean(Eval("IsActive")) %>' OnClientClick="return confirm('Disable this coupon?');">Disable</asp:LinkButton></ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div></div></div>
</asp:Content>
