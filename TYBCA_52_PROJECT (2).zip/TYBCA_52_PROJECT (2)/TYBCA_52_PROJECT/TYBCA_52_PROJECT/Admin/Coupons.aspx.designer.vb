Option Strict On
Option Explicit On

Partial Public Class AdminCoupons
    Protected WithEvents lblMessage As Global.System.Web.UI.WebControls.Label
    Protected WithEvents txtCode As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlDiscountType As Global.System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtDiscountValue As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMinimum As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMaximum As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtExpiry As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUsageLimit As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents btnCreate As Global.System.Web.UI.WebControls.Button
    Protected WithEvents gvCoupons As Global.System.Web.UI.WebControls.GridView
End Class
