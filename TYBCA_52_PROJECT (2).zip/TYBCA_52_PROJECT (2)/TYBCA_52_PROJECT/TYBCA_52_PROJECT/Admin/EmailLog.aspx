<%@ Page Title="Email Log" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="EmailLog.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminEmailLog" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">Email Log</h1>
            <p class="dash-subtitle">Review email delivery results and test the current SMTP configuration.</p>
        </div>
        <asp:Button ID="btnSendTest" runat="server" Text="Send test email" CssClass="fk-btn fk-btn-primary" OnClick="btnSendTest_Click" />
    </div>

    <div class="fk-card admin-data-card">
        <div class="fk-card-body p-0">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvEmailLog" runat="server" AutoGenerateColumns="False" CssClass="fk-table" AllowPaging="True" PageSize="25" OnPageIndexChanging="gvEmailLog_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="CreatedOn" HeaderText="Date" DataFormatString="{0:dd MMM yyyy HH:mm:ss}" />
                    <asp:BoundField DataField="ToEmail" HeaderText="Recipient" />
                    <asp:BoundField DataField="Type" HeaderText="Type" />
                    <asp:BoundField DataField="Subject" HeaderText="Subject" />
                    <asp:TemplateField HeaderText="Result">
                        <ItemTemplate>
                            <span class='<%# If(Convert.ToBoolean(Eval("Success")), "badge badge-success", "badge badge-danger") %>'>
                                <%# If(Convert.ToBoolean(Eval("Success")), "Sent", "Failed") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="Error" HeaderText="Error" />
                </Columns>
                <PagerStyle CssClass="fk-pagination" />
            </asp:GridView>
            </div>
            <asp:PlaceHolder ID="phEmptyLog" runat="server" Visible="false">
                <div class="empty-state p-4 text-center">
                    <p class="fk-text-muted">No email attempts have been logged.</p>
                </div>
            </asp:PlaceHolder>
        </div>
    </div>
</asp:Content>
