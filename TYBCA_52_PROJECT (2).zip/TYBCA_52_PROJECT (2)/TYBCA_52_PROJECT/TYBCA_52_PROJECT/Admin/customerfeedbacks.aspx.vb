Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.UI.WebControls
Imports TYBCA_52_PROJECT.Helpers

Public Class customerfeedbacks
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadProductFilter()
            LoadSummary()
            LoadProductReviews()
            LoadFeedbacks()
        End If
    End Sub

    Private Sub LoadProductFilter()
        Dim products As DataTable = Db.ExecuteQuery("SELECT DISTINCT p.ProductID, p.ProductName FROM Reviews r INNER JOIN addproduct1 p ON p.ProductID = r.ProductID ORDER BY p.ProductName")
        ddlProductFilter.Items.Clear()
        ddlProductFilter.Items.Add(New ListItem("All products", ""))
        For Each row As DataRow In products.Rows
            ddlProductFilter.Items.Add(New ListItem(Convert.ToString(row("ProductName")), Convert.ToString(row("ProductID"))))
        Next
    End Sub

    Private Sub LoadSummary()
        Dim summary As DataTable = Db.ExecuteQuery("SELECT ISNULL(AVG(CAST(Rating AS DECIMAL(10,2))), 0) AS AverageRating FROM Reviews WHERE IsApproved = 1")
        litAverageRating.Text = Convert.ToDecimal(summary.Rows(0)("AverageRating")).ToString("0.0")
        litPendingReviews.Text = Convert.ToString(Db.ExecuteScalar("SELECT COUNT(*) FROM Reviews WHERE IsApproved = 0"))
    End Sub

    Private Sub LoadProductReviews()
        Try
            Dim sql As String = "SELECT r.ReviewID, p.ProductName, u.Username, u.Email, r.Rating, r.Comment, r.CreatedOn, r.IsApproved, r.AdminReply, " & _
                                "CASE WHEN r.IsApproved = 1 THEN 'Approved' ELSE 'Pending/hidden' END AS ReviewStatus " & _
                                "FROM Reviews r INNER JOIN addproduct1 p ON p.ProductID = r.ProductID " & _
                                "INNER JOIN register u ON u.UserID = r.UserID WHERE 1=1 "
            Dim parameters As New System.Collections.Generic.List(Of SqlParameter)()
            If Not String.IsNullOrEmpty(ddlRatingFilter.SelectedValue) Then
                sql &= " AND r.Rating = @Rating"
                parameters.Add(Db.CreateParam("@Rating", SqlDbType.Int, Convert.ToInt32(ddlRatingFilter.SelectedValue)))
            End If
            If Not String.IsNullOrEmpty(ddlProductFilter.SelectedValue) Then
                sql &= " AND r.ProductID = @ProductID"
                parameters.Add(Db.CreateParam("@ProductID", SqlDbType.Int, Convert.ToInt32(ddlProductFilter.SelectedValue)))
            End If
            If Not String.IsNullOrEmpty(ddlStatusFilter.SelectedValue) Then
                sql &= " AND r.IsApproved = @IsApproved"
                parameters.Add(Db.CreateParam("@IsApproved", SqlDbType.Bit, ddlStatusFilter.SelectedValue = "1"))
            End If
            sql &= " ORDER BY r.CreatedOn DESC"

            Dim reviews As DataTable = Db.ExecuteQuery(sql, parameters.ToArray())
            gvProductReviews.DataSource = reviews
            gvProductReviews.DataBind()
            phEmptyProductReviews.Visible = (reviews.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading product reviews", ex)
            Toast.Show(Me, "Could not load product reviews.", ToastType.Error)
        End Try
    End Sub

    Private Sub LoadFeedbacks()
        Try
            Dim dt As DataTable = Db.ExecuteQuery("SELECT f.FeedbackID AS f_id, r.Username AS u_name, r.Email AS email, f.Rating AS rating, f.Comments AS message, f.DateSubmitted AS created_at " & _
                                                  "FROM Feedback f LEFT JOIN register r ON f.UserID = r.UserID ORDER BY f.FeedbackID DESC")
            gvFeedbacks.DataSource = dt
            gvFeedbacks.DataBind()
            phEmptyFeedback.Visible = (dt.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading feedbacks", ex)
            Toast.Show(Me, "Could not load general feedback.", ToastType.Error)
        End Try
    End Sub

    Protected Sub btnProductReviewsTab_Click(ByVal sender As Object, ByVal e As EventArgs)
        pnlProductReviews.Visible = True
        pnlGeneralFeedback.Visible = False
        LoadProductReviews()
    End Sub

    Protected Sub btnGeneralFeedbackTab_Click(ByVal sender As Object, ByVal e As EventArgs)
        pnlProductReviews.Visible = False
        pnlGeneralFeedback.Visible = True
        LoadFeedbacks()
    End Sub

    Protected Sub btnReviewFilter_Click(ByVal sender As Object, ByVal e As EventArgs)
        gvProductReviews.PageIndex = 0
        LoadProductReviews()
    End Sub

    Protected Sub gvProductReviews_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvProductReviews.PageIndex = e.NewPageIndex
        LoadProductReviews()
    End Sub

    Protected Sub gvProductReviews_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim reviewId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), reviewId) OrElse reviewId <= 0 Then Return

        Try
            Select Case e.CommandName
                Case "ApproveReview"
                    Db.ExecuteNonQuery("UPDATE Reviews SET IsApproved = 1 WHERE ReviewID = @ReviewID",
                                       Db.CreateParam("@ReviewID", SqlDbType.Int, reviewId))
                    SendReviewUpdateEmail(reviewId, "Your review has been approved.", Nothing, "ReviewApproved")
                    Toast.Show(Me, "Review approved.", ToastType.Success)
                Case "HideReview"
                    Db.ExecuteNonQuery("UPDATE Reviews SET IsApproved = 0 WHERE ReviewID = @ReviewID",
                                       Db.CreateParam("@ReviewID", SqlDbType.Int, reviewId))
                    SendReviewUpdateEmail(reviewId, "Your review was rejected and is no longer visible on the store.", Nothing, "ReviewRejected")
                    Toast.Show(Me, "Review hidden.", ToastType.Info)
                Case "DeleteReview"
                    Db.ExecuteNonQuery("DELETE FROM Reviews WHERE ReviewID = @ReviewID",
                                       Db.CreateParam("@ReviewID", SqlDbType.Int, reviewId))
                    Toast.Show(Me, "Review deleted.", ToastType.Success)
                Case "ReplyReview"
                    Dim sourceControl As Control = TryCast(e.CommandSource, Control)
                    Dim gridRow As GridViewRow = If(sourceControl Is Nothing, Nothing, TryCast(sourceControl.NamingContainer, GridViewRow))
                    Dim replyBox As TextBox = If(gridRow Is Nothing, Nothing, TryCast(gridRow.FindControl("txtAdminReply"), TextBox))
                    If replyBox Is Nothing OrElse String.IsNullOrWhiteSpace(replyBox.Text) Then
                        Toast.Show(Me, "Enter a reply before saving.", ToastType.Warning)
                        Return
                    End If
                    Dim replyParam As New SqlParameter("@AdminReply", SqlDbType.NVarChar, -1)
                    replyParam.Value = replyBox.Text.Trim()
                    Db.ExecuteNonQuery("UPDATE Reviews SET AdminReply = @AdminReply, ReplyOn = GETDATE() WHERE ReviewID = @ReviewID",
                                       replyParam, Db.CreateParam("@ReviewID", SqlDbType.Int, reviewId))
                    SendReviewUpdateEmail(reviewId, "The store has replied to your review.", replyBox.Text.Trim(), "ReviewReply")
                    Toast.Show(Me, "Reply sent to the customer.", ToastType.Success)
            End Select

            LoadSummary()
            LoadProductReviews()
        Catch ex As Exception
            Logger.LogError("Error moderating review " & reviewId, ex)
            Toast.Show(Me, "Could not update this review. Please try again.", ToastType.Error)
        End Try
    End Sub

    Private Sub SendReviewUpdateEmail(ByVal reviewId As Integer, ByVal message As String, ByVal reply As String, ByVal emailType As String)
        Try
            Dim review As DataTable = Db.ExecuteQuery("SELECT u.Username, u.Email, p.ProductName FROM Reviews r INNER JOIN register u ON u.UserID = r.UserID INNER JOIN addproduct1 p ON p.ProductID = r.ProductID WHERE r.ReviewID = @ReviewID",
                                                     Db.CreateParam("@ReviewID", SqlDbType.Int, reviewId))
            If review.Rows.Count = 0 Then Return

            Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(review.Rows(0)("Username")))
            Dim safeProduct As String = HttpUtility.HtmlEncode(Convert.ToString(review.Rows(0)("ProductName")))
            Dim body As String = "<p>Hello " & safeUsername & ",</p><p>" & HttpUtility.HtmlEncode(message) & "</p><p>Product: " & safeProduct & "</p>"
            If Not String.IsNullOrWhiteSpace(reply) Then
                body &= "<blockquote>" & HttpUtility.HtmlEncode(reply).Replace(vbCrLf, "<br/>").Replace(vbLf, "<br/>") & "</blockquote>"
            End If
            Mailer.SendAsync(Convert.ToString(review.Rows(0)("Email")), "Update on your Trendy Wear review", Mailer.Wrap("Review update", body), emailType)
        Catch ex As Exception
            Logger.LogError("Error preparing customer notification for review " & reviewId, ex)
        End Try
    End Sub

    Protected Sub gvFeedbacks_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvFeedbacks.PageIndex = e.NewPageIndex
        LoadFeedbacks()
    End Sub

    Public Function GetStarRating(ByVal ratingVal As Object) As String
        Dim rating As Integer = Convert.ToInt32(ratingVal)
        Return New String("★"c, rating) & New String("☆"c, 5 - rating) & " (" & rating.ToString() & "/5)"
    End Function
End Class
