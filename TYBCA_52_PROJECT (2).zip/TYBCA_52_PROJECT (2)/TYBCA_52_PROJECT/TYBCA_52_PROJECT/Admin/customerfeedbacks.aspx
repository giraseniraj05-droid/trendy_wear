<%@ Page Title="Customer Feedbacks" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="customerfeedbacks.aspx.vb" Inherits="TYBCA_52_PROJECT.customerfeedbacks" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">💬 Customer Reviews &amp; Feedbacks</h1>
            <p class="dash-subtitle">Moderate product reviews and review customer feedback.</p>
        </div>
    </div>

    <div class="grid-2-col mb-4">
        <div class="fk-card p-3"><span class="fk-text-muted">Average approved rating</span><div class="text-xl font-bold fk-text-warning"><asp:Literal ID="litAverageRating" runat="server">0.0</asp:Literal> / 5</div></div>
        <div class="fk-card p-3"><span class="fk-text-muted">Pending product reviews</span><div class="text-xl font-bold"><asp:Literal ID="litPendingReviews" runat="server">0</asp:Literal></div></div>
    </div>

    <div class="flex-gap mb-3">
        <asp:LinkButton ID="btnProductReviewsTab" runat="server" CssClass="fk-btn fk-btn-primary" OnClick="btnProductReviewsTab_Click">Product Reviews</asp:LinkButton>
        <asp:LinkButton ID="btnGeneralFeedbackTab" runat="server" CssClass="fk-btn fk-btn-outline" OnClick="btnGeneralFeedbackTab_Click">General Feedback</asp:LinkButton>
    </div>

    <asp:Panel ID="pnlProductReviews" runat="server">
        <div class="fk-card mb-3 admin-filter-card">
            <div class="fk-card-body p-3 flex-gap flex-wrap admin-review-filters">
                <asp:DropDownList ID="ddlRatingFilter" runat="server" CssClass="fk-select">
                    <asp:ListItem Value="">All ratings</asp:ListItem>
                    <asp:ListItem Value="5">5 stars</asp:ListItem><asp:ListItem Value="4">4 stars</asp:ListItem>
                    <asp:ListItem Value="3">3 stars</asp:ListItem><asp:ListItem Value="2">2 stars</asp:ListItem>
                    <asp:ListItem Value="1">1 star</asp:ListItem>
                </asp:DropDownList>
                <asp:DropDownList ID="ddlProductFilter" runat="server" CssClass="fk-select"></asp:DropDownList>
                <asp:DropDownList ID="ddlStatusFilter" runat="server" CssClass="fk-select">
                    <asp:ListItem Value="">All statuses</asp:ListItem>
                    <asp:ListItem Value="0">Pending/hidden</asp:ListItem>
                    <asp:ListItem Value="1">Approved</asp:ListItem>
                </asp:DropDownList>
                <asp:Button ID="btnReviewFilter" runat="server" Text="Apply filters" CssClass="fk-btn fk-btn-primary" OnClick="btnReviewFilter_Click" />
            </div>
        </div>
        <div class="fk-card">
            <div class="fk-card-body p-0">
                <div class="admin-table-scroll">
                <asp:GridView ID="gvProductReviews" runat="server" AutoGenerateColumns="False" CssClass="fk-table"
                              AllowPaging="True" PageSize="10" DataKeyNames="ReviewID"
                              OnRowCommand="gvProductReviews_RowCommand" OnPageIndexChanging="gvProductReviews_PageIndexChanging">
                    <Columns>
                        <asp:BoundField DataField="ProductName" HeaderText="Product" />
                        <asp:BoundField DataField="Username" HeaderText="Customer" />
                        <asp:TemplateField HeaderText="Stars"><ItemTemplate><span class="fk-text-warning admin-star-rating"><%# GetStarRating(Eval("Rating")) %></span></ItemTemplate></asp:TemplateField>
                        <asp:BoundField DataField="Comment" HeaderText="Comment" />
                        <asp:BoundField DataField="CreatedOn" HeaderText="Date" DataFormatString="{0:dd MMM yyyy}" />
                        <asp:BoundField DataField="ReviewStatus" HeaderText="Status" />
                        <asp:TemplateField HeaderText="Moderation &amp; Reply">
                            <ItemTemplate>
                                <div class="flex-gap flex-wrap">
                                    <asp:LinkButton runat="server" CommandName="ApproveReview" CommandArgument='<%# Eval("ReviewID") %>' CssClass="fk-btn-sm fk-btn-primary" CausesValidation="false">Approve</asp:LinkButton>
                                    <asp:LinkButton runat="server" CommandName="HideReview" CommandArgument='<%# Eval("ReviewID") %>' CssClass="fk-btn-sm fk-btn-outline" CausesValidation="false">Hide</asp:LinkButton>
                                    <asp:LinkButton runat="server" CommandName="DeleteReview" CommandArgument='<%# Eval("ReviewID") %>' CssClass="fk-btn-sm fk-btn-danger" CausesValidation="false" OnClientClick="return confirm('Delete this review?');">Delete</asp:LinkButton>
                                </div>
                                <asp:TextBox ID="txtAdminReply" runat="server" CssClass="fk-input mt-2" TextMode="MultiLine" Rows="2" Text='<%# Bind("AdminReply") %>' placeholder="Reply to the customer"></asp:TextBox>
                                <asp:LinkButton runat="server" CommandName="ReplyReview" CommandArgument='<%# Eval("ReviewID") %>' CssClass="fk-btn-sm fk-btn-outline-primary mt-1" CausesValidation="false">Save reply</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <PagerStyle CssClass="fk-pagination" />
                </asp:GridView>
                </div>
                <asp:PlaceHolder ID="phEmptyProductReviews" runat="server" Visible="false">
                    <div class="empty-state p-4 text-center"><p class="fk-text-muted">No product reviews found.</p></div>
                </asp:PlaceHolder>
            </div>
        </div>
    </asp:Panel>

    <asp:Panel ID="pnlGeneralFeedback" runat="server" Visible="false">
        <div class="fk-card">
            <div class="fk-card-body p-0">
                <div class="admin-table-scroll">
                <asp:GridView ID="gvFeedbacks" runat="server" AutoGenerateColumns="False" CssClass="fk-table"
                              AllowPaging="True" PageSize="10" OnPageIndexChanging="gvFeedbacks_PageIndexChanging">
                    <Columns>
                        <asp:BoundField DataField="f_id" HeaderText="ID" ItemStyle-Width="60px" />
                        <asp:BoundField DataField="u_name" HeaderText="Customer Name" />
                        <asp:BoundField DataField="email" HeaderText="Email Address" />
                        <asp:TemplateField HeaderText="Rating"><ItemTemplate><span class="fk-text-warning admin-star-rating"><%# GetStarRating(Eval("rating")) %></span></ItemTemplate></asp:TemplateField>
                        <asp:BoundField DataField="message" HeaderText="Feedback Message" />
                        <asp:BoundField DataField="created_at" HeaderText="Submitted Date" DataFormatString="{0:dd MMM yyyy HH:mm}" />
                    </Columns>
                    <PagerStyle CssClass="fk-pagination" />
                </asp:GridView>
                </div>
            <asp:PlaceHolder ID="phEmptyFeedback" runat="server" Visible="false">
                <div class="empty-state p-4 text-center">
                    <p class="fk-text-muted">No feedbacks received yet.</p>
                </div>
            </asp:PlaceHolder>
            </div>
        </div>
    </asp:Panel>
</asp:Content>
