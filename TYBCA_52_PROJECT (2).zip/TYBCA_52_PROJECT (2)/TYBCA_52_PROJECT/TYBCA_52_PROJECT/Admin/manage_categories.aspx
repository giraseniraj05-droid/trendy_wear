<%@ Page Title="Category Management" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master" CodeBehind="manage_categories.aspx.vb" Inherits="TYBCA_52_PROJECT.manage_categories" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="admin-card fk-card admin-category-card">
        <h2>Manage Categories</h2>
        <asp:Label ID="lblMsg" runat="server" Visible="false"></asp:Label>

        <div class="category-form-row admin-category-form">
            <asp:TextBox ID="txtCategoryName" runat="server" CssClass="form-control" Placeholder="Category Name (e.g. Footwear)" MaxLength="100"></asp:TextBox>
            <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" Placeholder="Description"></asp:TextBox>
            <asp:Button ID="btnAddCategory" runat="server" Text="Add Category" CssClass="btn btn-primary" OnClick="btnAddCategory_Click" />
        </div>

        <div class="admin-table-scroll">
        <table class="table admin-category-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category Name</th>
                    <th>Description</th>
                    <th>Created On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <asp:Repeater ID="rptCategories" runat="server">
                    <ItemTemplate>
                        <tr>
                            <td><%# Eval("CategoryID") %></td>
                            <td><strong><%# Eval("CategoryName") %></strong></td>
                            <td><%# Eval("Description") %></td>
                            <td><%# Convert.ToDateTime(Eval("CreatedOn")).ToString("dd-MMM-yyyy") %></td>
                            <td>
                                <asp:Button ID="btnDelete" runat="server" Text="Delete" CssClass="btn btn-danger btn-sm" CommandArgument='<%# Eval("CategoryID") %>' OnClick="btnDelete_Click" OnClientClick="return confirm('Are you sure?');" />
                            </td>
                        </tr>
                    </ItemTemplate>
                </asp:Repeater>
            </tbody>
        </table>
        </div>
    </div>
</asp:Content>
