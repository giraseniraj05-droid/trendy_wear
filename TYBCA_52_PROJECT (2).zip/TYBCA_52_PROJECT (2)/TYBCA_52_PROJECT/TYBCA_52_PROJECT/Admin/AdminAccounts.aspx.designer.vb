Option Strict On
Option Explicit On

    Partial Public Class AdminAccounts
        Protected WithEvents lblMsg As Global.System.Web.UI.WebControls.Label
        Protected WithEvents hfRequestToken As Global.System.Web.UI.WebControls.HiddenField
        Protected WithEvents hfEditAdminId As Global.System.Web.UI.WebControls.HiddenField
        Protected WithEvents hfResetAdminId As Global.System.Web.UI.WebControls.HiddenField
        Protected WithEvents txtMyUsername As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMyEmail As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtCurrentPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMyNewPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMyConfirmPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents btnSaveMyAccount As Global.System.Web.UI.WebControls.Button
        Protected WithEvents txtNewFullName As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewUsername As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewEmail As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewMobile As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewConfirmPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents btnAddAdmin As Global.System.Web.UI.WebControls.Button
        Protected WithEvents pnlEditAdmin As Global.System.Web.UI.WebControls.Panel
        Protected WithEvents txtEditFullName As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEditEmail As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents btnSaveEdit As Global.System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelEdit As Global.System.Web.UI.WebControls.Button
        Protected WithEvents pnlResetPassword As Global.System.Web.UI.WebControls.Panel
        Protected WithEvents txtResetPassword As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents txtResetConfirm As Global.System.Web.UI.WebControls.TextBox
        Protected WithEvents btnSaveReset As Global.System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelReset As Global.System.Web.UI.WebControls.Button
        Protected WithEvents gvAdmins As Global.System.Web.UI.WebControls.GridView
    End Class
