<%@ Page Title="Manage Customers" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="customers.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminCustomers" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">👥 Registered Customers</h1>
            <p class="dash-subtitle">Update customer details, delete accounts, or reactivate them. Deleting deactivates the account and retains its order history.</p>
        </div>
        <div class="kpi-card-inline">
            <span class="kpi-label">Total Registered Customers:</span>
            <strong class="fk-text-primary text-xl"><asp:Literal ID="litTotalCustCount" runat="server">0</asp:Literal></strong>
        </div>
    </div>

    <asp:Label ID="lblMsg" runat="server" Visible="false" CssClass="alert mb-3"></asp:Label>

    <!-- Search & Filter Bar -->
    <div class="fk-card mb-4 admin-filter-card">
        <div class="fk-card-body p-3">
            <div class="flex-between flex-wrap gap-2">
                <div class="search-box-wrap flex-gap flex-1 admin-search-bar">
                    <asp:TextBox ID="txtSearch" runat="server" CssClass="fk-input admin-search-input" placeholder="Search by name, email, or mobile..."></asp:TextBox>
                    <asp:Button ID="btnSearch" runat="server" Text="🔍 Search" CssClass="fk-btn fk-btn-primary" OnClick="btnSearch_Click" />
                    <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="fk-btn fk-btn-outline" OnClick="btnReset_Click" />
                </div>
            </div>
        </div>
    </div>

    <!-- Customers Table -->
    <div class="fk-card mb-4 admin-data-card">
        <div class="fk-card-body p-0">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvCustomers" runat="server" AutoGenerateColumns="False" 
                          CssClass="fk-table" AllowPaging="True" PageSize="10" 
                          OnPageIndexChanging="gvCustomers_PageIndexChanging"
                          OnRowEditing="gvCustomers_RowEditing"
                          OnRowCancelingEdit="gvCustomers_RowCancelingEdit"
                          OnRowUpdating="gvCustomers_RowUpdating"
                          OnRowCommand="gvCustomers_RowCommand"
                          DataKeyNames="u_id">
                <Columns>
                    <asp:BoundField DataField="u_id" HeaderText="ID" SortExpression="u_id" />
                    <asp:TemplateField HeaderText="Customer Name">
                        <ItemTemplate>
                            <strong><%#: Eval("FullName") %></strong>
                            <div class="fk-text-muted text-xs"><%#: Eval("u_name") %></div>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtFullName" runat="server" CssClass="fk-input mb-2" MaxLength="100" Text='<%# Bind("FullName") %>' placeholder="Full name"></asp:TextBox>
                            <asp:TextBox ID="txtUsername" runat="server" CssClass="fk-input" MaxLength="100" Text='<%# Bind("u_name") %>' placeholder="Username"></asp:TextBox>
                        </EditItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Email Address">
                        <ItemTemplate>
                            <%#: Eval("email") %>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtEmail" runat="server" CssClass="fk-input" MaxLength="255" Text='<%# Bind("email") %>' TextMode="Email"></asp:TextBox>
                        </EditItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Mobile">
                        <ItemTemplate><%#: Eval("mobile") %></ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtMobile" runat="server" CssClass="fk-input" MaxLength="15" Text='<%# Bind("mobile") %>'></asp:TextBox>
                        </EditItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='<%# If(Convert.ToBoolean(Eval("IsActive")), "badge badge-success", "badge badge-warning") %>'>
                                <%# If(Convert.ToBoolean(Eval("IsActive")), "Active", "Inactive") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="CreatedOn" HeaderText="Joined Date" DataFormatString="{0:dd MMM yyyy}" />
                    <asp:BoundField DataField="OrderCount" HeaderText="Total Orders" />
                    <asp:TemplateField HeaderText="Total Spent">
                        <ItemTemplate>
                            <strong>Rs <%# String.Format("{0:N0}", Eval("TotalSpent")) %></strong>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Actions">
                        <ItemTemplate>
                            <asp:LinkButton ID="btnEdit" runat="server" CommandName="Edit" CssClass="fk-btn fk-btn-outline-primary" Text="Edit" CausesValidation="false"></asp:LinkButton>
                            <asp:LinkButton ID="btnToggleActive" runat="server"
                                CommandName='<%# If(Convert.ToBoolean(Eval("IsActive")), "DeleteCustomer", "ReactivateCustomer") %>' CommandArgument='<%# Eval("u_id") %>'
                                CssClass="fk-btn fk-btn-outline" Text='<%# If(Convert.ToBoolean(Eval("IsActive")), "Delete", "Reactivate") %>'
                                OnClientClick="return confirm('Change this customer account status?');" CausesValidation="false"></asp:LinkButton>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:LinkButton ID="btnSave" runat="server" CommandName="Update" CssClass="fk-btn fk-btn-primary" Text="Save"></asp:LinkButton>
                            <asp:LinkButton ID="btnCancel" runat="server" CommandName="Cancel" CssClass="fk-btn fk-btn-outline" Text="Cancel" CausesValidation="false"></asp:LinkButton>
                        </EditItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <PagerStyle CssClass="fk-pagination" />
            </asp:GridView>
            </div>
            <asp:PlaceHolder ID="phEmptyCustomers" runat="server" Visible="false">
                <div class="empty-state p-4 text-center">
                    <p class="fk-text-muted">No customer accounts found.</p>
                </div>
            </asp:PlaceHolder>
        </div>
    </div>
</asp:Content>
