Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers

Public Class manage_categories
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase) Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If

        If Not IsPostBack Then
            LoadCategories()
        End If
    End Sub

    Private Sub LoadCategories()
        Try
            Dim dt As DataTable = Db.GetDataTable("SELECT * FROM Categories WHERE IsActive = 1 ORDER BY DisplayOrder, CategoryName")
            rptCategories.DataSource = dt
            rptCategories.DataBind()
        Catch ex As Exception
            Logger.LogException(ex, "LoadCategories error")
        End Try
    End Sub

    Protected Sub btnAddCategory_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddCategory.Click
        Dim catName As String = txtCategoryName.Text.Trim()
        Dim desc As String = txtDescription.Text.Trim()

        If String.IsNullOrEmpty(catName) Then Return

        Try
            Db.ExecuteNonQuery("INSERT INTO Categories (CategoryName, Description) VALUES (@Name, @Desc)",
                              New SqlParameter() {
                                  Db.CreateParam("@Name", SqlDbType.NVarChar, catName, 100),
                                  Db.CreateParam("@Desc", SqlDbType.NVarChar, desc, -1)
                              })
            txtCategoryName.Text = ""
            txtDescription.Text = ""
            LoadCategories()
        Catch ex As Exception
            Logger.LogException(ex, "Add category error")
        End Try
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim catId As Integer = Convert.ToInt32(CType(sender, Button).CommandArgument)
        Try
            Db.ExecuteNonQuery("UPDATE Categories SET IsActive = 0 WHERE CategoryID = @ID",
                              New SqlParameter() {Db.CreateParam("@ID", SqlDbType.Int, catId)})
            LoadCategories()
        Catch ex As Exception
            Logger.LogException(ex, "Delete category error")
        End Try
    End Sub
End Class
