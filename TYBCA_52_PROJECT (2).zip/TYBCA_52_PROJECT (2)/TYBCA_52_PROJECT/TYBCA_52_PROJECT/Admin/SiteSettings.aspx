<%@ Page Title="Site Settings" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="SiteSettings.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminSiteSettings" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header mb-4">
        <h1 class="dash-title">⚙️ Site Settings &amp; Branding</h1>
        <p class="dash-subtitle">Configure store name, default theme, announcement bar, delivery charges, and accent colors.</p>
    </div>

    <div class="fk-card max-w-700 admin-settings-card">
        <div class="fk-card-header">
            <h3 class="fk-card-title">Store Configuration</h3>
        </div>
        <div class="fk-card-body admin-settings-form">
            <div class="form-group mb-3">
                <label for="txtStoreName" class="form-label">Store Name:</label>
                <asp:TextBox ID="txtStoreName" runat="server" CssClass="fk-input" Text="Trendy Wear"></asp:TextBox>
            </div>

            <div class="form-group mb-3">
                <label for="txtTagline" class="form-label">Store Tagline:</label>
                <asp:TextBox ID="txtTagline" runat="server" CssClass="fk-input" Text="Explore Plus - Flipkart/Amazon Redesign"></asp:TextBox>
            </div>

            <div class="form-group mb-3">
                <label for="txtAnnouncement" class="form-label">Announcement Bar Banner:</label>
                <asp:TextBox ID="txtAnnouncement" runat="server" CssClass="fk-input" Text="🎉 Special Festivities Offer! Get Flat 15% OFF on Orders above Rs 1,999! Use Code: TRENDY15"></asp:TextBox>
            </div>

            <div class="grid-2-col mb-3">
                <div class="form-group">
                    <label for="ddlDefaultTheme" class="form-label">Default Theme:</label>
                    <asp:DropDownList ID="ddlDefaultTheme" runat="server" CssClass="fk-select">
                        <asp:ListItem Value="light">Light Mode (Flipkart Standard)</asp:ListItem>
                        <asp:ListItem Value="dark">Dark Mode</asp:ListItem>
                        <asp:ListItem Value="forest">Emerald Forest</asp:ListItem>
                        <asp:ListItem Value="rose">Velvet Rose</asp:ListItem>
                        <asp:ListItem Value="violet">Royal Violet</asp:ListItem>
                    </asp:DropDownList>
                </div>

                <div class="form-group">
                    <label for="txtBrandColor" class="form-label">Primary Brand Colour (Hex):</label>
                    <asp:TextBox ID="txtBrandColor" runat="server" CssClass="fk-input" Text="#2874f0"></asp:TextBox>
                </div>
            </div>

            <div class="grid-2-col mb-3">
                <div class="form-group">
                    <label for="txtDeliveryCharges" class="form-label">Default Delivery Fee (Rs):</label>
                    <asp:TextBox ID="txtDeliveryCharges" runat="server" CssClass="fk-input" Text="40"></asp:TextBox>
                </div>

                <div class="form-group">
                    <label for="txtFreeShippingMin" class="form-label">Free Delivery Minimum Amount (Rs):</label>
                    <asp:TextBox ID="txtFreeShippingMin" runat="server" CssClass="fk-input" Text="500"></asp:TextBox>
                </div>
            </div>

            <div class="form-actions mt-4 flex-gap">
                <asp:Button ID="btnSaveSettings" runat="server" Text="💾 Save Settings" CssClass="fk-btn fk-btn-primary" OnClick="btnSaveSettings_Click" />
                <a href="<%= ResolveUrl("~/Admin/Dashboard.aspx") %>" class="fk-btn fk-btn-outline">Cancel</a>
            </div>
        </div>
    </div>
</asp:Content>
