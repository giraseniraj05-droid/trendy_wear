<%@ Page Title="Manage Products & Stock" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="Add_Product.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">📦 Product Catalog &amp; Stock Control</h1>
            <p class="dash-subtitle">Add new inventory items, manage stock levels, update pricing, and set old MRP discount prices.</p>
        </div>
        <div class="dash-actions">
            <a href="<%= ResolveUrl("~/Admin/Dashboard.aspx") %>" class="fk-btn fk-btn-outline">&larr; Back to Dashboard</a>
        </div>
    </div>

    <!-- Product Form -->
    <div class="fk-card mb-4 admin-product-form">
        <div class="fk-card-header flex-between">
            <h3 class="fk-card-title">
                <asp:Literal ID="litFormTitle" runat="server">Add New Clothing Product</asp:Literal>
            </h3>
            <asp:Button ID="btnCancelEdit" runat="server" Text="Cancel Edit" CssClass="fk-btn-sm fk-btn-outline" Visible="false" OnClick="btnCancelEdit_Click" />
        </div>
        <div class="fk-card-body">
            <asp:HiddenField ID="hfProductID" runat="server" Value="0" />

            <div class="grid-3-col mb-3">
                <div class="form-group">
                    <label class="form-label">Product Name <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtPName" runat="server" CssClass="fk-input" placeholder="e.g. Classic Cotton Denim Shirt"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvPName" runat="server" ControlToValidate="txtPName" ErrorMessage="Product name is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ProductForm" />
                </div>

                <div class="form-group">
                    <label class="form-label">Category <span class="text-danger">*</span></label>
                    <asp:DropDownList ID="ddlCategory" runat="server" CssClass="fk-select"></asp:DropDownList>
                    <asp:RequiredFieldValidator ID="rfvCat" runat="server" ControlToValidate="ddlCategory" InitialValue="" ErrorMessage="Select a category" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ProductForm" />
                </div>

                <div class="form-group">
                    <label class="form-label">Size <span class="text-danger">*</span></label>
                    <asp:DropDownList ID="ddlSize" runat="server" CssClass="fk-select">
                        <asp:ListItem Value="">-- Select Size --</asp:ListItem>
                        <asp:ListItem Value="XS">XS</asp:ListItem>
                        <asp:ListItem Value="S">S</asp:ListItem>
                        <asp:ListItem Value="M">M</asp:ListItem>
                        <asp:ListItem Value="L">L</asp:ListItem>
                        <asp:ListItem Value="XL">XL</asp:ListItem>
                        <asp:ListItem Value="XXL">XXL</asp:ListItem>
                        <asp:ListItem Value="One Size">One Size</asp:ListItem>
                    </asp:DropDownList>
                    <asp:RequiredFieldValidator ID="rfvSize" runat="server" ControlToValidate="ddlSize" InitialValue="" ErrorMessage="Select a size" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ProductForm" />
                </div>
            </div>

            <div class="grid-3-col mb-3">
                <div class="form-group">
                    <label class="form-label">Price (Rs) <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtPrice" runat="server" CssClass="fk-input" placeholder="e.g. 799.50" TextMode="Number" step="0.01" min="0.01"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvPrice" runat="server" ControlToValidate="txtPrice" ErrorMessage="Price is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ProductForm" />
                </div>

                <div class="form-group">
                    <label class="form-label">Old MRP (Rs) <small>(For strike-through discount)</small></label>
                    <asp:TextBox ID="txtOldPrice" runat="server" CssClass="fk-input" placeholder="e.g. 1499.50" TextMode="Number" step="0.01" min="0.01"></asp:TextBox>
                </div>

                <div class="form-group">
                    <label class="form-label">Initial / Added Stock Units <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtStock" runat="server" CssClass="fk-input" placeholder="e.g. 25" TextMode="Number" Text="10" step="1" min="0"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvStock" runat="server" ControlToValidate="txtStock" ErrorMessage="Stock quantity is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="ProductForm" />
                </div>
            </div>

            <div class="grid-2-col mb-3">
                <div class="form-group admin-upload-group">
                    <label class="form-label">Product Image <small>(JPG, PNG, WebP, max 2MB)</small></label>
                    <div class="admin-upload-card">
                        <asp:FileUpload ID="fuImage" runat="server" CssClass="fk-input admin-upload-input" />
                        <asp:Label ID="lblCurrentImg" runat="server" CssClass="fk-text-muted text-xs display-block mt-1 admin-current-image"></asp:Label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Product Description</label>
                    <asp:TextBox ID="txtDetails" runat="server" CssClass="fk-input" TextMode="MultiLine" Rows="2" placeholder="Fabric, fit, care instructions..."></asp:TextBox>
                </div>
            </div>

            <div class="form-actions flex-gap mt-3">
                <asp:Button ID="btnSaveProduct" runat="server" Text="💾 Save Product" CssClass="fk-btn fk-btn-primary" ValidationGroup="ProductForm" OnClick="btnSaveProduct_Click" />
                <asp:Button ID="btnUpdateProduct" runat="server" Text="🔄 Update Product" CssClass="fk-btn fk-btn-warning" Visible="false" ValidationGroup="ProductForm" OnClick="btnUpdateProduct_Click" />
            </div>
        </div>
    </div>

    <!-- Product Grid & Stock Monitor -->
    <div class="fk-card admin-product-list-card">
        <div class="fk-card-header flex-between">
            <h3 class="fk-card-title">Inventory Items &amp; Stock Levels</h3>
            <div class="search-box-wrap flex-gap">
                <asp:TextBox ID="txtSearchFilter" runat="server" CssClass="fk-input text-sm admin-search-input" placeholder="Search catalog..."></asp:TextBox>
                <asp:Button ID="btnFilter" runat="server" Text="Search" CssClass="fk-btn-sm fk-btn-primary" OnClick="btnFilter_Click" />
            </div>
        </div>
        <div class="fk-card-body p-0">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvProducts" runat="server" AutoGenerateColumns="False" 
                          CssClass="fk-table" DataKeyNames="p_id" 
                          OnRowCommand="gvProducts_RowCommand" OnRowDeleting="gvProducts_RowDeleting"
                          AllowPaging="True" PageSize="10" OnPageIndexChanging="gvProducts_PageIndexChanging">
                <Columns>
                    <asp:TemplateField HeaderText="Product Image" ItemStyle-Width="70px">
                        <ItemTemplate>
                            <img src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' 
                                 alt='<%# Eval("p_name") %>' class="thumb-small" onerror="this.src='../Images/default.jpg';" />
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Product Name">
                        <ItemTemplate>
                            <strong><%# Eval("p_name") %></strong>
                            <div class="text-xs fk-text-muted"><%# Eval("category_name") %></div>
                            <div class="text-xs fk-text-muted">Size: <%# Eval("Size") %></div>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Price / MRP">
                        <ItemTemplate>
                            <span class="fk-text-success font-bold">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                            <%# If(Convert.ToDecimal(Eval("OldPrice")) > Convert.ToDecimal(Eval("price")), "<small class='text-mrp ml-1'>Rs " & String.Format("{0:N0}", Eval("OldPrice")) & "</small>", "") %>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Stock Availability" ItemStyle-Width="260px">
                        <ItemTemplate>
                            <div class="flex-between text-xs mb-1">
                                <span><strong class='<%# GetStockTextClass(Eval("Stock")) %>'><%# Eval("Stock") %> left</strong></span>
                                <span class="fk-text-muted">Cap: 50</span>
                            </div>
                            <div class="stock-bar-wrap">
                                <div class='<%# GetStockBarClass(Eval("Stock")) %>' style='<%# "width: " & GetStockPercentage(Eval("Stock")) & "%;" %>'></div>
                            </div>
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Actions" ItemStyle-Width="180px" ItemStyle-HorizontalAlign="Right">
                        <ItemTemplate>
                            <asp:LinkButton ID="btnEdit" runat="server" CommandName="EditProduct" CommandArgument='<%# Eval("p_id") %>' CssClass="fk-btn-sm fk-btn-outline mr-1">
                                ✏️ Edit
                            </asp:LinkButton>
                            <asp:LinkButton ID="btnDelete" runat="server" CommandName="DeleteProduct" CommandArgument='<%# Eval("p_id") %>' 
                                            CssClass="fk-btn-sm fk-btn-danger" OnClientClick="return confirm('Are you sure you want to deactivate/delete this product?');">
                                🗑️ Delete
                            </asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <PagerStyle CssClass="fk-pagination" />
            </asp:GridView>
            </div>
        </div>
    </div>
</asp:Content>
