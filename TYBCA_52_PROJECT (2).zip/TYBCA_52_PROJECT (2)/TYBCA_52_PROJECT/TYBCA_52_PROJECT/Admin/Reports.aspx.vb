Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports TYBCA_52_PROJECT.Helpers

Public Class Reports
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            ' Set default dates (Current Month)
            txtStartDate.Text = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("yyyy-MM-dd")
            txtEndDate.Text = DateTime.Now.ToString("yyyy-MM-dd")
            LoadReport()
        End If
    End Sub

    Private Sub LoadReport()
        Try
            Dim dt As DataTable = FetchReportData()
            gvReport.DataSource = dt
            gvReport.DataBind()

            phEmptyReport.Visible = (dt.Rows.Count = 0)

            ' Calculate total revenue
            Dim total As Decimal = 0
            For Each row As DataRow In dt.Rows
                If Not IsDBNull(row("total_price")) AndAlso Convert.ToString(row("status")).ToLower() <> "cancelled" Then
                    total += Convert.ToDecimal(row("total_price"))
                End If
            Next
            litReportTotal.Text = "Rs " & String.Format("{0:N0}", total)
        Catch ex As Exception
            Logger.LogError("Error loading report", ex)
        End Try
    End Sub

    Private Function FetchReportData() As DataTable
        Dim sql As String = "SELECT o.OrderID AS order_id, r.Username AS u_name, r.Mobileno AS mobile, p.ProductName AS p_name, " & _
                        "od.Quantity AS qty, od.TotalPrice AS total_price, o.OrderDate AS order_date, o.Status AS status " & _
                        "FROM orders o INNER JOIN register r ON o.UserID = r.UserID INNER JOIN order_details od ON o.OrderID = od.OrderID " & _
                        "INNER JOIN addproduct1 p ON od.ProductID = p.ProductID WHERE 1=1 "
        Dim params As New List(Of SqlParameter)()

        If Not String.IsNullOrEmpty(txtStartDate.Text) Then
            sql &= " AND o.OrderDate >= @sDate "
            params.Add(New SqlParameter("@sDate", Convert.ToDateTime(txtStartDate.Text)))
        End If

        If Not String.IsNullOrEmpty(txtEndDate.Text) Then
            sql &= " AND o.OrderDate < @eDate "
            params.Add(New SqlParameter("@eDate", Convert.ToDateTime(txtEndDate.Text).AddDays(1)))
        End If

        If ddlStatusFilter.SelectedValue <> "ALL" Then
            sql &= " AND LOWER(ISNULL(o.Status,'')) = @st "
            params.Add(New SqlParameter("@st", ddlStatusFilter.SelectedValue.ToLower()))
        End If

        sql &= " ORDER BY o.OrderID DESC"

        Return Db.ExecuteQuery(sql, params.ToArray())
    End Function

    Protected Sub btnGenerateReport_Click(ByVal sender As Object, ByVal e As EventArgs)
        gvReport.PageIndex = 0
        LoadReport()
    End Sub

    Protected Sub btnExportCSV_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Dim dt As DataTable = FetchReportData()
            If dt.Rows.Count = 0 Then
                Toast.Show(Me, "No data available to export!", Toast.ToastType.Warning)
                Return
            End If

            Dim sb As New StringBuilder()
            ' CSV Headers
            sb.AppendLine("Order ID,Customer,Mobile,Product,Quantity,Total Price,Order Date,Status")

            For Each row As DataRow In dt.Rows
                Dim line As String = String.Format("{0},""{1}"",""{2}"",""{3}"",{4},{5},""{6:yyyy-MM-dd}"",""{7}""", _
                                           row("order_id"), _
                                           row("u_name").ToString().Replace("""", """"""), _
                                           row("mobile"), _
                                           row("p_name").ToString().Replace("""", """"""), _
                                           row("qty"), _
                                           row("total_price"), _
                                           row("order_date"), _
                                           row("status"))
                sb.AppendLine(line)
            Next

            Response.Clear()
            Response.Buffer = True
            Response.AddHeader("content-disposition", "attachment;filename=TrendyWear_Sales_Report_" & DateTime.Now.ToString("yyyyMMdd") & ".csv")
            Response.Charset = ""
            Response.ContentType = "text/csv"
            Response.Output.Write(sb.ToString())
            Response.Flush()
            Response.End()
        Catch ex As Exception
            Logger.LogError("Error exporting CSV", ex)
        End Try
    End Sub

    Protected Sub gvReport_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gvReport.PageIndex = e.NewPageIndex
        LoadReport()
    End Sub

    Public Function GetStatusBadgeClass(ByVal statusVal As Object) As String
        Dim st As String = Convert.ToString(statusVal).ToLower()
        If st = "pending" Then Return "badge badge-warning"
        If st = "confirmed" Then Return "badge badge-primary"
        If st = "shipped" Then Return "badge badge-info"
        If st = "delivered" Then Return "badge badge-success"
        If st = "cancelled" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function
End Class