Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class AdminDashboard
    Inherits System.Web.UI.Page

    Private totalStockCount As Integer = 0
    Private highCount As Integer = 0
    Private medCount As Integer = 0
    Private lowCount As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadDashboardData()
        End If
    End Sub

    Protected Sub ddlDateRange_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        LoadDashboardData()
    End Sub

    Private Sub LoadDashboardData()
        Dim daysFilter As String = ddlDateRange.SelectedValue
        Dim dateClause As String = ""

        If daysFilter = "7" Then
            dateClause = " AND o.OrderDate >= DATEADD(day, -7, GETDATE()) "
        ElseIf daysFilter = "30" Then
            dateClause = " AND o.OrderDate >= DATEADD(day, -30, GETDATE()) "
        ElseIf daysFilter = "month" Then
            dateClause = " AND MONTH(o.OrderDate) = MONTH(GETDATE()) AND YEAR(o.OrderDate) = YEAR(GETDATE()) "
        End If

        ' 1. KPIs
        Try
            Dim totalSalesObj As Object = Db.ExecuteScalar("SELECT ISNULL(SUM(o.TotalAmount), 0) FROM orders o WHERE LOWER(ISNULL(o.Status, '')) <> 'cancelled' " & dateClause)
            Dim totalSales As Decimal = Convert.ToDecimal(totalSalesObj)
            litTotalSales.Text = "Rs " & String.Format("{0:N0}", totalSales)

            Dim totalOrdersObj As Object = Db.ExecuteScalar("SELECT COUNT(*) FROM orders o WHERE 1=1 " & dateClause)
            litTotalOrders.Text = Convert.ToInt32(totalOrdersObj).ToString()

            Dim pendingOrdersObj As Object = Db.ExecuteScalar("SELECT COUNT(*) FROM orders o WHERE LOWER(ISNULL(o.Status, '')) = 'pending' " & dateClause)
            Dim pendingVal As Integer = Convert.ToInt32(pendingOrdersObj)
            litPendingOrders.Text = pendingVal.ToString()

            Dim totalCustObj As Object = Db.ExecuteScalar("SELECT COUNT(*) FROM register WHERE LOWER(ISNULL(Role, 'Customer')) = 'customer'")
            litTotalCustomers.Text = Convert.ToInt32(totalCustObj).ToString()

            Dim unitsStockObj As Object = Db.ExecuteScalar("SELECT ISNULL(SUM(Stock), 0) FROM addproduct1 WHERE IsActive = 1")
            litUnitsInStock.Text = Convert.ToInt32(unitsStockObj).ToString()

            Dim lowStockObj As Object = Db.ExecuteScalar("SELECT COUNT(*) FROM addproduct1 WHERE IsActive = 1 AND Stock <= 5")
            litLowStockCount.Text = Convert.ToInt32(lowStockObj).ToString()

            Dim reviewAverage As Object = Db.ExecuteScalar("SELECT ISNULL(AVG(CAST(Rating AS DECIMAL(10,2))), 0) FROM Reviews WHERE IsApproved = 1")
            litAverageReviewRating.Text = Convert.ToDecimal(reviewAverage).ToString("0.0")
            Dim pendingReviews As Object = Db.ExecuteScalar("SELECT COUNT(*) FROM Reviews WHERE IsApproved = 0")
            litPendingReviewCount.Text = Convert.ToInt32(pendingReviews).ToString()
        Catch ex As Exception
            Logger.LogError("Dashboard KPI error", ex)
        End Try

        ' 2. Stock Monitor Table (Sorted lowest stock first)
        Try
            Dim dtStock As DataTable = Db.ExecuteQuery("SELECT p.ProductID AS p_id, p.ProductName AS p_name, p.Category AS category_name, p.Price AS price, p.Stock, p.ProductImage AS Image FROM addproduct1 p WHERE p.IsActive = 1 ORDER BY p.Stock ASC")
            rptStockItems.DataSource = dtStock
            rptStockItems.DataBind()

            ' Count stock health tiers
            highCount = 0
            medCount = 0
            lowCount = 0
            totalStockCount = dtStock.Rows.Count

            For Each row As DataRow In dtStock.Rows
                Dim s As Integer = Convert.ToInt32(row("Stock"))
                If s >= 20 Then
                    highCount += 1
                ElseIf s >= 6 Then
                    medCount += 1
                Else
                    lowCount += 1
                End If
            Next

            litDonutTotal.Text = totalStockCount.ToString()
            litHighCount.Text = highCount.ToString()
            litMedCount.Text = medCount.ToString()
            litLowCount.Text = lowCount.ToString()
        Catch ex As Exception
            Logger.LogError("Dashboard Stock error", ex)
        End Try

        ' 3. Orders by Status
        Try
            Dim pendingCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = 'pending'"))
            Dim confirmedCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = 'confirmed'"))
            Dim shippedCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = 'shipped'"))
            Dim deliveredCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = 'delivered'"))
            Dim cancelledCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = 'cancelled'"))

            litPendingStat.Text = pendingCount.ToString()
            litConfirmedStat.Text = confirmedCount.ToString()
            litShippedStat.Text = shippedCount.ToString()
            litDeliveredStat.Text = deliveredCount.ToString()
            litCancelledStat.Text = cancelledCount.ToString()
        Catch ex As Exception
            Logger.LogError("Dashboard Status error", ex)
        End Try

        ' 4. Recent Orders
        Try
            Dim dtRecent As DataTable = Db.ExecuteQuery("SELECT TOP 5 o.OrderID AS order_id, r.Username AS u_name, o.TotalAmount AS total_price, o.Status AS status FROM orders o INNER JOIN register r ON o.UserID = r.UserID ORDER BY o.OrderID DESC")
            rptRecentOrders.DataSource = dtRecent
            rptRecentOrders.DataBind()
            phNoRecentOrders.Visible = (dtRecent.Rows.Count = 0)
        Catch ex As Exception
            phNoRecentOrders.Visible = True
        End Try

        ' 5. Best Sellers
        Try
            Dim dtBest As DataTable = Db.ExecuteQuery("SELECT TOP 5 p.ProductID AS p_id, p.ProductName AS p_name, p.Price AS price, p.Stock, p.ProductImage AS Image, SUM(od.Quantity) AS UnitsSold FROM order_details od INNER JOIN orders o ON o.OrderID = od.OrderID INNER JOIN addproduct1 p ON p.ProductID = od.ProductID WHERE p.IsActive = 1 AND LOWER(ISNULL(o.Status,'')) <> 'cancelled' GROUP BY p.ProductID, p.ProductName, p.Price, p.Stock, p.ProductImage ORDER BY SUM(od.Quantity) DESC, p.ProductName")
            rptBestSellers.DataSource = dtBest
            rptBestSellers.DataBind()
        Catch ex As Exception
            Logger.LogError("Dashboard top selling products error", ex)
        End Try

        Try
            rptDailySales.DataSource = Db.ExecuteQuery("SELECT CONVERT(VARCHAR(10), CAST(OrderDate AS DATE), 23) AS PeriodLabel, COUNT(*) AS OrderCount, ISNULL(SUM(TotalAmount), 0) AS Revenue FROM orders WHERE OrderDate >= DATEADD(day, -6, CAST(GETDATE() AS DATE)) AND LOWER(ISNULL(Status,'')) <> 'cancelled' GROUP BY CAST(OrderDate AS DATE) ORDER BY CAST(OrderDate AS DATE) DESC")
            rptDailySales.DataBind()
            rptMonthlySales.DataSource = Db.ExecuteQuery("SELECT LEFT(DATENAME(month, MonthStart), 3) + ' ' + CONVERT(VARCHAR(4), YEAR(MonthStart)) AS PeriodLabel, OrderCount, Revenue FROM (SELECT DATEADD(month, DATEDIFF(month, 0, OrderDate), 0) AS MonthStart, COUNT(*) AS OrderCount, ISNULL(SUM(TotalAmount), 0) AS Revenue FROM orders WHERE OrderDate >= DATEADD(month, -5, DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)) AND LOWER(ISNULL(Status,'')) <> 'cancelled' GROUP BY DATEADD(month, DATEDIFF(month, 0, OrderDate), 0)) SalesByMonth ORDER BY MonthStart DESC")
            rptMonthlySales.DataBind()
        Catch ex As Exception
            Logger.LogError("Dashboard sales trends error", ex)
        End Try

        ' 6. Newest Customers
        Try
            Dim dtCust As DataTable = Db.ExecuteQuery("SELECT TOP 5 Username AS u_name, Email AS email, Mobileno AS mobile, ISNULL(Role, 'Customer') AS Role FROM register ORDER BY UserID DESC")
            rptNewCustomers.DataSource = dtCust
            rptNewCustomers.DataBind()
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub rptStockItems_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If e.CommandName = "Restock" Then
            Dim productId As Integer = Convert.ToInt32(e.CommandArgument)
            Db.ExecuteNonQuery("UPDATE addproduct1 SET Stock = Stock + 10 WHERE ProductID = @id", New SqlParameter("@id", productId))
            StockNotificationService.NotifyIfBackInStock(productId, Me)
            Toast.Show(Me, "Stock increased by +10 units!", Toast.ToastType.Success)
            LoadDashboardData()
        End If
    End Sub

    Public Function GetStockBarClass(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        If s >= 20 Then Return "bar-fill bar-green"
        If s >= 6 Then Return "bar-fill bar-amber"
        If s >= 1 Then Return "bar-fill bar-red"
        Return "bar-fill bar-grey"
    End Function

    Public Function GetStockBadgeClass(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        If s >= 20 Then Return "badge badge-success"
        If s >= 6 Then Return "badge badge-warning"
        If s >= 1 Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function

    Public Function GetStockPercentage(ByVal stockVal As Object) As String
        Dim s As Integer = Convert.ToInt32(stockVal)
        Dim pct As Integer = CInt(Math.Min(100, (s / 50.0) * 100))
        Return pct.ToString()
    End Function

    Public Function GetDonutDashArray(ByVal tier As String) As String
        Dim total As Integer = Math.Max(1, totalStockCount)
        Dim val As Integer = 0
        If tier = "green" Then val = highCount
        If tier = "amber" Then val = medCount
        If tier = "red" Then val = lowCount

        Dim pct As Double = (val / CDbl(total)) * 100
        Return String.Format("{0:0.0} {1:0.0}", pct, 100 - pct)
    End Function

    Public Function GetDonutOffset(ByVal tier As String) As String
        Dim total As Integer = Math.Max(1, totalStockCount)
        If tier = "amber" Then
            Dim greenPct As Double = (highCount / CDbl(total)) * 100
            Return String.Format("{0:0.0}", 25 - greenPct)
        ElseIf tier = "red" Then
            Dim greenMedPct As Double = ((highCount + medCount) / CDbl(total)) * 100
            Return String.Format("{0:0.0}", 25 - greenMedPct)
        End If
        Return "25"
    End Function

    Public Function GetStatusPercent(ByVal statusName As String) As String
        Try
            Dim totalOrders As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders"))
            If totalOrders = 0 Then Return "0"
            Dim statusCount As Integer = Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM orders WHERE LOWER(ISNULL(Status,'')) = @st", New SqlParameter("@st", statusName.ToLower())))
            Dim pct As Integer = CInt((statusCount / CDbl(totalOrders)) * 100)
            Return pct.ToString()
        Catch
            Return "0"
        End Try
    End Function

    Public Function GetStatusBadgeClass(ByVal statusVal As Object) As String
        Dim st As String = Convert.ToString(statusVal).ToLower()
        If st = "pending" Then Return "badge badge-warning"
        If st = "confirmed" Then Return "badge badge-primary"
        If st = "shipped" Then Return "badge badge-info"
        If st = "delivered" Then Return "badge badge-success"
        If st = "cancelled" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function
End Class
