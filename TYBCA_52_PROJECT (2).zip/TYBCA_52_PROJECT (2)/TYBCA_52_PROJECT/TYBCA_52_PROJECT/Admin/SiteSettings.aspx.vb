Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers

Public Class AdminSiteSettings
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim role As String = TryCast(Session("role"), String)
        If role <> "Admin" Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadSettings()
        End If
    End Sub

    Private Sub LoadSettings()
        Try
            txtStoreName.Text = GetSettingValue("StoreName", "Trendy Wear")
            txtTagline.Text = GetSettingValue("Tagline", "Explore Plus - Flipkart/Amazon Redesign")
            txtAnnouncement.Text = GetSettingValue("AnnouncementBar", "🎉 Special Festivities Offer! Get Flat 15% OFF on Orders above Rs 1,999! Use Code: TRENDY15")
            ddlDefaultTheme.SelectedValue = GetSettingValue("DefaultTheme", "light")
            txtBrandColor.Text = GetSettingValue("BrandColor", "#2874f0")
            txtDeliveryCharges.Text = GetSettingValue("DeliveryCharge", "40")
            txtFreeShippingMin.Text = GetSettingValue("FreeShippingMin", "500")
        Catch ex As Exception
            Logger.LogError("Error loading site settings", ex)
        End Try
    End Sub

    Private Function GetSettingValue(ByVal key As String, ByVal defaultVal As String) As String
        Try
            Dim val As Object = Db.ExecuteScalar("SELECT SettingValue FROM SiteSettings WHERE SettingKey = @k", New SqlParameter("@k", key))
            If val IsNot Nothing AndAlso Not IsDBNull(val) Then
                Return val.ToString()
            End If
        Catch ex As Exception
        End Try
        Return defaultVal
    End Function

    Protected Sub btnSaveSettings_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            SaveSetting("StoreName", txtStoreName.Text.Trim())
            SaveSetting("Tagline", txtTagline.Text.Trim())
            SaveSetting("AnnouncementBar", txtAnnouncement.Text.Trim())
            SaveSetting("DefaultTheme", ddlDefaultTheme.SelectedValue)
            SaveSetting("BrandColor", txtBrandColor.Text.Trim())
            SaveSetting("DeliveryCharge", txtDeliveryCharges.Text.Trim())
            SaveSetting("FreeShippingMin", txtFreeShippingMin.Text.Trim())

            ' Also set theme cookie for current response
            Dim c As New HttpCookie("app_theme", ddlDefaultTheme.SelectedValue)
            c.Expires = DateTime.Now.AddYears(1)
            Response.Cookies.Add(c)

            Toast.Show(Me, "Site settings updated successfully!", Toast.ToastType.Success)
        Catch ex As Exception
            Logger.LogError("Error saving site settings", ex)
            Toast.Show(Me, "Failed to save settings: " & ex.Message, Toast.ToastType.Error)
        End Try
    End Sub

    Private Sub SaveSetting(ByVal key As String, ByVal val As String)
        Dim sql As String = "IF EXISTS (SELECT 1 FROM SiteSettings WHERE SettingKey = @k) " & _
                           "  UPDATE SiteSettings SET SettingValue = @v, UpdatedOn = GETDATE() WHERE SettingKey = @k " & _
                           "ELSE " & _
                           "  INSERT INTO SiteSettings (SettingKey, SettingValue, UpdatedOn) VALUES (@k, @v, GETDATE())"
        Db.ExecuteNonQuery(sql, New SqlParameter("@k", key), New SqlParameter("@v", val))
    End Sub
End Class
