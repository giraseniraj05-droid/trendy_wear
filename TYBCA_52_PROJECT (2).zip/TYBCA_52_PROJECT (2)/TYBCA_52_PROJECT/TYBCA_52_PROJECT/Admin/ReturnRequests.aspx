<%@ Page Title="Return Requests" Language="VB" MasterPageFile="~/Admin/Admin.Master" AutoEventWireup="false" CodeBehind="ReturnRequests.aspx.vb" Inherits="TYBCA_52_PROJECT.AdminReturnRequests" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header mb-4"><h1 class="dash-title">Return and refund requests</h1><p class="dash-subtitle">Review customer requests submitted within seven days of delivery.</p></div>
    <asp:Label ID="lblMessage" runat="server" CssClass="display-block mb-3"></asp:Label>
    <div class="fk-card admin-data-card">
        <div class="fk-card-body p-0">
            <div class="admin-table-scroll">
            <asp:GridView ID="gvRequests" runat="server" AutoGenerateColumns="False" CssClass="fk-table" DataKeyNames="ReturnRequestID" OnRowCommand="gvRequests_RowCommand">
                <Columns>
                    <asp:BoundField DataField="OrderID" HeaderText="Order" />
                    <asp:BoundField DataField="CustomerName" HeaderText="Customer" />
                    <asp:BoundField DataField="Email" HeaderText="Email" />
                    <asp:BoundField DataField="CreatedAt" HeaderText="Requested" DataFormatString="{0:dd MMM yyyy HH:mm}" />
                    <asp:BoundField DataField="Reason" HeaderText="Reason" />
                    <asp:BoundField DataField="RequestStatus" HeaderText="Status" />
                    <asp:TemplateField HeaderText="Decision">
                        <ItemTemplate>
                            <asp:LinkButton ID="btnApprove" runat="server" CommandName="ApproveRequest" CommandArgument='<%# Eval("ReturnRequestID") %>' CssClass="fk-btn-sm fk-btn-primary" Visible='<%# Convert.ToString(Eval("RequestStatus")) = "Pending" %>' OnClientClick="return confirm('Approve this request and mark the order refunded?');">Approve</asp:LinkButton>
                            <asp:LinkButton ID="btnReject" runat="server" CommandName="RejectRequest" CommandArgument='<%# Eval("ReturnRequestID") %>' CssClass="fk-btn-sm fk-btn-outline" Visible='<%# Convert.ToString(Eval("RequestStatus")) = "Pending" %>'>Reject</asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
            </div>
        </div>
    </div>
</asp:Content>
