Option Strict On
Option Explicit On

Partial Public Class AdminEmailLog
    Protected WithEvents btnSendTest As Global.System.Web.UI.WebControls.Button
    Protected WithEvents gvEmailLog As Global.System.Web.UI.WebControls.GridView
    Protected WithEvents phEmptyLog As Global.System.Web.UI.WebControls.PlaceHolder
End Class
