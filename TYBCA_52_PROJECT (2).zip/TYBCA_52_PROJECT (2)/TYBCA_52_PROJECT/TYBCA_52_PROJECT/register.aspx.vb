Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class WebForm11
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblMsg.Text = ""
        End If
    End Sub

    Protected Sub btnRegister_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRegister.Click
        If Not Page.IsValid Then Return

        Dim username As String = txtUsername.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim mobile As String = txtMobile.Text.Trim()
        Dim password As String = txtPassword.Text.Trim()

        lblMsg.Text = ""

        Try
            ' 1. Check duplicate username or email
            Dim dtCheck As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE Username = @u OR Email = @e", New SqlParameter("@u", username), New SqlParameter("@e", email))
            If dtCheck.Rows.Count > 0 Then
                Dim existingRow As DataRow = dtCheck.Rows(0)
                If existingRow("Username").ToString().Equals(username, StringComparison.OrdinalIgnoreCase) Then
                    lblMsg.Text = "Username '" & HttpUtility.HtmlEncode(username) & "' is already registered. Please choose another."
                Else
                    lblMsg.Text = "This email address is already associated with an account."
                End If
                NotifyExistingEmailAccount(dtCheck, email)
                Return
            End If

            ' 2. Generate PBKDF2 password hash & salt
            Dim salt As String = Security.GenerateSalt()
            Dim hash As String = Security.HashPassword(password, salt)

            ' 3. Insert into database
            Dim sqlInsert As String = "INSERT INTO register (Username, Password, Email, EmailVerified, Mobileno, FullName, Role, PasswordHash, Salt, IsActive, CreatedOn) " & _
                                      "VALUES (@u, '', @e, 0, @m, @u, 'Customer', @h, @s, 1, GETDATE()); SELECT CAST(SCOPE_IDENTITY() AS INT);"

            Dim pParams As SqlParameter() = New SqlParameter() {
                Db.CreateParam("@u", SqlDbType.NVarChar, username, 100),
                Db.CreateParam("@e", SqlDbType.NVarChar, email, 255),
                Db.CreateParam("@m", SqlDbType.NVarChar, mobile, 15),
                Db.CreateParam("@h", SqlDbType.NVarChar, hash, 255),
                Db.CreateParam("@s", SqlDbType.NVarChar, salt, 255)
            }

            Dim userId As Integer = Convert.ToInt32(Db.ExecuteScalar(sqlInsert, pParams))

            Dim registrationReturnUrl As String = Request.QueryString("ReturnUrl")
            Session("RegistrationReturnUrl") = If(Security.IsLocalReturnUrl(registrationReturnUrl), registrationReturnUrl, "")

            Session("EmailVerificationUserID") = userId
            Try
                EmailVerification.SendVerificationEmail(userId, username, email)
            Catch verificationEx As Exception
                Logger.LogError("Error preparing registration verification for UserID " & userId, verificationEx)
                Session("EmailVerificationSendFailed") = True
            End Try
            Response.Redirect("~/verify_email.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return

        Catch ex As Exception
            Logger.LogError("Registration error", ex)
            lblMsg.Text = "Unable to create your account. Please try again."
        End Try
    End Sub

    Private Sub NotifyExistingEmailAccount(ByVal matches As DataTable, ByVal submittedEmail As String)
        For Each account As DataRow In matches.Rows
            Dim existingEmail As String = Convert.ToString(account("Email"))
            If Not String.Equals(existingEmail, submittedEmail, StringComparison.OrdinalIgnoreCase) Then Continue For

            Try
                Dim recentNoticeCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                    "SELECT COUNT(*) FROM EmailLog WHERE ToEmail = @Email AND [Type] = @Type AND CreatedOn >= DATEADD(minute, -15, GETDATE())",
                    Db.CreateParam("@Email", SqlDbType.NVarChar, existingEmail, 255),
                    Db.CreateParam("@Type", SqlDbType.NVarChar, "RegistrationExisting", 100)))
                If recentNoticeCount = 0 Then
                    Dim safeUsername As String = HttpUtility.HtmlEncode(Convert.ToString(account("Username")))
                    Mailer.SendAsync(existingEmail, "An account already exists for this email",
                                     Mailer.Wrap("Account already exists",
                                                 "<p>Hello " & safeUsername & ", someone attempted to register using this email address. If that was you, sign in or reset your password. If it wasn't you, you can ignore this message.</p><p><a href='" & Request.Url.GetLeftPart(UriPartial.Authority) & ResolveUrl("~/login.aspx") & "'>Sign in</a> &nbsp; <a href='" & Request.Url.GetLeftPart(UriPartial.Authority) & ResolveUrl("~/forgot_password.aspx") & "'>Reset password</a></p>"),
                                     "RegistrationExisting")
                End If
            Catch ex As Exception
                Logger.LogError("Error preparing existing-account registration notification", ex)
            End Try
            Return
        Next
    End Sub
End Class
