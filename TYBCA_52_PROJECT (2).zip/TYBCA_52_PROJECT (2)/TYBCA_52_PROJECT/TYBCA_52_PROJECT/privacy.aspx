<%@ Page Title="Privacy Policy" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="privacy-container info-content-panel">
        <h2>Privacy Policy</h2>
        <p>At Trendy Wear, we respect your privacy and are committed to protecting your personal data.</p>
        <hr />
        <h4>1. Information We Collect</h4>
        <p>We collect information you provide directly to us when registering an account, placing an order, or contacting us, including your name, email address, phone number, and shipping address.</p>
        <h4>2. Data Protection & Security</h4>
        <p>Your password is securely encrypted using PBKDF2 hashing algorithms. We do not store plain-text passwords or share your contact details with third-party marketers.</p>
        <h4>3. Cookies</h4>
        <p>We use HTTP-only cookies solely for session management and site theme preferences.</p>
    </div>
</asp:Content>
