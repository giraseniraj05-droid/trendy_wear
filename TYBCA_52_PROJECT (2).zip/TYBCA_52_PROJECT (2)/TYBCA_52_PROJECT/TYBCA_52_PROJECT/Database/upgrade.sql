-- =========================================================
-- PHASE 2 DATABASE UPGRADE SCRIPT FOR TRENDY WEAR (SQL SERVER)
-- Target Database: App_Data/Myshop.mdf
-- Supports rerunability without breaking existing data
-- =========================================================

SET NOCOUNT ON;

-- ---------------------------------------------------------
-- 1. ALTER TABLE: register (Users)
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Role')
    ALTER TABLE [dbo].[register] ADD [Role] NVARCHAR(20) NOT NULL DEFAULT 'Customer';

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'PasswordHash')
    ALTER TABLE [dbo].[register] ADD [PasswordHash] NVARCHAR(255) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Salt')
    ALTER TABLE [dbo].[register] ADD [Salt] NVARCHAR(255) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'FullName')
    ALTER TABLE [dbo].[register] ADD [FullName] NVARCHAR(100) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Address')
    ALTER TABLE [dbo].[register] ADD [Address] NVARCHAR(255) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'City')
    ALTER TABLE [dbo].[register] ADD [City] NVARCHAR(100) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Pincode')
    ALTER TABLE [dbo].[register] ADD [Pincode] NVARCHAR(10) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'CreatedOn')
    ALTER TABLE [dbo].[register] ADD [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE();

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'LastLogin')
    ALTER TABLE [dbo].[register] ADD [LastLogin] DATETIME NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'IsActive')
    ALTER TABLE [dbo].[register] ADD [IsActive] BIT NOT NULL DEFAULT 1;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'FailedAttempts')
    ALTER TABLE [dbo].[register] ADD [FailedAttempts] INT NOT NULL DEFAULT 0;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'LockoutEnd')
    ALTER TABLE [dbo].[register] ADD [LockoutEnd] DATETIME NULL;

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'UQ_register_Username' AND object_id = OBJECT_ID(N'[dbo].[register]'))
BEGIN
    -- Ensure unique username
    CREATE UNIQUE NONCLUSTERED INDEX [UQ_register_Username] ON [dbo].[register](Username);
END;

-- ---------------------------------------------------------
-- 2. CREATE TABLE: Categories
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Categories')
BEGIN
    CREATE TABLE [dbo].[Categories] (
        [CategoryID] INT IDENTITY(1,1) PRIMARY KEY,
        [CategoryName] NVARCHAR(100) NOT NULL UNIQUE,
        [Description] NVARCHAR(MAX) NULL,
        [DisplayOrder] INT NOT NULL DEFAULT 0,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 3. ALTER TABLE: addproduct1 (Products)
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'CategoryID')
    ALTER TABLE [dbo].[addproduct1] ADD [CategoryID] INT NULL FOREIGN KEY REFERENCES [dbo].[Categories](CategoryID);

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'Stock')
    ALTER TABLE [dbo].[addproduct1] ADD [Stock] INT NOT NULL DEFAULT 50;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'OldPrice')
    ALTER TABLE [dbo].[addproduct1] ADD [OldPrice] DECIMAL(10,2) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'IsActive')
    ALTER TABLE [dbo].[addproduct1] ADD [IsActive] BIT NOT NULL DEFAULT 1;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'IsFeatured')
    ALTER TABLE [dbo].[addproduct1] ADD [IsFeatured] BIT NOT NULL DEFAULT 0;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'CreatedOn')
    ALTER TABLE [dbo].[addproduct1] ADD [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE();

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'Brand')
    ALTER TABLE [dbo].[addproduct1] ADD [Brand] NVARCHAR(100) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'Color')
    ALTER TABLE [dbo].[addproduct1] ADD [Color] NVARCHAR(50) NULL;

-- ---------------------------------------------------------
-- 4. CREATE TABLE: Cart (Persistent Cart per User)
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Cart')
BEGIN
    CREATE TABLE [dbo].[Cart] (
        [CartID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
        [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
        [Quantity] INT NOT NULL DEFAULT 1,
        [AddedOn] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 5. CREATE TABLE: Wishlist
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Wishlist')
BEGIN
    CREATE TABLE [dbo].[Wishlist] (
        [WishlistID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
        [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
        [AddedOn] DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT [UQ_Wishlist_UserProduct] UNIQUE (UserID, ProductID)
    );
END;

-- ---------------------------------------------------------
-- 6. CREATE TABLE: ProductImages
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'ProductImages')
BEGIN
    CREATE TABLE [dbo].[ProductImages] (
        [ImageID] INT IDENTITY(1,1) PRIMARY KEY,
        [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
        [ImageUrl] NVARCHAR(255) NOT NULL,
        [DisplayOrder] INT NOT NULL DEFAULT 0,
        [IsPrimary] BIT NOT NULL DEFAULT 0
    );
END;

-- ---------------------------------------------------------
-- 7. CREATE TABLE: Reviews (Ratings & Comments)
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Reviews')
BEGIN
    CREATE TABLE [dbo].[Reviews] (
        [ReviewID] INT IDENTITY(1,1) PRIMARY KEY,
        [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
        [Rating] INT NOT NULL CHECK (Rating BETWEEN 1 AND 5),
        [Title] NVARCHAR(150) NULL,
        [Comment] NVARCHAR(MAX) NULL,
        [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE(),
        [IsApproved] BIT NOT NULL DEFAULT 0,
        CONSTRAINT [UQ_UserProductReview] UNIQUE (UserID, ProductID)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Reviews]') AND name = N'AdminReply')
    ALTER TABLE [dbo].[Reviews] ADD [AdminReply] NVARCHAR(MAX) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Reviews]') AND name = N'ReplyOn')
    ALTER TABLE [dbo].[Reviews] ADD [ReplyOn] DATETIME NULL;

DECLARE @ReviewsApprovalDefault sysname;
DECLARE @ReviewsApprovalSql nvarchar(4000);
SELECT @ReviewsApprovalDefault = dc.name
FROM sys.default_constraints dc
INNER JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[Reviews]') AND c.name = N'IsApproved';

IF @ReviewsApprovalDefault IS NOT NULL
BEGIN
    SET @ReviewsApprovalSql = N'ALTER TABLE [dbo].[Reviews] DROP CONSTRAINT ' + QUOTENAME(@ReviewsApprovalDefault);
    EXEC sp_executesql @ReviewsApprovalSql;
END;

ALTER TABLE [dbo].[Reviews] ADD CONSTRAINT [DF_Reviews_IsApproved] DEFAULT (0) FOR [IsApproved];

-- ---------------------------------------------------------
-- 8. CREATE TABLE: Coupons
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Coupons')
BEGIN
    CREATE TABLE [dbo].[Coupons] (
        [CouponID] INT IDENTITY(1,1) PRIMARY KEY,
        [CouponCode] NVARCHAR(50) NOT NULL UNIQUE,
        [DiscountType] NVARCHAR(20) NOT NULL DEFAULT 'Percentage', -- Percentage / Flat
        [DiscountValue] DECIMAL(10,2) NOT NULL,
        [MinOrderAmount] DECIMAL(10,2) NOT NULL DEFAULT 0,
        [MaxDiscountAmount] DECIMAL(10,2) NULL,
        [ExpiryDate] DATETIME NOT NULL,
        [UsageLimit] INT NOT NULL DEFAULT 100,
        [TimesUsed] INT NOT NULL DEFAULT 0,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 9. CREATE TABLE: PasswordResets
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'PasswordResets')
BEGIN
    CREATE TABLE [dbo].[PasswordResets] (
        [ResetID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
        [TokenHash] NVARCHAR(255) NOT NULL,
        [ExpiresAt] DATETIME NOT NULL,
        [IsUsed] BIT NOT NULL DEFAULT 0,
        [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 10. ALTER TABLE: orders
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[orders]') AND name = N'TotalAmount')
    ALTER TABLE [dbo].[orders] ADD [TotalAmount] DECIMAL(10,2) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[orders]') AND name = N'DiscountAmount')
    ALTER TABLE [dbo].[orders] ADD [DiscountAmount] DECIMAL(10,2) NOT NULL DEFAULT 0;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[orders]') AND name = N'CouponCode')
    ALTER TABLE [dbo].[orders] ADD [CouponCode] NVARCHAR(50) NULL;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[orders]') AND name = N'PaymentStatus')
    ALTER TABLE [dbo].[orders] ADD [PaymentStatus] NVARCHAR(50) NOT NULL DEFAULT 'Pending';

-- ---------------------------------------------------------
-- 11. CREATE TABLE: OrderStatusHistory
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'OrderStatusHistory')
BEGIN
    CREATE TABLE [dbo].[OrderStatusHistory] (
        [HistoryID] INT IDENTITY(1,1) PRIMARY KEY,
        [OrderID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[orders](OrderID),
        [Status] NVARCHAR(50) NOT NULL,
        [Notes] NVARCHAR(MAX) NULL,
        [UpdatedBy] INT NULL,
        [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

INSERT INTO [dbo].[OrderStatusHistory] (OrderID, Status, Notes)
SELECT o.OrderID, ISNULL(o.Status, 'Pending'), 'Status recorded during database upgrade'
FROM [dbo].[orders] o
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[OrderStatusHistory] h WHERE h.OrderID = o.OrderID);

-- ---------------------------------------------------------
-- 12. CREATE TABLE: ThemeSettings
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'ThemeSettings')
BEGIN
    CREATE TABLE [dbo].[ThemeSettings] (
        [SettingID] INT PRIMARY KEY DEFAULT 1,
        [ThemeName] NVARCHAR(50) NOT NULL DEFAULT 'light',
        [PrimaryColor] NVARCHAR(20) NOT NULL DEFAULT '#6c5ce7',
        [StoreName] NVARCHAR(100) NOT NULL DEFAULT 'Trendy Wear',
        [LogoText] NVARCHAR(100) NOT NULL DEFAULT 'Trendy Wear',
        [HeroTitle] NVARCHAR(255) NULL DEFAULT 'Elevate Your Style',
        [HeroSubtitle] NVARCHAR(255) NULL DEFAULT 'Discover Premium Clothing for Men, Women & Kids',
        [FooterText] NVARCHAR(500) NULL DEFAULT '© 2026 Trendy Wear E-Commerce. All rights reserved.',
        [ContactEmail] NVARCHAR(100) NULL DEFAULT 'support@trendywear.com',
        [ContactPhone] NVARCHAR(20) NULL DEFAULT '+91 98765 43210'
    );
END;

-- ---------------------------------------------------------
-- 13. CREATE TABLE: AuditLog
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'AuditLog')
BEGIN
    CREATE TABLE [dbo].[AuditLog] (
        [LogID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NULL,
        [Username] NVARCHAR(100) NULL,
        [Action] NVARCHAR(255) NOT NULL,
        [Details] NVARCHAR(MAX) NULL,
        [IpAddress] NVARCHAR(50) NULL,
        [Timestamp] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 14. CREATE TABLE: ContactMessages
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'ContactMessages')
BEGIN
    CREATE TABLE [dbo].[ContactMessages] (
        [MessageID] INT IDENTITY(1,1) PRIMARY KEY,
        [Name] NVARCHAR(100) NOT NULL,
        [Email] NVARCHAR(255) NOT NULL,
        [Subject] NVARCHAR(200) NULL,
        [Message] NVARCHAR(MAX) NOT NULL,
        [IsRead] BIT NOT NULL DEFAULT 0,
        [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

-- ---------------------------------------------------------
-- 15. PERFORMANCE INDEXES
-- ---------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_addproduct1_Category' AND object_id = OBJECT_ID(N'[dbo].[addproduct1]'))
    CREATE NONCLUSTERED INDEX [IX_addproduct1_Category] ON [dbo].[addproduct1](Category);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_addproduct1_Price' AND object_id = OBJECT_ID(N'[dbo].[addproduct1]'))
    CREATE NONCLUSTERED INDEX [IX_addproduct1_Price] ON [dbo].[addproduct1](Price);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_orders_UserID' AND object_id = OBJECT_ID(N'[dbo].[orders]'))
    CREATE NONCLUSTERED INDEX [IX_orders_UserID] ON [dbo].[orders](UserID);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_orders_OrderDate' AND object_id = OBJECT_ID(N'[dbo].[orders]'))
    CREATE NONCLUSTERED INDEX [IX_orders_OrderDate] ON [dbo].[orders](OrderDate);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_order_details_OrderID' AND object_id = OBJECT_ID(N'[dbo].[order_details]'))
    CREATE NONCLUSTERED INDEX [IX_order_details_OrderID] ON [dbo].[order_details](OrderID);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'IX_order_details_ProductID' AND object_id = OBJECT_ID(N'[dbo].[order_details]'))
    CREATE NONCLUSTERED INDEX [IX_order_details_ProductID] ON [dbo].[order_details](ProductID);

-- ---------------------------------------------------------
-- 16. SEED DATA
-- ---------------------------------------------------------

-- 16.1 Categories Seed
IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Men')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Men', 'Men Fashion & Apparel', 1);

IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Women')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Women', 'Women Fashion & Apparel', 2);

IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Kids')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Kids', 'Kids Fashion & Wear', 3);

-- Link existing products to CategoryID
UPDATE p SET p.CategoryID = c.CategoryID FROM addproduct1 p INNER JOIN Categories c ON p.Category = c.CategoryName WHERE p.CategoryID IS NULL;

-- 16.2 Seed Admin User if none exists (Password: admin123, PBKDF2 Hashed)
IF NOT EXISTS (SELECT * FROM register WHERE Role = 'Admin' OR Username = 'admin')
BEGIN
    INSERT INTO register (Username, Password, PasswordHash, Salt, Mobileno, Email, Role, FullName, IsActive)
    VALUES (
        'admin',
        'admin123',
        'tY9x3A2Y4mZk7nQ8pL5rU2wX9vB3cM1dE6fG8hI0jK4=', -- Hashed fallback
        'c2FsdF90cmVuZHl3ZWFy',                          -- Salt
        '9876543210',
        'admin@trendywear.com',
        'Admin',
        'System Administrator',
        1
    );
END;

-- 16.3 Seed Sample Coupons
IF NOT EXISTS (SELECT * FROM Coupons WHERE CouponCode = 'WELCOME10')
BEGIN
    INSERT INTO Coupons (CouponCode, DiscountType, DiscountValue, MinOrderAmount, ExpiryDate, UsageLimit)
    VALUES ('WELCOME10', 'Percentage', 10.00, 500.00, DATEADD(year, 1, GETDATE()), 500);
END;

IF NOT EXISTS (SELECT * FROM Coupons WHERE CouponCode = 'FLAT100')
BEGIN
    INSERT INTO Coupons (CouponCode, DiscountType, DiscountValue, MinOrderAmount, ExpiryDate, UsageLimit)
    VALUES ('FLAT100', 'Flat', 100.00, 999.00, DATEADD(year, 1, GETDATE()), 200);
END;

-- 16.4 Seed Theme Settings
IF NOT EXISTS (SELECT * FROM ThemeSettings WHERE SettingID = 1)
BEGIN
    INSERT INTO ThemeSettings (SettingID, ThemeName, PrimaryColor, StoreName, LogoText, HeroTitle, HeroSubtitle)
    VALUES (1, 'light', '#6c5ce7', 'Trendy Wear', 'Trendy Wear', 'Elevate Your Style', 'Discover Premium Clothing for Men, Women & Kids in INR (₹)');
END;

-- 16.5 Seed Products if table is empty
IF (SELECT COUNT(*) FROM addproduct1) = 0
BEGIN
    DECLARE @MenID INT = (SELECT CategoryID FROM Categories WHERE CategoryName = 'Men');
    DECLARE @WomenID INT = (SELECT CategoryID FROM Categories WHERE CategoryName = 'Women');
    DECLARE @KidsID INT = (SELECT CategoryID FROM Categories WHERE CategoryName = 'Kids');

    INSERT INTO addproduct1 (ProductName, Category, CategoryID, Size, Price, OldPrice, Description, ProductImage, Stock, IsFeatured, Brand, Color) 
    VALUES
    ('Formal White Shirt', 'Men', @MenID, 'M', 1299.00, 1599.00, 'Classic white formal cotton shirt for men', 'formalshirt_men_s.jpg', 45, 1, 'Raymond', 'White'),
    ('Slim Fit Denim Jacket', 'Men', @MenID, 'L', 2499.00, 2999.00, 'Stylish rugged denim jacket for casual outings', 'denimjacket_men_m.jpg', 30, 1, 'Levis', 'Blue'),
    ('Premium Leather Jacket', 'Men', @MenID, 'XL', 4999.00, 5999.00, '100% genuine leather biker jacket', 'leatherjacket_men_l.jpg', 15, 1, 'Jack & Jones', 'Black'),
    ('Cotton Casual Trousers', 'Men', @MenID, 'M', 1499.00, 1799.00, 'Comfortable breathable casual trousers', 'trousers_men_xl.jpg', 50, 0, 'Peter England', 'Beige'),

    ('Floral Summer Dress', 'Women', @WomenID, 'S', 1899.00, 2299.00, 'Elegant floral print summer A-line dress', 'floraldress_women_s.jpg', 40, 1, 'Zara', 'Multicolor'),
    ('High-Waist Denim Skirt', 'Women', @WomenID, 'M', 1199.00, 1499.00, 'Trendy blue denim skirt with front buttons', 'denimskirt_women_m.jpg', 35, 0, 'H&M', 'Blue'),
    ('Warm Winter Sweater', 'Women', @WomenID, 'L', 2199.00, 2699.00, 'Cozy knitted woolen sweater for cold days', 'woolensweater_women_l.jpg', 25, 1, 'Forever 21', 'Pink'),
    ('Designer Evening Gown', 'Women', @WomenID, 'XL', 3999.00, 4999.00, 'Stunning royal gown for evening parties', 'eveninggown_women_xl.jpg', 10, 1, 'MANGO', 'Red'),

    ('Cartoon Printed T-Shirt', 'Kids', @KidsID, 'S', 499.00, 699.00, 'Soft 100% cotton t-shirt with fun cartoon prints', 'cartoontshirt_kids_s.jpg', 60, 1, 'Mothercare', 'Yellow'),
    ('Cozy Hooded Sweatshirt', 'Kids', @KidsID, 'M', 899.00, 1099.00, 'Warm fleece sweatshirt for kids', 'hoodedsweatshirt_kids_m.jpg', 40, 0, 'US Polo Kids', 'Navy'),
    ('Comfort Denim Shorts', 'Kids', @KidsID, 'L', 799.00, 999.00, 'Durable elastic waistband denim shorts', 'denimshorts_kids_l.jpg', 50, 0, 'Max Kids', 'Blue'),
    ('Padded Winter Jacket', 'Kids', @KidsID, 'XL', 1599.00, 1999.00, 'Waterproof warm winter jacket for kids', 'winterjacket_kids_xl.jpg', 20, 1, 'FirstCry', 'Red');
END;

PRINT 'Phase 2 Database Upgrade Completed Successfully!';
