-- =========================================================
-- SEED DATA SCRIPT FOR TRENDY WEAR (SQL SERVER)
-- Target Database: App_Data/Myshop.mdf
-- =========================================================

-- 1. Seed Categories
IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Men')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Men', 'Men Fashion & Apparel', 1);

IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Women')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Women', 'Women Fashion & Apparel', 2);

IF NOT EXISTS (SELECT * FROM Categories WHERE CategoryName = 'Kids')
    INSERT INTO Categories (CategoryName, Description, DisplayOrder) VALUES ('Kids', 'Kids Fashion & Wear', 3);

-- 2. Seed Admin Account (admin / admin123)
IF NOT EXISTS (SELECT * FROM register WHERE Username = 'admin')
BEGIN
    INSERT INTO register (Username, Password, PasswordHash, Salt, Mobileno, Email, Role, FullName, IsActive)
    VALUES (
        'admin',
        'admin123',
        'tY9x3A2Y4mZk7nQ8pL5rU2wX9vB3cM1dE6fG8hI0jK4=',
        'c2FsdF90cmVuZHl3ZWFy',
        '9876543210',
        'admin@trendywear.com',
        'Admin',
        'System Administrator',
        1
    );
END;

-- 3. Seed Promotional Coupons
IF NOT EXISTS (SELECT * FROM Coupons WHERE CouponCode = 'WELCOME10')
    INSERT INTO Coupons (CouponCode, DiscountType, DiscountValue, MinOrderAmount, ExpiryDate, UsageLimit)
    VALUES ('WELCOME10', 'Percentage', 10.00, 500.00, DATEADD(year, 1, GETDATE()), 500);

IF NOT EXISTS (SELECT * FROM Coupons WHERE CouponCode = 'FLAT100')
    INSERT INTO Coupons (CouponCode, DiscountType, DiscountValue, MinOrderAmount, ExpiryDate, UsageLimit)
    VALUES ('FLAT100', 'Flat', 100.00, 999.00, DATEADD(year, 1, GETDATE()), 200);

-- 4. Seed Theme Settings
IF NOT EXISTS (SELECT * FROM ThemeSettings WHERE SettingID = 1)
    INSERT INTO ThemeSettings (SettingID, ThemeName, PrimaryColor, StoreName, LogoText, HeroTitle, HeroSubtitle)
    VALUES (1, 'light', '#6c5ce7', 'Trendy Wear', 'Trendy Wear', 'Elevate Your Style', 'Discover Premium Clothing for Men, Women & Kids in INR (₹)');
