-- =========================================================
-- COMPLETE PRODUCTION DATABASE SCHEMA FOR TRENDY WEAR (SQL SERVER)
-- Target Database: App_Data/Myshop.mdf
-- =========================================================

CREATE TABLE [dbo].[register] (
    [UserID] INT IDENTITY(1,1) PRIMARY KEY,
    [Username] NVARCHAR(100) NOT NULL UNIQUE,
    [Password] NVARCHAR(255) NOT NULL,
    [PasswordHash] NVARCHAR(255) NULL,
    [Salt] NVARCHAR(255) NULL,
    [Mobileno] NVARCHAR(15) NULL,
    [Email] NVARCHAR(255) UNIQUE NOT NULL,
    [EmailVerified] BIT NOT NULL DEFAULT 1,
    [Role] NVARCHAR(20) NOT NULL DEFAULT 'Customer',
    [FullName] NVARCHAR(100) NULL,
    [Address] NVARCHAR(255) NULL,
    [City] NVARCHAR(100) NULL,
    [Pincode] NVARCHAR(10) NULL,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE(),
    [LastLogin] DATETIME NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [FailedAttempts] INT NOT NULL DEFAULT 0,
    [LockoutEnd] DATETIME NULL
);

CREATE TABLE [dbo].[Categories] (
    [CategoryID] INT IDENTITY(1,1) PRIMARY KEY,
    [CategoryName] NVARCHAR(100) NOT NULL UNIQUE,
    [Description] NVARCHAR(MAX) NULL,
    [DisplayOrder] INT NOT NULL DEFAULT 0,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[addproduct1] (
    [ProductID] INT IDENTITY(1,1) PRIMARY KEY,
    [ProductName] NVARCHAR(255) NOT NULL,
    [Category] NVARCHAR(50) NULL,
    [CategoryID] INT NULL FOREIGN KEY REFERENCES [dbo].[Categories](CategoryID),
    [Size] NVARCHAR(50) NOT NULL,
    [Price] DECIMAL(10,2) NOT NULL,
    [OldPrice] DECIMAL(10,2) NULL,
    [Description] NVARCHAR(MAX) NULL,
    [ProductImage] NVARCHAR(255) NULL,
    [Stock] INT NOT NULL DEFAULT 50,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [IsFeatured] BIT NOT NULL DEFAULT 0,
    [Brand] NVARCHAR(100) NULL,
    [Color] NVARCHAR(50) NULL,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[orders] (
    [OrderID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [OrderDate] DATETIME DEFAULT GETDATE(),
    [ShippingAddress] NVARCHAR(255) NULL,
    [City] NVARCHAR(100) NULL,
    [Pincode] NVARCHAR(10) NULL,
    [PaymentType] NVARCHAR(50) NULL,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    [TotalAmount] DECIMAL(10,2) NULL,
    [DiscountAmount] DECIMAL(10,2) NOT NULL DEFAULT 0,
    [CouponCode] NVARCHAR(50) NULL,
    [PaymentStatus] NVARCHAR(50) NOT NULL DEFAULT 'Pending'
);

CREATE TABLE [dbo].[order_details] (
    [OrderDetailID] INT IDENTITY(1,1) PRIMARY KEY,
    [OrderID] INT FOREIGN KEY REFERENCES [dbo].[orders](OrderID),
    [ProductID] INT FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
    [Quantity] INT NOT NULL,
    [Price] DECIMAL(10,2) NOT NULL,
    [TotalPrice] DECIMAL(10,2) NOT NULL
);

CREATE TABLE [dbo].[Feedback] (
    [FeedbackID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [Rating] INT CHECK ([Rating] BETWEEN 1 AND 5),
    [FeedbackType] NVARCHAR(50) NULL,
    [Comments] NVARCHAR(MAX) NULL,
    [Recommend] BIT DEFAULT 1,
    [DateSubmitted] DATETIME DEFAULT GETDATE()
);

CREATE TABLE [dbo].[Cart] (
    [CartID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
    [Quantity] INT NOT NULL DEFAULT 1,
    [AddedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[Wishlist] (
    [WishlistID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
    [AddedOn] DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [UQ_Wishlist_UserProduct] UNIQUE (UserID, ProductID)
);

CREATE TABLE [dbo].[ProductImages] (
    [ImageID] INT IDENTITY(1,1) PRIMARY KEY,
    [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
    [ImageUrl] NVARCHAR(255) NOT NULL,
    [DisplayOrder] INT NOT NULL DEFAULT 0,
    [IsPrimary] BIT NOT NULL DEFAULT 0
);

CREATE TABLE [dbo].[Reviews] (
    [ReviewID] INT IDENTITY(1,1) PRIMARY KEY,
    [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1](ProductID),
    [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [Rating] INT NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    [Title] NVARCHAR(150) NULL,
    [Comment] NVARCHAR(MAX) NULL,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE(),
    [IsApproved] BIT NOT NULL DEFAULT 1,
    CONSTRAINT [UQ_UserProductReview] UNIQUE (UserID, ProductID)
);

CREATE TABLE [dbo].[Coupons] (
    [CouponID] INT IDENTITY(1,1) PRIMARY KEY,
    [CouponCode] NVARCHAR(50) NOT NULL UNIQUE,
    [DiscountType] NVARCHAR(20) NOT NULL DEFAULT 'Percentage',
    [DiscountValue] DECIMAL(10,2) NOT NULL,
    [MinOrderAmount] DECIMAL(10,2) NOT NULL DEFAULT 0,
    [MaxDiscountAmount] DECIMAL(10,2) NULL,
    [ExpiryDate] DATETIME NOT NULL,
    [UsageLimit] INT NOT NULL DEFAULT 100,
    [TimesUsed] INT NOT NULL DEFAULT 0,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[PasswordResets] (
    [ResetID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
    [TokenHash] NVARCHAR(255) NOT NULL,
    [ExpiresAt] DATETIME NOT NULL,
    [IsUsed] BIT NOT NULL DEFAULT 0,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE(),
    [Attempts] INT NOT NULL DEFAULT 0
);

CREATE TABLE [dbo].[EmailVerificationTokens] (
    [VerificationID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register]([UserID]),
    [TokenHash] NVARCHAR(255) NOT NULL UNIQUE,
    [ExpiresAt] DATETIME NOT NULL,
    [IsUsed] BIT NOT NULL DEFAULT 0,
    [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE INDEX [IX_EmailVerificationTokens_UserCreated] ON [dbo].[EmailVerificationTokens] ([UserID], [IsUsed], [CreatedAt]);

CREATE TABLE [dbo].[OrderStatusHistory] (
    [HistoryID] INT IDENTITY(1,1) PRIMARY KEY,
    [OrderID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[orders](OrderID),
    [Status] NVARCHAR(50) NOT NULL,
    [Notes] NVARCHAR(MAX) NULL,
    [UpdatedBy] INT NULL,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[ThemeSettings] (
    [SettingID] INT PRIMARY KEY DEFAULT 1,
    [ThemeName] NVARCHAR(50) NOT NULL DEFAULT 'light',
    [PrimaryColor] NVARCHAR(20) NOT NULL DEFAULT '#6c5ce7',
    [StoreName] NVARCHAR(100) NOT NULL DEFAULT 'Trendy Wear',
    [LogoText] NVARCHAR(100) NOT NULL DEFAULT 'Trendy Wear',
    [HeroTitle] NVARCHAR(255) NULL DEFAULT 'Elevate Your Style',
    [HeroSubtitle] NVARCHAR(255) NULL DEFAULT 'Discover Premium Clothing for Men, Women & Kids',
    [FooterText] NVARCHAR(500) NULL DEFAULT '© 2026 Trendy Wear E-Commerce. All rights reserved.',
    [ContactEmail] NVARCHAR(100) NULL DEFAULT 'support@trendywear.com',
    [ContactPhone] NVARCHAR(20) NULL DEFAULT '+91 98765 43210'
);

CREATE TABLE [dbo].[AuditLog] (
    [LogID] INT IDENTITY(1,1) PRIMARY KEY,
    [UserID] INT NULL,
    [Username] NVARCHAR(100) NULL,
    [Action] NVARCHAR(255) NOT NULL,
    [Details] NVARCHAR(MAX) NULL,
    [IpAddress] NVARCHAR(50) NULL,
    [Timestamp] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[ContactMessages] (
    [MessageID] INT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(100) NOT NULL,
    [Email] NVARCHAR(255) NOT NULL,
    [Subject] NVARCHAR(200) NULL,
    [Message] NVARCHAR(MAX) NOT NULL,
    [IsRead] BIT NOT NULL DEFAULT 0,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE [dbo].[EmailLog] (
    [Id] INT IDENTITY(1,1) PRIMARY KEY,
    [ToEmail] NVARCHAR(255) NOT NULL,
    [Subject] NVARCHAR(255) NOT NULL,
    [Type] NVARCHAR(100) NOT NULL,
    [Success] BIT NOT NULL,
    [Error] NVARCHAR(MAX) NULL,
    [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE INDEX [IX_EmailLog_CreatedOn] ON [dbo].[EmailLog] ([CreatedOn] DESC);

-- Task 5: Reviews extra columns (added in upgrade_phase2.sql)
-- ALTER TABLE [dbo].[Reviews] ADD [ReviewImage] NVARCHAR(255) NULL;
-- ALTER TABLE [dbo].[Reviews] ADD [HelpfulCount] INT NOT NULL DEFAULT 0;
-- ALTER TABLE [dbo].[Reviews] ADD [AdminReply] NVARCHAR(MAX) NULL;
-- ALTER TABLE [dbo].[Reviews] ADD [ReplyOn] DATETIME NULL;

-- Task 5: ReviewHelpful table
CREATE TABLE [dbo].[ReviewHelpful] (
    [HelpfulID]  INT IDENTITY(1,1) PRIMARY KEY,
    [ReviewID]   INT NOT NULL REFERENCES [dbo].[Reviews](ReviewID) ON DELETE CASCADE,
    [UserID]     INT NOT NULL REFERENCES [dbo].[register](UserID),
    [CreatedOn]  DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [UQ_ReviewHelpful_UserReview] UNIQUE (ReviewID, UserID)
);
