-- Phase 1 SQL Schema Updates for Trendy Wear
-- Apply to App_Data/Myshop.mdf

-- 1. Add missing columns to register table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Role')
BEGIN
    ALTER TABLE [dbo].[register] ADD [Role] NVARCHAR(20) NOT NULL DEFAULT 'Customer';
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'PasswordHash')
BEGIN
    ALTER TABLE [dbo].[register] ADD [PasswordHash] NVARCHAR(255) NULL;
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Salt')
BEGIN
    ALTER TABLE [dbo].[register] ADD [Salt] NVARCHAR(255) NULL;
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'FailedAttempts')
BEGIN
    ALTER TABLE [dbo].[register] ADD [FailedAttempts] INT NOT NULL DEFAULT 0;
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'LockoutEnd')
BEGIN
    ALTER TABLE [dbo].[register] ADD [LockoutEnd] DATETIME NULL;
END;

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'IsActive')
BEGIN
    ALTER TABLE [dbo].[register] ADD [IsActive] BIT NOT NULL DEFAULT 1;
END;

-- 2. Add IsActive column to addproduct1 table for soft delete support
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[addproduct1]') AND name = N'IsActive')
BEGIN
    ALTER TABLE [dbo].[addproduct1] ADD [IsActive] BIT NOT NULL DEFAULT 1;
END;

-- 3. Add TotalAmount column to orders table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[orders]') AND name = N'TotalAmount')
BEGIN
    ALTER TABLE [dbo].[orders] ADD [TotalAmount] DECIMAL(10,2) NULL;
END;

-- 4. Create PasswordResets table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'PasswordResets')
BEGIN
    CREATE TABLE [dbo].[PasswordResets] (
        [ResetID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register](UserID),
        [TokenHash] NVARCHAR(255) NOT NULL,
        [ExpiresAt] DATETIME NOT NULL,
        [IsUsed] BIT NOT NULL DEFAULT 0,
        [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;
