/*
   Trendy Wear demo catalog reset and 20-product seed.
   Run against App_Data/Myshop.mdf. On the first run, rows that do not match the
   seed marker are treated as old demo/catalog rows. Order-referenced products
   are retained but disabled so order_details history remains valid. Later runs
   preserve non-seed products added by admins and only repair the seeded rows.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SeedBrand NVARCHAR(100) = N'Trendy Wear';
DECLARE @CategoryID INT;
DECLARE @CategoryName NVARCHAR(100);
DECLARE @Slug NVARCHAR(120);
DECLARE @BadChar INT;
DECLARE @IsFirstCatalogSeed BIT;

IF OBJECT_ID(N'dbo.Categories', N'U') IS NULL OR OBJECT_ID(N'dbo.addproduct1', N'U') IS NULL
BEGIN
    RAISERROR('Categories and addproduct1 tables are required before running this seed.', 16, 1);
    RETURN;
END;

IF COL_LENGTH(N'dbo.addproduct1', N'CategoryID') IS NULL
BEGIN
    RAISERROR('addproduct1.CategoryID is required. Apply the project database schema upgrade first.', 16, 1);
    RETURN;
END;

SELECT @IsFirstCatalogSeed = CASE WHEN EXISTS
    (SELECT 1 FROM dbo.addproduct1 WHERE ISNULL(Brand, N'') = N'Trendy Wear'
       AND ISNULL(ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg')
    THEN 0 ELSE 1 END;

CREATE TABLE #Styles
(
    SlotNo INT NOT NULL PRIMARY KEY,
    StyleName NVARCHAR(150) NOT NULL,
    ColorName NVARCHAR(50) NOT NULL,
    SizeAdults NVARCHAR(50) NOT NULL,
    SizeKids NVARCHAR(50) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    OldPrice DECIMAL(10,2) NOT NULL,
    Stock INT NOT NULL,
    IsFeatured BIT NOT NULL,
    ProductDescription NVARCHAR(500) NOT NULL
);

INSERT INTO #Styles (SlotNo, StyleName, ColorName, SizeAdults, SizeKids, Price, OldPrice, Stock, IsFeatured, ProductDescription)
VALUES
(1, N'Classic Cotton Crew Tee', N'Ivory', N'M', N'6Y', 499.00, 799.00, 32, 1, N'Soft breathable cotton jersey with a comfortable everyday fit.'),
(2, N'Textured Everyday Polo', N'Forest Green', N'L', N'8Y', 899.00, 1299.00, 18, 1, N'Textured knit polo with a neat collar and easy movement.'),
(3, N'Casual Oxford Shirt', N'Sky Blue', N'M', N'10Y', 1499.00, 2199.00, 14, 0, N'Lightweight woven shirt suited to workdays and weekends.'),
(4, N'Relaxed Linen Blend Shirt', N'Sand', N'L', N'12Y', 1699.00, 2499.00, 11, 1, N'Airy linen blend with a relaxed silhouette for warm days.'),
(5, N'Straight Fit Denim Jeans', N'Indigo', N'32', N'10Y', 1899.00, 2799.00, 16, 0, N'Durable denim with a classic straight leg and comfortable rise.'),
(6, N'Slim Chino Trousers', N'Olive', N'32', N'12Y', 1599.00, 2299.00, 13, 0, N'Soft stretch twill chinos with a clean tapered finish.'),
(7, N'Lightweight Zip Hoodie', N'Charcoal', N'L', N'8Y', 1799.00, 2599.00, 9, 0, N'Brushed cotton blend hoodie with a smooth zip front.'),
(8, N'Everyday Knit Sweater', N'Burgundy', N'M', N'10Y', 1999.00, 2999.00, 8, 1, N'Midweight knit layer with a soft hand feel and ribbed trim.'),
(9, N'Easy Jogger Pants', N'Black', N'L', N'8Y', 1099.00, 1599.00, 21, 0, N'Comfortable joggers with an elastic waist and practical pockets.'),
(10, N'Cotton Weekend Shorts', N'Camel', N'M', N'6Y', 799.00, 1199.00, 24, 0, N'Everyday cotton shorts with a flexible waistband.'),
(11, N'Printed Resort Shirt', N'Coral Print', N'L', N'10Y', 1299.00, 1899.00, 12, 0, N'Light resort shirt with a subtle all-over print.'),
(12, N'Long Sleeve Henley Tee', N'Rust', N'M', N'12Y', 999.00, 1499.00, 17, 0, N'Soft long sleeve jersey top with a simple button placket.'),
(13, N'Classic Denim Jacket', N'Mid Blue', N'L', N'12Y', 2499.00, 3599.00, 7, 0, N'Layer-friendly denim jacket with useful front pockets.'),
(14, N'Ribbed Lounge Set', N'Mauve', N'M', N'8Y', 1399.00, 1999.00, 10, 0, N'Coordinated ribbed top and bottom made for relaxed comfort.'),
(15, N'Active Track Jacket', N'Royal Blue', N'L', N'10Y', 1699.00, 2399.00, 15, 0, N'Lightweight zip layer with a smooth finish for active days.'),
(16, N'Tapered Everyday Pants', N'Graphite', N'32', N'12Y', 1499.00, 2199.00, 19, 0, N'Easy-care woven trousers with a neat tapered leg.'),
(17, N'Soft Fleece Sweatshirt', N'Cream', N'M', N'6Y', 1199.00, 1799.00, 22, 0, N'Cozy fleece-backed sweatshirt with a classic crew neckline.'),
(18, N'Pocket Graphic Tee', N'Mustard', N'L', N'8Y', 699.00, 999.00, 25, 0, N'Everyday cotton tee with a small chest graphic and pocket.'),
(19, N'Canvas Overshirt', N'Tan', N'L', N'10Y', 1799.00, 2699.00, 6, 0, N'Layering overshirt in sturdy cotton canvas with button cuffs.'),
(20, N'Everyday Cotton Leggings', N'Navy', N'M', N'12Y', 899.00, 1299.00, 20, 0, N'Soft stretch cotton leggings designed for comfortable movement.');

BEGIN TRY
    BEGIN TRANSACTION;

    IF @IsFirstCatalogSeed = 1
    BEGIN
    /* ProductImages are gallery children. Remove old demo galleries first. */
    DELETE pi
    FROM dbo.ProductImages AS pi
    INNER JOIN dbo.addproduct1 AS p ON p.ProductID = pi.ProductID
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg');

    /* Old demo items must no longer remain in carts or wishlists. */
    DELETE c
    FROM dbo.Cart AS c
    INNER JOIN dbo.addproduct1 AS p ON p.ProductID = c.ProductID
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg');

    DELETE w
    FROM dbo.Wishlist AS w
    INNER JOIN dbo.addproduct1 AS p ON p.ProductID = w.ProductID
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg');

    /* Keep products referenced by orders for history, and disable them. */
    UPDATE p SET IsActive = 0
    FROM dbo.addproduct1 AS p
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg')
      AND EXISTS (SELECT 1 FROM dbo.order_details AS od WHERE od.ProductID = p.ProductID);

    /* Remove review helper/alert rows before deleting reviews/products where present. */
    IF OBJECT_ID(N'dbo.ReviewHelpful', N'U') IS NOT NULL
        EXEC sys.sp_executesql N'DELETE rh FROM dbo.ReviewHelpful rh INNER JOIN dbo.Reviews r ON r.ReviewID=rh.ReviewID INNER JOIN dbo.addproduct1 p ON p.ProductID=r.ProductID WHERE NOT (ISNULL(p.Brand,N'''')=N''Trendy Wear'' AND ISNULL(p.ProductImage,N'''') LIKE N''Products/%/[0-9][0-9].jpg'') AND NOT EXISTS (SELECT 1 FROM dbo.order_details od WHERE od.ProductID=p.ProductID);';

    IF OBJECT_ID(N'dbo.StockAlerts', N'U') IS NOT NULL
        EXEC sys.sp_executesql N'DELETE sa FROM dbo.StockAlerts sa INNER JOIN dbo.addproduct1 p ON p.ProductID=sa.ProductID WHERE NOT (ISNULL(p.Brand,N'''')=N''Trendy Wear'' AND ISNULL(p.ProductImage,N'''') LIKE N''Products/%/[0-9][0-9].jpg'') AND NOT EXISTS (SELECT 1 FROM dbo.order_details od WHERE od.ProductID=p.ProductID);';

    DELETE r
    FROM dbo.Reviews AS r
    INNER JOIN dbo.addproduct1 AS p ON p.ProductID = r.ProductID
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg')
      AND NOT EXISTS (SELECT 1 FROM dbo.order_details AS od WHERE od.ProductID = p.ProductID);

    DELETE p
    FROM dbo.addproduct1 AS p
    WHERE NOT (ISNULL(p.Brand, N'') = @SeedBrand
               AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg')
      AND NOT EXISTS (SELECT 1 FROM dbo.order_details AS od WHERE od.ProductID = p.ProductID);
    END;

    DECLARE category_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT CategoryID, CategoryName FROM dbo.Categories WHERE IsActive = 1 ORDER BY DisplayOrder, CategoryName;
    OPEN category_cursor;
    FETCH NEXT FROM category_cursor INTO @CategoryID, @CategoryName;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Slug = LOWER(LTRIM(RTRIM(@CategoryName)));
        SET @Slug = REPLACE(@Slug, N'&', N'and');
        SET @Slug = REPLACE(@Slug, N' ', N'-');
        SET @Slug = REPLACE(@Slug, N'/', N'-');
        SET @Slug = REPLACE(@Slug, N'\', N'-');
        SET @Slug = REPLACE(@Slug, N'--', N'-');
        SET @BadChar = PATINDEX(N'%[^a-z0-9_-]%', @Slug COLLATE Latin1_General_BIN2);
        WHILE @BadChar > 0
        BEGIN
            SET @Slug = STUFF(@Slug, @BadChar, 1, N'');
            SET @BadChar = PATINDEX(N'%[^a-z0-9_-]%', @Slug COLLATE Latin1_General_BIN2);
        END;
        IF LEN(@Slug) = 0 SET @Slug = N'category-' + CONVERT(NVARCHAR(12), @CategoryID);

        /* Disable surplus seed rows; no product rows are deleted on reruns. */
        ;WITH SeedRows AS
        (
            SELECT ProductID, ROW_NUMBER() OVER (ORDER BY ProductID) AS rn
            FROM dbo.addproduct1
            WHERE CategoryID = @CategoryID AND Brand = @SeedBrand
              AND ProductImage LIKE N'Products/%/[0-9][0-9].jpg'
        )
        UPDATE p SET IsActive = CASE WHEN s.rn <= 20 THEN 1 ELSE 0 END,
                      Category = @CategoryName
        FROM dbo.addproduct1 AS p INNER JOIN SeedRows AS s ON s.ProductID = p.ProductID;

        /* Repair canonical image paths and enforce one primary image per seed product. */
        UPDATE p
           SET ProductImage = N'Products/' + @Slug + N'/' + RIGHT(p.ProductImage, 6)
        FROM dbo.addproduct1 AS p
        WHERE p.CategoryID = @CategoryID AND p.Brand = @SeedBrand
          AND p.ProductImage LIKE N'Products/%/[0-9][0-9].jpg';

        DELETE pi
        FROM dbo.ProductImages AS pi
        INNER JOIN dbo.addproduct1 AS p ON p.ProductID = pi.ProductID
        WHERE p.CategoryID = @CategoryID AND p.Brand = @SeedBrand
          AND p.ProductImage LIKE N'Products/%/[0-9][0-9].jpg';

        INSERT INTO dbo.addproduct1
            (ProductName, Category, CategoryID, Size, Price, OldPrice, Description, ProductImage,
             Stock, IsActive, IsFeatured, Brand, Color, CreatedOn)
        SELECT @CategoryName + N' ' + s.StyleName, @CategoryName, @CategoryID,
               CASE WHEN @CategoryName = N'Kids' THEN s.SizeKids ELSE s.SizeAdults END,
               s.Price, s.OldPrice, s.ProductDescription,
               N'Products/' + @Slug + N'/' + RIGHT(N'0' + CONVERT(NVARCHAR(2), s.SlotNo), 2) + N'.jpg',
               s.Stock, 1, s.IsFeatured, @SeedBrand, s.ColorName, GETDATE()
        FROM #Styles AS s
        WHERE NOT EXISTS
        (
            SELECT 1 FROM dbo.addproduct1 AS p
            WHERE p.CategoryID = @CategoryID AND p.Brand = @SeedBrand
              AND p.ProductImage = N'Products/' + @Slug + N'/' + RIGHT(N'0' + CONVERT(NVARCHAR(2), s.SlotNo), 2) + N'.jpg'
        );

        /* Seed products get exactly one primary ProductImages row. */
        INSERT INTO dbo.ProductImages (ProductID, ImageUrl, DisplayOrder, IsPrimary)
        SELECT p.ProductID, p.ProductImage,
               CONVERT(INT, SUBSTRING(p.ProductImage, LEN(p.ProductImage) - 5, 2)), 1
        FROM dbo.addproduct1 AS p
        WHERE p.CategoryID = @CategoryID AND p.Brand = @SeedBrand
          AND p.ProductImage LIKE N'Products/' + @Slug + N'/[0-9][0-9].jpg';

        FETCH NEXT FROM category_cursor INTO @CategoryID, @CategoryName;
    END;

    CLOSE category_cursor;
    DEALLOCATE category_cursor;

    /* Old categories that are now inactive must not have active seed products. */
    UPDATE p SET IsActive = 0
    FROM dbo.addproduct1 AS p
    WHERE p.Brand = @SeedBrand
      AND ISNULL(p.ProductImage, N'') LIKE N'Products/%/[0-9][0-9].jpg'
      AND NOT EXISTS (SELECT 1 FROM dbo.Categories c WHERE c.CategoryID = p.CategoryID AND c.IsActive = 1);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS('local', 'category_cursor') >= 0 CLOSE category_cursor;
    IF CURSOR_STATUS('local', 'category_cursor') > -3 DEALLOCATE category_cursor;
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT c.CategoryID, c.CategoryName, COUNT(p.ProductID) AS ActiveProductCount,
       CASE WHEN COUNT(p.ProductID) = 20 THEN N'OK' ELSE N'CHECK' END AS Verification
FROM dbo.Categories AS c
LEFT JOIN dbo.addproduct1 AS p ON p.CategoryID = c.CategoryID AND p.IsActive = 1
WHERE c.IsActive = 1
GROUP BY c.CategoryID, c.CategoryName, c.DisplayOrder
ORDER BY c.DisplayOrder, c.CategoryName;
