SET NOCOUNT ON;

IF OBJECT_ID(N'[dbo].[CustomerAddresses]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[CustomerAddresses] (
        [AddressID] INT IDENTITY(1,1) PRIMARY KEY,
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register]([UserID]) ON DELETE CASCADE,
        [FullName] NVARCHAR(100) NOT NULL,
        [Mobile] NVARCHAR(15) NOT NULL,
        [AddressLine] NVARCHAR(255) NOT NULL,
        [City] NVARCHAR(100) NOT NULL,
        [Pincode] NVARCHAR(10) NOT NULL,
        [IsDefault] BIT NOT NULL DEFAULT 0,
        [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

IF OBJECT_ID(N'[dbo].[OrderReturnRequests]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[OrderReturnRequests] (
        [ReturnRequestID] INT IDENTITY(1,1) PRIMARY KEY,
        [OrderID] INT NOT NULL UNIQUE FOREIGN KEY REFERENCES [dbo].[orders]([OrderID]),
        [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register]([UserID]),
        [Reason] NVARCHAR(1000) NOT NULL,
        [RequestStatus] NVARCHAR(20) NOT NULL DEFAULT 'Pending',
        [AdminNotes] NVARCHAR(1000) NULL,
        [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE(),
        [UpdatedAt] DATETIME NULL
    );
END;

IF OBJECT_ID(N'[dbo].[StockAlerts]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[StockAlerts] (
        [StockAlertID] INT IDENTITY(1,1) PRIMARY KEY,
        [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1]([ProductID]) ON DELETE CASCADE,
        [Email] NVARCHAR(255) NOT NULL,
        [IsNotified] BIT NOT NULL DEFAULT 0,
        [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT [UQ_StockAlerts_ProductEmail] UNIQUE ([ProductID], [Email])
    );
END;
