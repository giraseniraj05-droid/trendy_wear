/* Idempotent support objects for the Admin Accounts page. Run against the
   Trendy Wear database before using Admin Accounts. No account data is changed. */
IF OBJECT_ID(N'dbo.register', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.register', N'LastLogin') IS NULL
BEGIN
    ALTER TABLE dbo.register ADD LastLogin DATETIME NULL;
END;
GO

IF OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditLog
    (
        LogID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLog PRIMARY KEY,
        UserID INT NULL,
        Username NVARCHAR(100) NULL,
        Action NVARCHAR(255) NOT NULL,
        Details NVARCHAR(MAX) NULL,
        IpAddress NVARCHAR(50) NULL,
        [Timestamp] DATETIME NOT NULL CONSTRAINT DF_AuditLog_Timestamp DEFAULT GETDATE()
    );
END;
GO
