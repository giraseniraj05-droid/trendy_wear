-- Phase 2 email delivery logging
SET NOCOUNT ON;

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'EmailVerified')
    ALTER TABLE [dbo].[register] ADD [EmailVerified] BIT NOT NULL CONSTRAINT [DF_register_EmailVerified] DEFAULT 1;

IF OBJECT_ID(N'[dbo].[EmailLog]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EmailLog] (
        [Id] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_EmailLog] PRIMARY KEY,
        [ToEmail] NVARCHAR(255) NOT NULL,
        [Subject] NVARCHAR(255) NOT NULL,
        [Type] NVARCHAR(100) NOT NULL,
        [Success] BIT NOT NULL,
        [Error] NVARCHAR(MAX) NULL,
        [CreatedOn] DATETIME NOT NULL CONSTRAINT [DF_EmailLog_CreatedOn] DEFAULT GETDATE()
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EmailLog]') AND name = N'IX_EmailLog_CreatedOn')
    CREATE INDEX [IX_EmailLog_CreatedOn] ON [dbo].[EmailLog] ([CreatedOn] DESC);

IF OBJECT_ID(N'[dbo].[EmailVerificationTokens]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EmailVerificationTokens] (
        [VerificationID] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_EmailVerificationTokens] PRIMARY KEY,
        [UserID] INT NOT NULL CONSTRAINT [FK_EmailVerificationTokens_register] FOREIGN KEY REFERENCES [dbo].[register]([UserID]),
        [TokenHash] NVARCHAR(255) NOT NULL CONSTRAINT [UQ_EmailVerificationTokens_TokenHash] UNIQUE,
        [ExpiresAt] DATETIME NOT NULL,
        [IsUsed] BIT NOT NULL CONSTRAINT [DF_EmailVerificationTokens_IsUsed] DEFAULT 0,
        [CreatedAt] DATETIME NOT NULL CONSTRAINT [DF_EmailVerificationTokens_CreatedAt] DEFAULT GETDATE()
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EmailVerificationTokens]') AND name = N'IX_EmailVerificationTokens_UserCreated')
    CREATE INDEX [IX_EmailVerificationTokens_UserCreated] ON [dbo].[EmailVerificationTokens] ([UserID], [IsUsed], [CreatedAt]);


IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[PasswordResets]') AND name = N'Attempts')
    ALTER TABLE [dbo].[PasswordResets] ADD [Attempts] INT NOT NULL CONSTRAINT [DF_PasswordResets_Attempts] DEFAULT 0;

-- Task 5: Reviews enhancements
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'ReviewImage')
    ALTER TABLE [dbo].[Reviews] ADD [ReviewImage] NVARCHAR(255) NULL;
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'HelpfulCount')
    ALTER TABLE [dbo].[Reviews] ADD [HelpfulCount] INT NOT NULL CONSTRAINT [DF_Reviews_HelpfulCount] DEFAULT 0;
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'AdminReply')
    ALTER TABLE [dbo].[Reviews] ADD [AdminReply] NVARCHAR(MAX) NULL;
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'ReplyOn')
    ALTER TABLE [dbo].[Reviews] ADD [ReplyOn] DATETIME NULL;
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name=N'ReviewHelpful')
BEGIN
    CREATE TABLE [dbo].[ReviewHelpful] (
        [HelpfulID]  INT IDENTITY(1,1) PRIMARY KEY,
        [ReviewID]   INT NOT NULL REFERENCES [dbo].[Reviews](ReviewID) ON DELETE CASCADE,
        [UserID]     INT NOT NULL REFERENCES [dbo].[register](UserID),
        [CreatedOn]  DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT [UQ_ReviewHelpful_UserReview] UNIQUE (ReviewID, UserID)
    );
END;
