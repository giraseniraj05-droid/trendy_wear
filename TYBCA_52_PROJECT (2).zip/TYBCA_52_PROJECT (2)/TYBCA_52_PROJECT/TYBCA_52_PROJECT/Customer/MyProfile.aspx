<%@ Page Title="My Profile" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="MyProfile.aspx.vb" Inherits="TYBCA_52_PROJECT.MyProfile" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="dash-header mb-4"><h1 class="dash-title">My Profile</h1><p class="dash-subtitle">Update your account details, password, and saved delivery addresses.</p></div>
    <asp:Label ID="lblMessage" runat="server" CssClass="display-block mb-3"></asp:Label>
    <div class="fk-card mb-4 profile-form-card">
        <div class="fk-card-header"><h2 class="fk-card-title">Account details</h2></div>
        <div class="fk-card-body">
            <div class="grid-2-col mb-3">
                <div class="form-group"><label class="form-label">Name</label><asp:TextBox ID="txtName" runat="server" CssClass="fk-input" MaxLength="100"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Mobile</label><asp:TextBox ID="txtMobile" runat="server" CssClass="fk-input" MaxLength="10"></asp:TextBox></div>
            </div>
            <h3>Change password</h3>
            <div class="grid-3-col mb-3">
                <div class="form-group"><label class="form-label">Current password</label><asp:TextBox ID="txtCurrentPassword" runat="server" CssClass="fk-input" TextMode="Password"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">New password</label><asp:TextBox ID="txtNewPassword" runat="server" CssClass="fk-input" TextMode="Password"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Confirm new password</label><asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="fk-input" TextMode="Password"></asp:TextBox></div>
            </div>
            <asp:Button ID="btnSaveProfile" runat="server" Text="Save profile" CssClass="fk-btn fk-btn-primary" OnClick="btnSaveProfile_Click" />
        </div>
    </div>
     <div class="fk-card mb-4 profile-form-card profile-address-form">
        <div class="fk-card-header"><h2 class="fk-card-title">Add delivery address</h2></div>
        <div class="fk-card-body">
            <div class="grid-2-col mb-3">
                <div class="form-group"><label class="form-label">Recipient name</label><asp:TextBox ID="txtAddressName" runat="server" CssClass="fk-input" MaxLength="100"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Mobile</label><asp:TextBox ID="txtAddressMobile" runat="server" CssClass="fk-input" MaxLength="10"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Street address</label><asp:TextBox ID="txtAddressLine" runat="server" CssClass="fk-input" MaxLength="255"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">City</label><asp:TextBox ID="txtAddressCity" runat="server" CssClass="fk-input" MaxLength="100"></asp:TextBox></div>
                <div class="form-group"><label class="form-label">Pincode</label><asp:TextBox ID="txtAddressPincode" runat="server" CssClass="fk-input" MaxLength="6"></asp:TextBox></div>
            </div>
            <asp:CheckBox ID="chkDefaultAddress" runat="server" Text=" Make this my default address" CssClass="mb-3" /><br />
            <asp:Button ID="btnAddAddress" runat="server" Text="Save address" CssClass="fk-btn fk-btn-primary" OnClick="btnAddAddress_Click" />
        </div>
    </div>
    <div class="fk-card profile-address-list">
        <div class="fk-card-header"><h2 class="fk-card-title">Saved addresses</h2></div>
        <div class="fk-card-body p-0">
            <asp:GridView ID="gvAddresses" runat="server" AutoGenerateColumns="False" CssClass="fk-table" DataKeyNames="AddressID" OnRowCommand="gvAddresses_RowCommand">
                <Columns>
                    <asp:BoundField DataField="FullName" HeaderText="Recipient" />
                    <asp:BoundField DataField="Mobile" HeaderText="Mobile" />
                    <asp:BoundField DataField="AddressLine" HeaderText="Address" />
                    <asp:BoundField DataField="City" HeaderText="City" />
                    <asp:BoundField DataField="Pincode" HeaderText="Pincode" />
                    <asp:TemplateField HeaderText="Default"><ItemTemplate><%# If(Convert.ToBoolean(Eval("IsDefault")), "Yes", "") %></ItemTemplate></asp:TemplateField>
                    <asp:TemplateField><ItemTemplate><asp:LinkButton ID="btnDeleteAddress" runat="server" CommandName="DeleteAddress" CommandArgument='<%# Eval("AddressID") %>' CssClass="fk-btn-sm fk-btn-danger" OnClientClick="return confirm('Remove this saved address?');">Remove</asp:LinkButton></ItemTemplate></asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
