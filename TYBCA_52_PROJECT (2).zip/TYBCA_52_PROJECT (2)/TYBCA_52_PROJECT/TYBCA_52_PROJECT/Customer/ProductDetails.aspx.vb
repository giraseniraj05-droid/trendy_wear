Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Web
Imports System.Web.UI.WebControls
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class ProductDetails
    Inherits System.Web.UI.Page

    Private productId As Integer = 0
    Private Const PageSize As Integer = 5

    ' ─── Page_Load ───────────────────────────────────────────────────────────
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim idStr As String = Request.QueryString("id")
        If Not Integer.TryParse(idStr, productId) OrElse productId <= 0 Then
            Response.Redirect("~/Customer/search_product.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadProductDetails()
        End If
    End Sub

    ' ─── Product Detail ───────────────────────────────────────────────────────
    Private Sub LoadProductDetails()
        Try
            Dim dt As DataTable = Db.ExecuteQuery(
                "SELECT ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " &
                "ISNULL(OldPrice, Price * 1.3) AS OldPrice, Size, Stock, Description AS details, ProductImage AS Image " &
                "FROM addproduct1 WHERE ProductID = @id AND IsActive = 1", New SqlParameter("@id", productId))
            If dt.Rows.Count = 0 Then
                Response.Redirect("~/Customer/search_product.aspx")
                Return
            End If

            Dim row As DataRow = dt.Rows(0)
            RecordRecentlyViewed(productId)
            litProductName.Text = Server.HtmlEncode(row("p_name").ToString())
            litCategory.Text = Server.HtmlEncode(row("category_name").ToString())
            litSize.Text = Server.HtmlEncode(row("Size").ToString())

            Dim price As Decimal = Convert.ToDecimal(row("price"))
            Dim oldPrice As Decimal = Convert.ToDecimal(row("OldPrice"))
            litPrice.Text = String.Format("{0:N0}", price)
            litOldPrice.Text = String.Format("{0:N0}", oldPrice)

            If oldPrice > price Then
                Dim pct As Integer = CInt(((oldPrice - price) / oldPrice) * 100)
                litDiscountPct.Text = pct & "% OFF"
                lblDiscountBadge.Text = pct & "% OFF"
                lblDiscountBadge.Visible = True
            Else
                litDiscountPct.Text = "BEST PRICE"
                lblDiscountBadge.Visible = False
            End If

            Dim detailsStr As String = If(IsDBNull(row("details")), "", row("details").ToString())
            litDetails.Text = Server.HtmlEncode(If(String.IsNullOrEmpty(detailsStr), "High quality apparel crafted for comfort, style, and everyday elegance.", detailsStr))

            Dim imgName As String = If(IsDBNull(row("Image")) OrElse String.IsNullOrEmpty(row("Image").ToString()), "default.jpg", row("Image").ToString())
            imgMainProduct.Src = ResolveUrl(If(imgName = "default.jpg", "~/Images/default.jpg", "~/Uploads/" & imgName))

            Dim gallery As DataTable = Db.ExecuteQuery(
                "SELECT ImageUrl AS Image FROM ProductImages WHERE ProductID = @id " &
                "UNION SELECT ProductImage AS Image FROM addproduct1 WHERE ProductID = @id AND ISNULL(ProductImage, '') <> ''",
                New SqlParameter("@id", productId))
            rptProductImages.DataSource = gallery
            rptProductImages.DataBind()

            Dim stock As Integer = Convert.ToInt32(row("Stock"))
            If stock <= 0 Then
                lblStockStatus.Text = "Out of Stock"
                lblStockStatus.CssClass = "badge badge-secondary"
                pnlStockAlert.Visible = True
                btnAddToCart.Enabled = False
                btnBuyNow.Enabled = False
            ElseIf stock <= 5 Then
                pnlStockAlert.Visible = False
                lblStockStatus.Text = "Hurry, Only " & stock & " left in stock!"
                lblStockStatus.CssClass = "badge badge-warning"
            Else
                pnlStockAlert.Visible = False
                lblStockStatus.Text = "In Stock (Available)"
                lblStockStatus.CssClass = "badge badge-success"
            End If

            Dim dtRelated As DataTable = Db.ExecuteQuery(
                "SELECT TOP 4 ProductID AS p_id, ProductName AS p_name, Price AS price, ProductImage AS Image " &
                "FROM addproduct1 WHERE Category = @cat AND ProductID <> @id AND IsActive = 1",
                New SqlParameter("@cat", row("category_name").ToString()), New SqlParameter("@id", productId))
            rptRelated.DataSource = dtRelated
            rptRelated.DataBind()
            BindRecentlyViewed(productId)

            ' Current page from ViewState (default 1 on fresh load)
            If ViewState("ReviewPage") Is Nothing Then ViewState("ReviewPage") = 1
            LoadReviewsSection()

        Catch ex As Exception
            Logger.LogError("Error loading product details", ex)
        End Try
    End Sub

    Protected Sub btnStockAlert_Click(ByVal sender As Object, ByVal e As EventArgs)
        If StockNotificationService.Subscribe(productId, txtStockAlertEmail.Text) Then
            lblStockAlertMessage.Text = "We'll email you when this product is available."
            txtStockAlertEmail.Text = ""
        Else
            lblStockAlertMessage.Text = "This product is no longer out of stock, or enter a valid email address."
        End If
    End Sub

    Private Sub RecordRecentlyViewed(ByVal viewedProductId As Integer)
        Dim recent As List(Of Integer) = TryCast(Session("RecentlyViewedProducts"), List(Of Integer))
        If recent Is Nothing Then recent = New List(Of Integer)()
        recent.Remove(viewedProductId)
        recent.Insert(0, viewedProductId)
        If recent.Count > 10 Then recent.RemoveAt(recent.Count - 1)
        Session("RecentlyViewedProducts") = recent
    End Sub

    Private Sub BindRecentlyViewed(ByVal currentProductId As Integer)
        Dim recent As List(Of Integer) = TryCast(Session("RecentlyViewedProducts"), List(Of Integer))
        If recent Is Nothing Then Return
        Dim ids As List(Of Integer) = recent.Where(Function(id) id <> currentProductId).Take(6).ToList()
        If ids.Count = 0 Then
            phRecentlyViewed.Visible = False
            Return
        End If
        Dim names As New List(Of String)()
        Dim parameters As New List(Of SqlParameter)()
        For i As Integer = 0 To ids.Count - 1
            Dim parameterName As String = "@recent" & i.ToString()
            names.Add(parameterName)
            parameters.Add(New SqlParameter(parameterName, ids(i)))
        Next
        Dim query As String = "SELECT ProductID AS p_id, ProductName AS p_name, Price AS price, ProductImage AS Image FROM addproduct1 WHERE IsActive = 1 AND ProductID IN (" & String.Join(",", names.ToArray()) & ") ORDER BY CASE ProductID " & String.Join(" ", names.Select(Function(name, index) "WHEN " & name & " THEN " & index.ToString()).ToArray()) & " END"
        rptRecentlyViewed.DataSource = Db.ExecuteQuery(query, parameters.ToArray())
        rptRecentlyViewed.DataBind()
        phRecentlyViewed.Visible = (rptRecentlyViewed.Items.Count > 0)
    End Sub

    ' ─── Reviews: Load ───────────────────────────────────────────────────────
    Private Sub LoadReviewsSection()
        ' Stats
        Dim stats As DataTable = Db.ExecuteQuery(
            "SELECT COUNT(*) AS ReviewCount, ISNULL(AVG(CAST(Rating AS DECIMAL(10,2))), 0) AS AverageRating FROM Reviews WHERE ProductID = @ProductID AND IsApproved = 1",
            New SqlParameter("@ProductID", productId))
        Dim total As Integer = Convert.ToInt32(stats.Rows(0)("ReviewCount"))
        litReviewCount.Text = total.ToString()
        litAvgRating.Text = Convert.ToDecimal(stats.Rows(0)("AverageRating")).ToString("0.0")

        ' Breakdown bars
        Dim breakdown As DataTable = Db.ExecuteQuery(
            "SELECT Rating, COUNT(*) AS RatingCount FROM Reviews WHERE ProductID = @ProductID AND IsApproved = 1 GROUP BY Rating",
            New SqlParameter("@ProductID", productId))
        Dim counts(5) As Integer
        For Each ratingRow As DataRow In breakdown.Rows
            counts(Convert.ToInt32(ratingRow("Rating"))) = Convert.ToInt32(ratingRow("RatingCount"))
        Next
        Dim html As New StringBuilder()
        For rating As Integer = 5 To 1 Step -1
            Dim pct As Integer = If(total = 0, 0, CInt(Math.Round(counts(rating) * 100.0R / total)))
            html.Append("<div class='rating-bar-row'><span>" & rating & " &#9733;</span>")
            html.Append("<div class='rating-bar-bg'><div class='rating-bar-fill' style='width:" & pct & "%'></div></div>")
            html.Append("<span>" & counts(rating) & "</span></div>")
        Next
        litRatingBreakdown.Text = html.ToString()

        ' Sort order
        Dim sortOrder As String = "newest"
        If ddlReviewSort IsNot Nothing AndAlso ddlReviewSort.SelectedValue <> "" Then
            sortOrder = ddlReviewSort.SelectedValue
        End If
        Dim orderBy As String
        Select Case sortOrder
            Case "highest" : orderBy = "r.Rating DESC, r.CreatedOn DESC"
            Case "lowest"  : orderBy = "r.Rating ASC, r.CreatedOn DESC"
            Case Else      : orderBy = "r.CreatedOn DESC"
        End Select

        ' Paging
        Dim currentPage As Integer = Convert.ToInt32(If(ViewState("ReviewPage"), 1))
        Dim totalPages As Integer = If(total = 0, 1, CInt(Math.Ceiling(total / PageSize)))
        If currentPage > totalPages Then currentPage = totalPages
        If currentPage < 1 Then currentPage = 1
        ViewState("ReviewPage") = currentPage

        Dim offset As Integer = (currentPage - 1) * PageSize
        litPageInfo.Text = "Page " & currentPage & " of " & totalPages
        lbPrev.Enabled = (currentPage > 1)
        lbNext.Enabled = (currentPage < totalPages)

        ' Determine current user
        Dim userId As Integer = 0
        Integer.TryParse(Convert.ToString(Session("UserID")), userId)

        ' Reviews query – include IsVerified flag for current user
        Dim reviewSql As String =
            "SELECT r.ReviewID, r.Rating, r.Title, r.Comment, r.CreatedOn, r.AdminReply, r.ReplyOn, r.HelpfulCount, " &
            "ISNULL(r.ReviewImage, '') AS ReviewImage, u.Username, " &
            "CASE WHEN EXISTS (SELECT 1 FROM orders o INNER JOIN order_details od ON od.OrderID = o.OrderID " &
            "                  WHERE o.UserID = r.UserID AND od.ProductID = r.ProductID AND LOWER(ISNULL(o.Status,'')) = 'delivered') THEN 1 ELSE 0 END AS IsVerified " &
            "FROM Reviews r INNER JOIN register u ON u.UserID = r.UserID " &
            "WHERE r.ProductID = @ProductID AND r.IsApproved = 1 " &
            "ORDER BY " & orderBy & " " &
            "OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY"

        Dim reviews As DataTable = Db.ExecuteQuery(reviewSql,
            New SqlParameter("@ProductID", productId),
            New SqlParameter("@Offset", offset),
            New SqlParameter("@PageSize", PageSize))
        rptReviews.DataSource = reviews
        rptReviews.DataBind()
        phNoReviews.Visible = (reviews.Rows.Count = 0)

        ' Write-a-review section
        If userId <= 0 Then
            ' Not logged in
            phLoginPrompt.Visible = True
            phNotEligible.Visible = False
            pnlReviewForm.Visible = False
        Else
            ' Check verified purchaser
            Dim purchasedCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM orders o INNER JOIN order_details od ON od.OrderID = o.OrderID " &
                "WHERE o.UserID = @UID AND od.ProductID = @PID AND LOWER(ISNULL(o.Status,'')) = 'delivered'",
                New SqlParameter("@UID", userId),
                New SqlParameter("@PID", productId)))

            If purchasedCount = 0 Then
                phLoginPrompt.Visible = False
                phNotEligible.Visible = True
                pnlReviewForm.Visible = False
            Else
                phLoginPrompt.Visible = False
                phNotEligible.Visible = False
                pnlReviewForm.Visible = True

                ' Pre-fill existing review
                Dim existing As DataTable = Db.ExecuteQuery(
                    "SELECT Rating, Title, Comment FROM Reviews WHERE UserID = @UID AND ProductID = @PID",
                    New SqlParameter("@UID", userId),
                    New SqlParameter("@PID", productId))
                If existing.Rows.Count > 0 Then
                    Dim er As DataRow = existing.Rows(0)
                    lblReviewMsg.Text = "You have already reviewed this product. Editing it will send it back for approval."
                    txtReviewTitle.Text = If(IsDBNull(er("Title")), "", er("Title").ToString())
                    txtReviewComment.Text = If(IsDBNull(er("Comment")), "", er("Comment").ToString())
                    Dim existingRating As Integer = Convert.ToInt32(er("Rating"))
                    hfRating.Value = existingRating.ToString()
                    SetStarRadio(existingRating)
                    btnSubmitReview.Text = "Update Review"
                Else
                    lblReviewMsg.Text = ""
                    btnSubmitReview.Text = "Submit Review"
                End If
            End If
        End If
    End Sub

    Private Sub SetStarRadio(ByVal rating As Integer)
        rb1.Checked = (rating = 1)
        rb2.Checked = (rating = 2)
        rb3.Checked = (rating = 3)
        rb4.Checked = (rating = 4)
        rb5.Checked = (rating = 5)
    End Sub

    ' ─── Paging & Sorting ────────────────────────────────────────────────────
    Protected Sub lbPrev_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim page As Integer = Convert.ToInt32(If(ViewState("ReviewPage"), 1))
        If page > 1 Then ViewState("ReviewPage") = page - 1
        LoadReviewsSection()
    End Sub

    Protected Sub lbNext_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim page As Integer = Convert.ToInt32(If(ViewState("ReviewPage"), 1))
        ViewState("ReviewPage") = page + 1
        LoadReviewsSection()
    End Sub

    Protected Sub ddlReviewSort_Changed(ByVal sender As Object, ByVal e As EventArgs)
        ViewState("ReviewPage") = 1
        LoadReviewsSection()
    End Sub

    ' ─── Submit Review ────────────────────────────────────────────────────────
    Protected Sub btnSubmitReview_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If

        ' Verify eligibility
        Dim purchased As Integer = Convert.ToInt32(Db.ExecuteScalar(
            "SELECT COUNT(*) FROM orders o INNER JOIN order_details od ON od.OrderID = o.OrderID " &
            "WHERE o.UserID = @UID AND od.ProductID = @PID AND LOWER(ISNULL(o.Status,'')) = 'delivered'",
            New SqlParameter("@UID", userId),
            New SqlParameter("@PID", productId)))
        If purchased = 0 Then
            Toast.ShowMessage(Me, "Only verified purchasers can submit a review.", ToastType.Error)
            LoadReviewsSection()
            Return
        End If

        ' Read rating from hidden field (JS writes it) or from radio buttons
        Dim rating As Integer = 0
        If Not Integer.TryParse(hfRating.Value, rating) OrElse rating < 1 OrElse rating > 5 Then
            ' Fallback: check radio buttons
            If rb5.Checked Then rating = 5
            If rb4.Checked Then rating = 4
            If rb3.Checked Then rating = 3
            If rb2.Checked Then rating = 2
            If rb1.Checked Then rating = 1
        End If
        If rating < 1 OrElse rating > 5 Then
            Toast.ShowMessage(Me, "Please select a rating from 1 to 5 stars.", ToastType.Warning)
            LoadReviewsSection()
            Return
        End If

        Dim title As String = txtReviewTitle.Text.Trim()
        Dim comment As String = txtReviewComment.Text.Trim()
        If String.IsNullOrEmpty(comment) Then
            Toast.ShowMessage(Me, "Please write your review comment.", ToastType.Warning)
            LoadReviewsSection()
            Return
        End If

        ' Photo upload (optional)
        Dim reviewImageName As String = Nothing
        If fuReviewPhoto.HasFile Then
            Dim ext As String = Path.GetExtension(fuReviewPhoto.FileName).ToLowerInvariant()
            If ext <> ".jpg" AndAlso ext <> ".jpeg" AndAlso ext <> ".png" Then
                Toast.ShowMessage(Me, "Only JPG and PNG images are allowed.", ToastType.Warning)
                LoadReviewsSection()
                Return
            End If
            If fuReviewPhoto.PostedFile.ContentLength > 2 * 1024 * 1024 Then
                Toast.ShowMessage(Me, "Photo must be 2 MB or smaller.", ToastType.Warning)
                LoadReviewsSection()
                Return
            End If
            reviewImageName = Guid.NewGuid().ToString("N") & ext
            Dim savePath As String = Server.MapPath("~/Reviews/" & reviewImageName)
            fuReviewPhoto.SaveAs(savePath)
        End If

        Try
            ' Keep existing image if no new upload
            Dim commentParam As New SqlParameter("@Comment", SqlDbType.NVarChar, -1)
            commentParam.Value = comment

            If reviewImageName IsNot Nothing Then
                Dim imgParam As New SqlParameter("@ReviewImage", SqlDbType.NVarChar, 255)
                imgParam.Value = reviewImageName
                Db.ExecuteNonQuery(
                    "IF EXISTS (SELECT 1 FROM Reviews WHERE UserID = @UID AND ProductID = @PID) " &
                    "  UPDATE Reviews SET Rating=@Rating, Title=@Title, Comment=@Comment, ReviewImage=@ReviewImage, CreatedOn=GETDATE(), IsApproved=0, AdminReply=NULL, ReplyOn=NULL " &
                    "  WHERE UserID=@UID AND ProductID=@PID " &
                    "ELSE INSERT INTO Reviews (ProductID,UserID,Rating,Title,Comment,ReviewImage,CreatedOn,IsApproved,HelpfulCount) " &
                    "  VALUES (@PID,@UID,@Rating,@Title,@Comment,@ReviewImage,GETDATE(),0,0)",
                    New SqlParameter("@UID", userId),
                    New SqlParameter("@PID", productId),
                    New SqlParameter("@Rating", rating),
                    Db.CreateParam("@Title", SqlDbType.NVarChar, title, 150),
                    commentParam,
                    imgParam)
            Else
                Db.ExecuteNonQuery(
                    "IF EXISTS (SELECT 1 FROM Reviews WHERE UserID = @UID AND ProductID = @PID) " &
                    "  UPDATE Reviews SET Rating=@Rating, Title=@Title, Comment=@Comment, CreatedOn=GETDATE(), IsApproved=0, AdminReply=NULL, ReplyOn=NULL " &
                    "  WHERE UserID=@UID AND ProductID=@PID " &
                    "ELSE INSERT INTO Reviews (ProductID,UserID,Rating,Title,Comment,CreatedOn,IsApproved,HelpfulCount) " &
                    "  VALUES (@PID,@UID,@Rating,@Title,@Comment,GETDATE(),0,0)",
                    New SqlParameter("@UID", userId),
                    New SqlParameter("@PID", productId),
                    New SqlParameter("@Rating", rating),
                    Db.CreateParam("@Title", SqlDbType.NVarChar, title, 150),
                    commentParam)
            End If

            ' Send emails
            Try
                Dim user As DataTable = Db.ExecuteQuery(
                    "SELECT Username, Email FROM register WHERE UserID = @UID",
                    New SqlParameter("@UID", userId))
                Dim pName As String = HttpUtility.HtmlEncode(
                    Convert.ToString(Db.ExecuteScalar("SELECT ProductName FROM addproduct1 WHERE ProductID = @PID", New SqlParameter("@PID", productId))))
                If user.Rows.Count > 0 Then
                    Dim uName As String = HttpUtility.HtmlEncode(Convert.ToString(user.Rows(0)("Username")))
                    Mailer.SendAsync(Convert.ToString(user.Rows(0)("Email")), "Thanks for your review",
                        Mailer.Wrap("Thanks for your review",
                            "<p>Hello " & uName & ", thank you for reviewing <strong>" & pName & "</strong>. It will appear once approved.</p>"),
                        "ReviewReceived")
                End If
                Mailer.SendAsync(System.Configuration.ConfigurationManager.AppSettings("AdminEmail"),
                    "Review pending approval",
                    Mailer.Wrap("New review pending approval",
                        "<p>Product: " & pName & "</p><p>Rating: " & rating & "/5</p>"),
                    "ReviewPending")
            Catch ex As Exception
                Logger.LogError("Error sending review emails for UserID " & userId, ex)
            End Try

            Toast.ShowMessage(Me, "Review submitted and is awaiting approval. Thank you!", ToastType.Success)
            ViewState("ReviewPage") = 1
            LoadReviewsSection()
        Catch ex As Exception
            Logger.LogError("Error submitting review for UserID " & userId & " ProductID " & productId, ex)
            Toast.ShowMessage(Me, "Could not submit your review. Please try again.", ToastType.Error)
            LoadReviewsSection()
        End Try
    End Sub

    ' ─── Helpful Button ───────────────────────────────────────────────────────
    Protected Sub rptReviews_Helpful(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName <> "Helpful" Then Return

        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Toast.ShowMessage(Me, "Please log in to mark a review as helpful.", ToastType.Warning)
            LoadReviewsSection()
            Return
        End If

        Dim reviewId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), reviewId) OrElse reviewId <= 0 Then Return

        Try
            ' Insert ignore duplicates
            Dim inserted As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "IF NOT EXISTS (SELECT 1 FROM ReviewHelpful WHERE ReviewID=@RID AND UserID=@UID) " &
                "BEGIN INSERT INTO ReviewHelpful (ReviewID,UserID) VALUES (@RID,@UID); SELECT 1 END ELSE SELECT 0",
                New SqlParameter("@RID", reviewId),
                New SqlParameter("@UID", userId)))
            If inserted = 1 Then
                Db.ExecuteNonQuery(
                    "UPDATE Reviews SET HelpfulCount = HelpfulCount + 1 WHERE ReviewID = @RID",
                    New SqlParameter("@RID", reviewId))
            Else
                Toast.ShowMessage(Me, "You have already voted on this review.", ToastType.Warning)
            End If
        Catch ex As Exception
            Logger.LogError("Error marking review helpful", ex)
        End Try

        LoadReviewsSection()
    End Sub

    ' ─── Helper Functions ─────────────────────────────────────────────────────
    Public Function GetReviewStars(ByVal ratingValue As Object) As String
        Dim rating As Integer = Convert.ToInt32(ratingValue)
        Return New String("★"c, rating) & New String("☆"c, 5 - rating)
    End Function

    Public Function GetReviewImageUrl(ByVal imageValue As Object) As String
        Dim name As String = Convert.ToString(imageValue)
        If String.IsNullOrEmpty(name) Then Return ""
        Return HttpUtility.HtmlAttributeEncode(ResolveUrl("~/Reviews/" & name))
    End Function

    Public Function GetProductImageUrl(ByVal imageValue As Object) As String
        Dim imagePath As String = Convert.ToString(imageValue)
        Dim imageUrl As String
        If String.IsNullOrWhiteSpace(imagePath) OrElse String.Equals(imagePath, "default.jpg", StringComparison.OrdinalIgnoreCase) Then
            imageUrl = ResolveUrl("~/Images/default.jpg")
        ElseIf imagePath.StartsWith("~/", StringComparison.Ordinal) Then
            imageUrl = ResolveUrl(imagePath)
        ElseIf imagePath.StartsWith("http://", StringComparison.OrdinalIgnoreCase) OrElse imagePath.StartsWith("https://", StringComparison.OrdinalIgnoreCase) Then
            imageUrl = imagePath
        Else
            imageUrl = ResolveUrl("~/Uploads/" & imagePath)
        End If
        Return HttpUtility.HtmlAttributeEncode(imageUrl)
    End Function

    ' ─── Cart/Buy buttons ────────────────────────────────────────────────────
    Protected Sub btnAddToCart_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim qty As Integer = Convert.ToInt32(ddlQuantity.SelectedValue)
        If CartService.TryAddToCart(Context, productId, qty) Then
            Toast.Show(Me, "Added " & qty & " item(s) to your cart!", Toast.ToastType.Success)
        Else
            Toast.Show(Me, "That quantity is not available in stock.", Toast.ToastType.Warning)
        End If
    End Sub

    Protected Sub btnBuyNow_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim qty As Integer = Convert.ToInt32(ddlQuantity.SelectedValue)
        If Not CartService.TryAddToCart(Context, productId, qty) Then
            Toast.Show(Me, "That quantity is not available in stock.", Toast.ToastType.Warning)
            Return
        End If
        Dim userId As Integer
        If Integer.TryParse(Convert.ToString(Session("UserID")), userId) AndAlso userId > 0 Then
            Response.Redirect("~/Customer/checkout.aspx")
        Else
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
        End If
    End Sub

    Protected Sub btnCheckDelivery_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim pin As String = txtPincodeCheck.Text.Trim()
        If pin.Length = 6 Then
            lblDeliveryEst.Text = "✅ Delivery available to " & pin & " by " & DateTime.Now.AddDays(3).ToString("dd MMM yyyy") & " (Free Delivery)"
            lblDeliveryEst.CssClass = "fk-text-success text-xs font-bold display-block mt-2"
        Else
            lblDeliveryEst.Text = "❌ Please enter a valid 6-digit Pincode."
            lblDeliveryEst.CssClass = "fk-text-danger text-xs font-bold display-block mt-2"
        End If
    End Sub

    Protected Sub rptRelated_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        ' Navigation handled by link href
    End Sub
End Class
