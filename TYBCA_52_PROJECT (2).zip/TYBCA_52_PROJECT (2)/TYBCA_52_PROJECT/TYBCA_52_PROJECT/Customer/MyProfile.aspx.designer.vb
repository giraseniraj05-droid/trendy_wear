Option Strict On
Option Explicit On

Partial Public Class MyProfile
    Protected WithEvents lblMessage As Global.System.Web.UI.WebControls.Label
    Protected WithEvents txtName As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMobile As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCurrentPassword As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtNewPassword As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtConfirmPassword As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents btnSaveProfile As Global.System.Web.UI.WebControls.Button
    Protected WithEvents txtAddressName As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAddressMobile As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAddressLine As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAddressCity As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAddressPincode As Global.System.Web.UI.WebControls.TextBox
    Protected WithEvents chkDefaultAddress As Global.System.Web.UI.WebControls.CheckBox
    Protected WithEvents btnAddAddress As Global.System.Web.UI.WebControls.Button
    Protected WithEvents gvAddresses As Global.System.Web.UI.WebControls.GridView
End Class
