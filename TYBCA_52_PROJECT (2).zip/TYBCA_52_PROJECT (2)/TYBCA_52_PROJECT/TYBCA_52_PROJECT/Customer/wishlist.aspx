<%@ Page Title="My Wishlist" Language="vb" AutoEventWireup="false" MasterPageFile="~/navbar.Master" CodeBehind="wishlist.aspx.vb" Inherits="TYBCA_52_PROJECT.wishlist" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="wishlist-container customer-wishlist">
        <h2><i class="bi bi-heart-fill text-danger"></i> My Wishlist</h2>
        
        <asp:Label ID="lblMsg" runat="server" CssClass="alert alert-info" Visible="false"></asp:Label>

        <div class="wishlist-grid">
            <asp:Repeater ID="rptWishlist" runat="server">
                <ItemTemplate>
                    <div class="tw-card p-3 position-relative wishlist-product-card">
                        <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("ProductImage"))), "~/Images/default.jpg", "~/Uploads/" & Convert.ToString(Eval("ProductImage")))) %>' class="img-fluid rounded mb-2 wishlist-product-image" alt='<%# Eval("ProductName") %>' onerror="this.onerror=null;this.src='../Images/default.jpg';" />
                        <h5><%# Eval("ProductName") %></h5>
                        <p class="price-inr">₹<%# Convert.ToDecimal(Eval("Price")).ToString("N2") %></p>
                        <div class="d-flex gap-2">
                            <asp:Button ID="btnAddToCart" runat="server" Text="Add to Cart" CssClass="btn-tw-primary w-100" CommandArgument='<%# Eval("ProductID") %>' OnClick="btnAddToCart_Click" />
                            <asp:Button ID="btnRemove" runat="server" Text="Remove" CssClass="btn btn-outline-danger" CommandArgument='<%# Eval("WishlistID") %>' OnClick="btnRemove_Click" />
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>
</asp:Content>
