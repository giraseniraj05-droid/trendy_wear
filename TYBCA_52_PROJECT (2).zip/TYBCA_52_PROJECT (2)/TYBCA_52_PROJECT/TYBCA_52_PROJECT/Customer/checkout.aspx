<%@ Page Title="Order Checkout" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="checkout.aspx.vb" Inherits="TYBCA_52_PROJECT.checkout" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="checkout-layout checkout-glass-layout">
        <!-- Left: Address & Payment Method -->
        <div class="checkout-form-section">
            <!-- 1. Delivery Address Card -->
            <div class="fk-card mb-4 checkout-address-card">
                <div class="fk-card-header">
                    <h3 class="fk-card-title m-0">1. Delivery Address &amp; Contact</h3>
                </div>
                <div class="fk-card-body">
                    <div class="form-group mb-3">
                        <label class="form-label">Use a saved address</label>
                        <asp:DropDownList ID="ddlSavedAddress" runat="server" CssClass="fk-select" AutoPostBack="true" OnSelectedIndexChanged="ddlSavedAddress_SelectedIndexChanged"></asp:DropDownList>
                        <a href="<%= ResolveUrl("~/Customer/MyProfile.aspx") %>" class="fk-link text-sm">Manage saved addresses</a>
                    </div>
                    <div class="grid-2-col mb-3">
                        <div class="form-group">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <asp:TextBox ID="txtFullName" runat="server" CssClass="fk-input"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="rfvName" runat="server" ControlToValidate="txtFullName" ErrorMessage="Name is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                        </div>

                        <div class="form-group">
                            <label class="form-label">Mobile Number <span class="text-danger">*</span></label>
                            <asp:TextBox ID="txtMobile" runat="server" CssClass="fk-input" MaxLength="10"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="rfvMobile" runat="server" ControlToValidate="txtMobile" ErrorMessage="Mobile is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                            <asp:RegularExpressionValidator ID="revMobile" runat="server" ControlToValidate="txtMobile" ValidationExpression="^[0-9]{10}$" ErrorMessage="Enter valid 10-digit mobile" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label">Delivery Street Address <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtAddress" runat="server" CssClass="fk-input" TextMode="MultiLine" Rows="2"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvAddress" runat="server" ControlToValidate="txtAddress" ErrorMessage="Address is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                    </div>

                    <div class="grid-2-col mb-3">
                        <div class="form-group">
                            <label class="form-label">City <span class="text-danger">*</span></label>
                            <asp:TextBox ID="txtCity" runat="server" CssClass="fk-input"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="rfvCity" runat="server" ControlToValidate="txtCity" ErrorMessage="City is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                        </div>

                        <div class="form-group">
                            <label class="form-label">Pincode <span class="text-danger">*</span></label>
                            <asp:TextBox ID="txtPincode" runat="server" CssClass="fk-input" MaxLength="6"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="rfvPincode" runat="server" ControlToValidate="txtPincode" ErrorMessage="Pincode is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                            <asp:RegularExpressionValidator ID="revPincode" runat="server" ControlToValidate="txtPincode" ValidationExpression="^[0-9]{6}$" ErrorMessage="Enter a valid 6-digit pincode" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="CheckoutForm" />
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Payment Method Card -->
            <div class="fk-card mb-4 checkout-payment-card">
                <div class="fk-card-header">
                    <h3 class="fk-card-title m-0">2. Payment Method</h3>
                </div>
                <div class="fk-card-body">
                    <asp:RadioButtonList ID="rblPayment" runat="server" CssClass="payment-radio-group">
                        <asp:ListItem Value="COD" Selected="True">💵 Cash on Delivery (Pay cash when items arrive)</asp:ListItem>
                        <asp:ListItem Value="UPI" Enabled="False">📱 UPI <span class="badge-coming-soon">Coming soon</span></asp:ListItem>
                    </asp:RadioButtonList>
                </div>
            </div>

            <asp:Button ID="btnPlaceOrder" runat="server" Text="CONFIRM ORDER &amp; PAY NOW &rarr;" CssClass="fk-btn fk-btn-buy width-100 p-3 text-lg font-bold" ValidationGroup="CheckoutForm" OnClick="btnPlaceOrder_Click" />
        </div>

        <!-- Right: Order Summary -->
        <div class="checkout-summary-section">
            <div class="fk-card mb-4 checkout-order-summary">
                <div class="fk-card-header">
                    <h3 class="fk-card-title m-0">Order Summary (<asp:Literal ID="litSummaryCount" runat="server">0</asp:Literal>)</h3>
                </div>
                <div class="fk-card-body p-0">
                    <asp:Repeater ID="rptSummary" runat="server">
                        <ItemTemplate>
                            <div class="flex-between align-center p-3 border-bottom text-sm">
                                <div>
                                    <strong><%# Eval("ProductName") %></strong>
                                    <div class="fk-text-muted text-xs">Size: <%# Eval("Size") %></div>
                                    <div class="fk-text-muted text-xs">Qty: <%# Eval("Quantity") %> x Rs <%# String.Format("{0:N0}", Eval("Price")) %></div>
                                </div>
                                <span class="font-bold">Rs <%# String.Format("{0:N0}", Convert.ToDecimal(Eval("Price")) * Convert.ToInt32(Eval("Quantity"))) %></span>
                            </div>
                        </ItemTemplate>
                    </asp:Repeater>

                    <div class="p-3">
                        <div class="flex-between py-1">
                            <span>Subtotal:</span>
                            <span>Rs <asp:Literal ID="litSubtotal" runat="server">0</asp:Literal></span>
                        </div>
                        <div class="flex-between py-1">
                            <span>Coupon <asp:Literal ID="litCouponCode" runat="server"></asp:Literal>:</span>
                            <span class="fk-text-success">- Rs <asp:Literal ID="litCouponDiscount" runat="server">0</asp:Literal></span>
                        </div>
                        <div class="flex-between py-1">
                            <span>Delivery Charges:</span>
                            <span class="fk-text-success">FREE</span>
                        </div>
                        <hr />
                        <div class="flex-between py-2 text-lg font-bold">
                            <span>Total Payable:</span>
                            <span class="fk-text-primary">Rs <asp:Literal ID="litGrandTotal" runat="server">0</asp:Literal></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
