Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class MyOrders
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/MyOrders.aspx"))
            Return
        End If

        If Not IsPostBack Then
            LoadUserOrders(userId)
        End If
    End Sub

    Private Sub LoadUserOrders(ByVal userId As Integer)
        Try
            Dim sql As String = "SELECT o.OrderID AS order_id, r.Username AS u_name, r.Mobileno AS mobile, o.ShippingAddress AS address, o.City AS city, o.Pincode AS pincode, " & _
                                "p.ProductName AS p_name, p.Size AS size, od.Quantity AS qty, od.TotalPrice AS total_price, o.OrderDate AS order_date, o.Status AS status, " & _
                                "ISNULL(o.PaymentType, 'COD') AS payment_type, ISNULL(o.PaymentStatus, 'Pending') AS payment_status, " & _
                                "COALESCE((SELECT MAX(h.CreatedOn) FROM OrderStatusHistory h WHERE h.OrderID = o.OrderID AND LOWER(h.Status) = 'delivered'), o.OrderDate) AS delivered_on, " & _
                                "(SELECT TOP 1 RequestStatus FROM OrderReturnRequests rr WHERE rr.OrderID = o.OrderID) AS return_status " & _
                                "FROM orders o INNER JOIN register r ON o.UserID = r.UserID INNER JOIN order_details od ON o.OrderID = od.OrderID " & _
                                "INNER JOIN addproduct1 p ON od.ProductID = p.ProductID WHERE o.UserID = @UserID ORDER BY o.OrderID DESC"
            Dim dt As DataTable = Db.ExecuteQuery(sql, New SqlParameter("@UserID", userId))
            rptMyOrders.DataSource = dt
            rptMyOrders.DataBind()

            phEmptyOrders.Visible = (dt.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading user orders", ex)
        End Try
    End Sub

    Protected Sub rptMyOrders_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If e.CommandName = "CancelOrder" Then
            Dim orderId As Integer
            Dim userId As Integer
            If Not Integer.TryParse(Convert.ToString(e.CommandArgument), orderId) OrElse orderId <= 0 OrElse
               Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
                Toast.Show(Me, "Invalid order or customer session.", Toast.ToastType.Error)
                Return
            End If

            Try
                Using conn As SqlConnection = Db.GetConnection()
                    Using transaction As SqlTransaction = conn.BeginTransaction()
                        Using statusCmd As New SqlCommand("UPDATE orders SET Status = 'Cancelled' WHERE OrderID = @OrderID AND UserID = @UserID AND Status = 'Pending'", conn, transaction)
                            statusCmd.Parameters.AddWithValue("@OrderID", orderId)
                            statusCmd.Parameters.AddWithValue("@UserID", userId)
                            If statusCmd.ExecuteNonQuery() = 0 Then
                                transaction.Rollback()
                                Toast.Show(Me, "Only your pending orders can be cancelled.", Toast.ToastType.Warning)
                                Return
                            End If
                        End Using

                        Using detailsCmd As New SqlCommand("SELECT ProductID, Quantity FROM order_details WHERE OrderID = @OrderID", conn, transaction)
                            detailsCmd.Parameters.AddWithValue("@OrderID", orderId)
                            Dim details As New DataTable()
                            Using adapter As New SqlDataAdapter(detailsCmd)
                                adapter.Fill(details)
                            End Using
                            For Each detail As DataRow In details.Rows
                                Using stockCmd As New SqlCommand("UPDATE addproduct1 SET Stock = Stock + @Quantity WHERE ProductID = @ProductID", conn, transaction)
                                    stockCmd.Parameters.AddWithValue("@Quantity", Convert.ToInt32(detail("Quantity")))
                                    stockCmd.Parameters.AddWithValue("@ProductID", Convert.ToInt32(detail("ProductID")))
                                    stockCmd.ExecuteNonQuery()
                                End Using
                            Next
                        End Using
                        Using historyCmd As New SqlCommand("INSERT INTO OrderStatusHistory (OrderID, Status, Notes, UpdatedBy) VALUES (@OrderID, 'Cancelled', 'Order cancelled by customer', @UserID)", conn, transaction)
                            historyCmd.Parameters.AddWithValue("@OrderID", orderId)
                            historyCmd.Parameters.AddWithValue("@UserID", userId)
                            historyCmd.ExecuteNonQuery()
                        End Using
                        transaction.Commit()
                    End Using
                End Using
                Dim restoredProducts As DataTable = Db.ExecuteQuery("SELECT DISTINCT ProductID FROM order_details WHERE OrderID = @OrderID", Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                For Each restoredProduct As DataRow In restoredProducts.Rows
                    StockNotificationService.NotifyIfBackInStock(Convert.ToInt32(restoredProduct("ProductID")), Me)
                Next
                Try
                    Dim customer As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE UserID = @UserID",
                                                                Db.CreateParam("@UserID", SqlDbType.Int, userId))
                    Dim safeUsername As String = If(customer.Rows.Count > 0, HttpUtility.HtmlEncode(Convert.ToString(customer.Rows(0)("Username"))), "")
                    If customer.Rows.Count > 0 Then
                        Mailer.SendAsync(Convert.ToString(customer.Rows(0)("Email")), "Order #" & orderId.ToString() & " cancelled",
                                         Mailer.Wrap("Order cancelled",
                                                     "<p>Hello " & safeUsername & ", order #" & orderId.ToString() & " has been cancelled.</p>"),
                                         "OrderCancelledCustomer")
                    End If
                    Mailer.SendAsync(ConfigurationManager.AppSettings("AdminEmail"), "Customer cancelled order #" & orderId.ToString(),
                                     Mailer.Wrap("Customer cancelled an order",
                                                 "<p>Customer " & safeUsername & " cancelled order #" & orderId.ToString() & ".</p>"),
                                     "OrderCancelledAdmin")
                Catch notificationEx As Exception
                    Logger.LogError("Error preparing cancellation notifications for order " & orderId, notificationEx)
                End Try
                Toast.Show(Me, "Order #" & orderId & " has been cancelled and stock was restored.", Toast.ToastType.Success)
                LoadUserOrders(userId)
            Catch ex As Exception
                Logger.LogError("Error cancelling user order", ex)
                Toast.Show(Me, "Unable to cancel this order. Please try again.", Toast.ToastType.Error)
            End Try
        End If
        If e.CommandName = "RequestReturn" Then SubmitReturnRequest(e)
    End Sub

    Private Sub SubmitReturnRequest(ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim orderId As Integer
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), orderId) OrElse
           Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then Return
        Dim reasonBox As TextBox = TryCast(e.Item.FindControl("txtReturnReason"), TextBox)
        Dim reason As String = If(reasonBox Is Nothing, "", reasonBox.Text.Trim())
        If String.IsNullOrWhiteSpace(reason) OrElse reason.Length > 1000 Then
            Toast.Show(Me, "Please enter a return reason (up to 1000 characters).", Toast.ToastType.Warning)
            Return
        End If
        Try
            Dim inserted As Integer = Db.ExecuteNonQuery(
                "INSERT INTO OrderReturnRequests (OrderID, UserID, Reason) " &
                "SELECT @OrderID, @UserID, @Reason WHERE EXISTS (SELECT 1 FROM orders o WHERE o.OrderID = @OrderID AND o.UserID = @UserID AND LOWER(o.Status) = 'delivered' " &
                "AND COALESCE((SELECT MAX(h.CreatedOn) FROM OrderStatusHistory h WHERE h.OrderID = o.OrderID AND LOWER(h.Status) = 'delivered'), o.OrderDate) >= DATEADD(day, -7, GETDATE())) " &
                "AND NOT EXISTS (SELECT 1 FROM OrderReturnRequests WHERE OrderID = @OrderID)",
                Db.CreateParam("@OrderID", SqlDbType.Int, orderId),
                Db.CreateParam("@UserID", SqlDbType.Int, userId),
                Db.CreateParam("@Reason", SqlDbType.NVarChar, reason, 1000))
            If inserted = 0 Then
                Toast.Show(Me, "This order is outside the 7-day return window or already has a request.", Toast.ToastType.Warning)
                Return
            End If
            Dim customer As DataTable = Db.ExecuteQuery("SELECT Username, Email FROM register WHERE UserID = @UserID", Db.CreateParam("@UserID", SqlDbType.Int, userId))
            If customer.Rows.Count > 0 Then
                Dim safeName As String = HttpUtility.HtmlEncode(Convert.ToString(customer.Rows(0)("Username")))
                Mailer.SendAsync(Convert.ToString(customer.Rows(0)("Email")), "Return request received for order #" & orderId.ToString(),
                                 Mailer.Wrap("Return request received", "<p>Hello " & safeName & ", we received your return/refund request for order #" & orderId.ToString() & ". Our team will review it and email you with a decision.</p>"), "ReturnRequestCustomer")
                Mailer.SendAsync(ConfigurationManager.AppSettings("AdminEmail"), "Return request for order #" & orderId.ToString(),
                                 Mailer.Wrap("Customer return request", "<p>" & safeName & " requested a return/refund for order #" & orderId.ToString() & ".</p><p>Reason: " & HttpUtility.HtmlEncode(reason) & "</p>"), "ReturnRequestAdmin")
            End If
            Toast.Show(Me, "Your return/refund request was sent for approval.", Toast.ToastType.Success)
            LoadUserOrders(userId)
        Catch ex As Exception
            Logger.LogError("Error submitting return request for order " & orderId.ToString(), ex)
            Toast.Show(Me, "Could not submit the return request. Please try again.", Toast.ToastType.Error)
        End Try
    End Sub

    Public Function CanRequestReturn(ByVal status As Object, ByVal deliveredOn As Object, ByVal returnStatus As Object) As Boolean
        If Not String.Equals(Convert.ToString(status), "Delivered", StringComparison.OrdinalIgnoreCase) OrElse
           deliveredOn Is Nothing OrElse IsDBNull(deliveredOn) Then Return False
        If Not IsDBNull(returnStatus) AndAlso Not String.IsNullOrWhiteSpace(Convert.ToString(returnStatus)) Then Return False
        Return Convert.ToDateTime(deliveredOn) >= DateTime.Now.AddDays(-7)
    End Function

    Protected Sub rptMyOrders_ItemDataBound(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        If e.Item.ItemType <> ListItemType.Item AndAlso e.Item.ItemType <> ListItemType.AlternatingItem Then Return
        Dim order As DataRowView = TryCast(e.Item.DataItem, DataRowView)
        If order Is Nothing Then Return

        Dim historyRepeater As Repeater = TryCast(e.Item.FindControl("rptStatusHistory"), Repeater)
        If historyRepeater Is Nothing Then Return

        Try
            Dim history As DataTable = Db.ExecuteQuery("SELECT Status, Notes, CreatedOn FROM OrderStatusHistory WHERE OrderID = @OrderID ORDER BY CreatedOn",
                                                       Db.CreateParam("@OrderID", SqlDbType.Int, Convert.ToInt32(order("order_id"))))
            historyRepeater.DataSource = history
            historyRepeater.DataBind()
        Catch ex As Exception
            Logger.LogError("Error loading order status history", ex)
        End Try
    End Sub

    Public Function GetPaymentStatusBadgeClass(ByVal pStatus As Object) As String
        Dim st As String = Convert.ToString(pStatus).ToLower()
        If st = "paid" Then Return "badge badge-success"
        If st = "pending" Then Return "badge badge-warning"
        If st = "refunded" Then Return "badge badge-info"
        If st = "failed" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function

    Public Function GetPaymentMethodDisplay(ByVal methodVal As Object) As String
        Return PaymentService.GetPaymentMethodDisplay(Convert.ToString(methodVal))
    End Function

    Public Function GetStatusBadgeClass(ByVal statusVal As Object) As String
        Dim st As String = Convert.ToString(statusVal).ToLower()
        If st = "pending" Then Return "badge badge-warning"
        If st = "confirmed" Then Return "badge badge-primary"
        If st = "shipped" Then Return "badge badge-info"
        If st = "delivered" Then Return "badge badge-success"
        If st = "cancelled" Then Return "badge badge-danger"
        Return "badge badge-secondary"
    End Function

    Public Function GetStepClass(ByVal statusVal As Object, ByVal stepNum As Integer) As String
        Dim st As String = Convert.ToString(statusVal).ToLower()
        Dim currentStep As Integer = 1
        If st = "confirmed" Then currentStep = 2
        If st = "shipped" OrElse st = "out for delivery" Then currentStep = 3
        If st = "delivered" Then currentStep = 4
        If st = "cancelled" Then Return "step-item step-cancelled"

        If stepNum < currentStep Then
            Return "step-item step-completed"
        ElseIf stepNum = currentStep Then
            Return "step-item step-active"
        Else
            Return "step-item"
        End If
    End Function
End Class
