Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class OrderThankyou
    Inherits System.Web.UI.Page

    Private orderId As Integer = 0
    Private userId As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx")
            Return
        End If

        If Not Integer.TryParse(Request.QueryString("oid"), orderId) OrElse orderId <= 0 Then
            Response.Redirect("~/Customer/MyOrders.aspx")
            Return
        End If

        ' Security: verify this order belongs to the logged-in user
        Dim ownerCheck As Object = Db.ExecuteScalar(
            "SELECT COUNT(*) FROM orders WHERE OrderID = @OID AND UserID = @UID",
            New SqlParameter("@OID", orderId),
            New SqlParameter("@UID", userId))
        If Convert.ToInt32(ownerCheck) = 0 Then
            Response.Redirect("~/Customer/MyOrders.aspx")
            Return
        End If

        If Not IsPostBack Then
            litOrderID.Text = orderId.ToString()
            LoadOrderProducts()
        End If
    End Sub

    Private Sub LoadOrderProducts()
        Try
            Dim sql As String =
                "SELECT od.ProductID, p.ProductName, ISNULL(p.ProductImage,'') AS Image, " &
                "od.Quantity, od.TotalPrice, " &
                "CASE WHEN EXISTS (SELECT 1 FROM Reviews rv WHERE rv.ProductID = od.ProductID AND rv.UserID = @UID) THEN 1 ELSE 0 END AS AlreadyReviewed " &
                "FROM order_details od " &
                "INNER JOIN addproduct1 p ON p.ProductID = od.ProductID " &
                "WHERE od.OrderID = @OID"
            Dim dt As DataTable = Db.ExecuteQuery(sql,
                New SqlParameter("@OID", orderId),
                New SqlParameter("@UID", userId))
            rptOrderProducts.DataSource = dt
            rptOrderProducts.DataBind()
            phNoProducts.Visible = (dt.Rows.Count = 0)
        Catch ex As Exception
            Logger.LogError("Error loading order products for thank-you page", ex)
        End Try
    End Sub

    Protected Sub rptOrderProducts_ItemCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName <> "SubmitReview" Then Return

        Dim productId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), productId) OrElse productId <= 0 Then Return

        ' Find controls in the repeater item
        Dim item As System.Web.UI.WebControls.RepeaterItem = Nothing
        For Each ri As System.Web.UI.WebControls.RepeaterItem In rptOrderProducts.Items
            Dim btn As System.Web.UI.WebControls.LinkButton =
                CType(ri.FindControl("btnSubmit"), System.Web.UI.WebControls.LinkButton)
            If btn IsNot Nothing AndAlso Convert.ToString(btn.CommandArgument) = productId.ToString() Then
                item = ri
                Exit For
            End If
        Next
        If item Is Nothing Then Return

        Dim txtTitle As System.Web.UI.WebControls.TextBox =
            CType(item.FindControl("txtTitle"), System.Web.UI.WebControls.TextBox)
        Dim txtComment As System.Web.UI.WebControls.TextBox =
            CType(item.FindControl("txtComment"), System.Web.UI.WebControls.TextBox)
        Dim fuPhoto As System.Web.UI.WebControls.FileUpload =
            CType(item.FindControl("fuPhoto"), System.Web.UI.WebControls.FileUpload)

        ' Read rating from submitted form (hidden radio group per product)
        Dim ratingKey As String = "rating_ty_" & productId.ToString()
        Dim rating As Integer = 0
        If Not Integer.TryParse(Request.Form(ratingKey), rating) OrElse rating < 1 OrElse rating > 5 Then
            Toast.ShowMessage(Me, "Please select a star rating for the product.", ToastType.Warning)
            LoadOrderProducts()
            Return
        End If

        Dim comment As String = If(txtComment IsNot Nothing, txtComment.Text.Trim(), "")
        Dim title As String = If(txtTitle IsNot Nothing, txtTitle.Text.Trim(), "")

        If String.IsNullOrEmpty(comment) Then
            Toast.ShowMessage(Me, "Please write a short review comment.", ToastType.Warning)
            LoadOrderProducts()
            Return
        End If

        ' Photo upload (optional)
        Dim reviewImageName As String = Nothing
        If fuPhoto IsNot Nothing AndAlso fuPhoto.HasFile Then
            Dim ext As String = Path.GetExtension(fuPhoto.FileName).ToLowerInvariant()
            If ext <> ".jpg" AndAlso ext <> ".jpeg" AndAlso ext <> ".png" Then
                Toast.ShowMessage(Me, "Only JPG and PNG images are allowed.", ToastType.Warning)
                LoadOrderProducts()
                Return
            End If
            If fuPhoto.PostedFile.ContentLength > 2 * 1024 * 1024 Then
                Toast.ShowMessage(Me, "Photo must be 2 MB or smaller.", ToastType.Warning)
                LoadOrderProducts()
                Return
            End If
            reviewImageName = Guid.NewGuid().ToString("N") & ext
            fuPhoto.SaveAs(Server.MapPath("~/Reviews/" & reviewImageName))
        End If

        Try
            Dim commentParam As New SqlParameter("@Comment", SqlDbType.NVarChar, -1)
            commentParam.Value = comment

            If reviewImageName IsNot Nothing Then
                Dim imgParam As New SqlParameter("@ReviewImage", SqlDbType.NVarChar, 255)
                imgParam.Value = reviewImageName
                Db.ExecuteNonQuery(
                    "IF NOT EXISTS (SELECT 1 FROM Reviews WHERE UserID=@UID AND ProductID=@PID) " &
                    "INSERT INTO Reviews (ProductID,UserID,Rating,Title,Comment,ReviewImage,CreatedOn,IsApproved,HelpfulCount) " &
                    "VALUES (@PID,@UID,@Rating,@Title,@Comment,@ReviewImage,GETDATE(),0,0)",
                    New SqlParameter("@UID", userId),
                    New SqlParameter("@PID", productId),
                    New SqlParameter("@Rating", rating),
                    Db.CreateParam("@Title", SqlDbType.NVarChar, title, 150),
                    commentParam, imgParam)
            Else
                Db.ExecuteNonQuery(
                    "IF NOT EXISTS (SELECT 1 FROM Reviews WHERE UserID=@UID AND ProductID=@PID) " &
                    "INSERT INTO Reviews (ProductID,UserID,Rating,Title,Comment,CreatedOn,IsApproved,HelpfulCount) " &
                    "VALUES (@PID,@UID,@Rating,@Title,@Comment,GETDATE(),0,0)",
                    New SqlParameter("@UID", userId),
                    New SqlParameter("@PID", productId),
                    New SqlParameter("@Rating", rating),
                    Db.CreateParam("@Title", SqlDbType.NVarChar, title, 150),
                    commentParam)
            End If

            ' Send thank-you email
            Try
                Dim user As DataTable = Db.ExecuteQuery(
                    "SELECT Username, Email FROM register WHERE UserID=@UID",
                    New SqlParameter("@UID", userId))
                Dim pName As String = HttpUtility.HtmlEncode(
                    Convert.ToString(Db.ExecuteScalar("SELECT ProductName FROM addproduct1 WHERE ProductID=@PID",
                    New SqlParameter("@PID", productId))))
                If user.Rows.Count > 0 Then
                    Mailer.SendAsync(Convert.ToString(user.Rows(0)("Email")), "Thanks for your review",
                        Mailer.Wrap("Thanks for your review",
                            "<p>Hello " & HttpUtility.HtmlEncode(Convert.ToString(user.Rows(0)("Username"))) &
                            ", thank you for reviewing <strong>" & pName & "</strong>. It will appear once approved.</p>"),
                        "ReviewReceived")
                End If
                Mailer.SendAsync(System.Configuration.ConfigurationManager.AppSettings("AdminEmail"),
                    "Review pending approval",
                    Mailer.Wrap("New review pending",
                        "<p>Product: " & pName & "</p><p>Rating: " & rating & "/5</p>"),
                    "ReviewPending")
            Catch ex As Exception
                Logger.LogError("Error sending review email", ex)
            End Try

            Toast.ShowMessage(Me, "Review submitted! It will appear once approved by admin. Thank you! 🎉", ToastType.Success)
            LoadOrderProducts()
        Catch ex As Exception
            Logger.LogError("Error submitting post-order review for UserID=" & userId & " ProductID=" & productId, ex)
            Toast.ShowMessage(Me, "Could not submit review. Please try again.", ToastType.Error)
            LoadOrderProducts()
        End Try
    End Sub

    ' ─── Helpers ─────────────────────────────────────────────────────────────
    Public Function GetStarRadios(ByVal productIdVal As Object) As String
        Dim pid As String = Convert.ToString(productIdVal)
        Dim key As String = "rating_ty_" & pid
        Dim sb As New StringBuilder()
        ' Row-reverse CSS means we render 5 down to 1
        For i As Integer = 5 To 1 Step -1
            Dim id As String = "star_" & i & "_" & pid
            sb.Append("<input type='radio' id='" & id & "' name='" & key & "' value='" & i & "' />")
            sb.Append("<label for='" & id & "' aria-label='" & i & " stars'>&#9733;</label>")
        Next
        Return sb.ToString()
    End Function

    Public Function GetProductImageUrl(ByVal imageValue As Object) As String
        Dim img As String = Convert.ToString(imageValue)
        If String.IsNullOrEmpty(img) OrElse img = "default.jpg" Then
            Return ResolveUrl("~/Images/default.jpg")
        End If
        Return HttpUtility.HtmlAttributeEncode(ResolveUrl("~/Uploads/" & img))
    End Function
End Class

