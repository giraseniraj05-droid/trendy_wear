<%@ Page Title="Product Details" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="ProductDetails.aspx.vb" Inherits="TYBCA_52_PROJECT.ProductDetails" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="pdp-container fk-card mb-5">
        <div class="fk-card-body p-4">
            <div class="grid-pdp">
                <!-- Left: Product Image -->
                <div class="pdp-image-col">
                    <div class="pdp-main-img-wrap">
                        <img id="imgMainProduct" runat="server" class="pdp-img" src="~/Images/default.jpg" alt="Product Image" onerror="this.onerror=null;this.src='../Images/default.jpg';" />
                        <asp:Label ID="lblDiscountBadge" runat="server" CssClass="discount-badge text-md"></asp:Label>
                    </div>
                    <div class="pdp-gallery">
                        <asp:Repeater ID="rptProductImages" runat="server">
                            <ItemTemplate>
                                <button type="button" class="pdp-gallery-thumb" aria-label="View product image"
                                        onclick="this.closest('.pdp-image-col').querySelector('.pdp-img').src=this.querySelector('img').src;">
                                    <img loading="lazy" decoding="async" src='<%# GetProductImageUrl(Eval("Image")) %>' alt="Product photo" onerror="this.onerror=null;this.src='../Images/default.jpg';" />
                                </button>
                            </ItemTemplate>
                        </asp:Repeater>
                    </div>
                </div>

                <!-- Right: Product Info & Actions -->
                <div class="pdp-info-col">
                    <span class="product-cat text-sm font-bold uppercase"><asp:Literal ID="litCategory" runat="server">Clothing</asp:Literal></span>
                    <h1 class="pdp-title"><asp:Literal ID="litProductName" runat="server">Product Title</asp:Literal></h1>
                    <p class="fk-text-muted text-sm pdp-size-note">Size: <strong><asp:Literal ID="litSize" runat="server"></asp:Literal></strong></p>

                    <!-- Price Block -->
                    <div class="pdp-price-block mb-3 flex-gap align-center">
                        <span class="pdp-price text-xxl font-bold fk-text-primary">Rs <asp:Literal ID="litPrice" runat="server">0</asp:Literal></span>
                        <span class="pdp-old-price text-lg text-mrp">Rs <asp:Literal ID="litOldPrice" runat="server">0</asp:Literal></span>
                        <span class="fk-badge-green font-bold text-sm"><asp:Literal ID="litDiscountPct" runat="server">0% OFF</asp:Literal></span>
                    </div>

                    <!-- Stock Warning -->
                    <div class="pdp-stock-block mb-4">
                        <asp:Label ID="lblStockStatus" runat="server" CssClass="fk-badge"></asp:Label>
                        <asp:Panel ID="pnlStockAlert" runat="server" Visible="false" CssClass="mt-2">
                            <p class="text-sm">Get an email when this item is back in stock.</p>
                            <div class="flex-gap">
                                <asp:TextBox ID="txtStockAlertEmail" runat="server" CssClass="fk-input" TextMode="Email" MaxLength="255" placeholder="Your email"></asp:TextBox>
                                <asp:Button ID="btnStockAlert" runat="server" Text="Notify me" CssClass="fk-btn-sm fk-btn-outline" OnClick="btnStockAlert_Click" />
                            </div>
                            <asp:Label ID="lblStockAlertMessage" runat="server" CssClass="text-xs display-block mt-1"></asp:Label>
                        </asp:Panel>
                    </div>

                    <!-- Description -->
                    <div class="pdp-desc-block mb-4">
                        <h4 class="text-sm font-bold mb-1">Product Highlights &amp; Specifications:</h4>
                        <p class="fk-text-muted text-sm"><asp:Literal ID="litDetails" runat="server">Premium quality fabric designed for comfort and durability.</asp:Literal></p>
                    </div>

                    <!-- Quantity Selector -->
                    <div class="pdp-qty-block mb-4 flex-gap align-center">
                        <label class="font-bold text-sm">Quantity:</label>
                        <asp:DropDownList ID="ddlQuantity" runat="server" CssClass="fk-select text-sm width-auto" style="min-width: 80px;">
                            <asp:ListItem Value="1" Selected="True">1</asp:ListItem>
                            <asp:ListItem Value="2">2</asp:ListItem>
                            <asp:ListItem Value="3">3</asp:ListItem>
                            <asp:ListItem Value="4">4</asp:ListItem>
                            <asp:ListItem Value="5">5</asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <!-- Action Buttons -->
                    <div class="pdp-actions flex-gap mb-4">
                        <asp:Button ID="btnAddToCart" runat="server" Text="🛒 ADD TO CART" CssClass="fk-btn fk-btn-cart pdp-btn flex-1" OnClick="btnAddToCart_Click" />
                        <asp:Button ID="btnBuyNow" runat="server" Text="⚡ BUY NOW" CssClass="fk-btn fk-btn-buy pdp-btn flex-1" OnClick="btnBuyNow_Click" />
                    </div>

                    <!-- Delivery Estimate Box -->
                    <div class="pdp-delivery-box p-3">
                        <h4 class="text-sm font-bold mb-2">🚚 Delivery &amp; Services</h4>
                        <div class="flex-gap-sm">
                            <asp:TextBox ID="txtPincodeCheck" runat="server" CssClass="fk-input text-sm pdp-pincode-input" placeholder="Enter Pincode (e.g. 395007)" MaxLength="6" style="width: 180px; max-width: 100%;"></asp:TextBox>
                            <asp:Button ID="btnCheckDelivery" runat="server" Text="Check" CssClass="fk-btn-sm fk-btn-outline" OnClick="btnCheckDelivery_Click" />
                        </div>
                        <asp:Label ID="lblDeliveryEst" runat="server" CssClass="fk-text-success text-xs font-bold display-block mt-2" Text="Free Delivery available in 2-4 business days"></asp:Label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="fk-container mb-5 pdp-reviews-section">
        <div class="fk-card">
            <div class="fk-card-header flex-between">
                <h2 class="fk-card-title">Customer Reviews</h2>
                <strong><asp:Literal ID="litAvgRating" runat="server">0.0</asp:Literal> / 5 (<asp:Literal ID="litReviewCount" runat="server">0</asp:Literal> reviews)</strong>
            </div>
            <div class="fk-card-body">
                <asp:Literal ID="litRatingBreakdown" runat="server"></asp:Literal>

                <%-- Sort + Pager row --%>
                <div class="review-sort-pager">
                    <div>
                        <label class="fk-text-muted text-sm">Sort by:</label>
                        <asp:DropDownList ID="ddlReviewSort" runat="server" CssClass="fk-select text-sm" AutoPostBack="true" OnSelectedIndexChanged="ddlReviewSort_Changed" style="width:auto;min-width:120px;">
                            <asp:ListItem Value="newest">Newest</asp:ListItem>
                            <asp:ListItem Value="highest">Highest Rating</asp:ListItem>
                            <asp:ListItem Value="lowest">Lowest Rating</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <div>
                        <asp:LinkButton ID="lbPrev" runat="server" CssClass="fk-btn-sm fk-btn-outline" OnClick="lbPrev_Click" CausesValidation="false">&laquo; Prev</asp:LinkButton>
                        &nbsp;<asp:Literal ID="litPageInfo" runat="server">Page 1</asp:Literal>&nbsp;
                        <asp:LinkButton ID="lbNext" runat="server" CssClass="fk-btn-sm fk-btn-outline" OnClick="lbNext_Click" CausesValidation="false">Next &raquo;</asp:LinkButton>
                    </div>
                </div>

                <%-- Reviews list --%>
                <asp:Repeater ID="rptReviews" runat="server">
                    <ItemTemplate>
                        <article class="review-entry">
                            <div class="flex-between">
                                <div>
                                    <strong><%#: Eval("Username") %></strong>
                                    <asp:Panel runat="server" Visible='<%# Convert.ToBoolean(Eval("IsVerified")) %>' style="display:inline"><span class="review-verified-badge">✔ Verified Purchase</span></asp:Panel>
                                </div>
                                <span class="fk-text-warning"><%# GetReviewStars(Eval("Rating")) %></span>
                            </div>
                            <div class="fk-text-muted text-xs"><%# Eval("CreatedOn", "{0:dd MMM yyyy}") %></div>
                            <h3 class="text-base mt-2"><%#: Eval("Title") %></h3>
                            <p class="mb-1"><%#: Eval("Comment") %></p>
                            <asp:Panel runat="server" Visible='<%# Not String.IsNullOrEmpty(Convert.ToString(Eval("ReviewImage"))) %>'>
                                <div>
                                    <img loading="lazy" decoding="async" src='<%# GetReviewImageUrl(Eval("ReviewImage")) %>' alt="Review photo" class="review-photo"
                                         onclick="this.style.maxWidth=this.style.maxWidth===&quot;300px&quot;?&quot;100px&quot;:&quot;300px&quot;" />
                                </div>
                            </asp:Panel>
                            <%-- Admin reply --%>
                            <asp:Panel ID="pnlAdminReply" runat="server" Visible='<%# Not String.IsNullOrEmpty(Convert.ToString(Eval("AdminReply"))) %>' CssClass="fk-card-body bg-light mt-2">
                                <strong>Store reply</strong>
                                <p class="m-0"><%#: Eval("AdminReply") %></p>
                                <small class="fk-text-muted"><%# Eval("ReplyOn", "{0:dd MMM yyyy}") %></small>
                            </asp:Panel>
                            <%-- Helpful button --%>
                            <div class="mt-2">
                                <asp:LinkButton runat="server" CommandName="Helpful" CommandArgument='<%# Eval("ReviewID") %>'
                                    CssClass="helpful-btn" CausesValidation="false"
                                    OnCommand="rptReviews_Helpful">
                                    👍 Helpful (<%# Eval("HelpfulCount") %>)
                                </asp:LinkButton>
                            </div>
                        </article>
                    </ItemTemplate>
                </asp:Repeater>
                <asp:PlaceHolder ID="phNoReviews" runat="server" Visible="false">
                    <p class="fk-text-muted mt-3">No approved reviews yet. Be the first to review this product after delivery.</p>
                </asp:PlaceHolder>
            </div>
        </div>
    </section>

    <%-- Write a Review section --%>
    <section class="fk-container mb-5">
        <div class="fk-card">
            <div class="fk-card-header"><h2 class="fk-card-title">Write a Review</h2></div>
            <div class="fk-card-body">
                <%-- Not logged in --%>
                <asp:PlaceHolder ID="phLoginPrompt" runat="server" Visible="false">
                    <p class="fk-text-muted">Please <a href="<%=ResolveUrl("~/login.aspx") %>">log in</a> to write a review.</p>
                </asp:PlaceHolder>
                <%-- Logged in but not a verified purchaser --%>
                <asp:PlaceHolder ID="phNotEligible" runat="server" Visible="false">
                    <p class="fk-text-muted">Only customers who have received this product can submit a review.</p>
                </asp:PlaceHolder>
                <%-- Review form (shown when eligible) --%>
                <asp:Panel ID="pnlReviewForm" runat="server" Visible="false">
                    <asp:Label ID="lblReviewMsg" runat="server" CssClass="fk-text-muted text-sm display-block mb-3"></asp:Label>
                    <fieldset class="mb-3">
                        <legend class="form-label">Your Rating <span class="fk-text-danger">*</span></legend>
                        <div class="review-stars-input" role="radiogroup" aria-label="Review rating">
                            <asp:RadioButton ID="rb5" runat="server" GroupName="ReviewRating" Text="★" InputAttributes-value="5" /><label for="<%=rb5.ClientID %>">★</label>
                            <asp:RadioButton ID="rb4" runat="server" GroupName="ReviewRating" Text="★" InputAttributes-value="4" /><label for="<%=rb4.ClientID %>">★</label>
                            <asp:RadioButton ID="rb3" runat="server" GroupName="ReviewRating" Text="★" InputAttributes-value="3" /><label for="<%=rb3.ClientID %>">★</label>
                            <asp:RadioButton ID="rb2" runat="server" GroupName="ReviewRating" Text="★" InputAttributes-value="2" /><label for="<%=rb2.ClientID %>">★</label>
                            <asp:RadioButton ID="rb1" runat="server" GroupName="ReviewRating" Text="★" InputAttributes-value="1" /><label for="<%=rb1.ClientID %>">★</label>
                        </div>
                        <asp:HiddenField ID="hfRating" runat="server" Value="0" />
                        <script>
                            (function () {
                                var rbs = ['rb5','rb4','rb3','rb2','rb1'];
                                rbs.forEach(function(id) {
                                    var el = document.getElementById('<%= rb5.ClientID %>'.replace('rb5', id));
                                    if (el) el.addEventListener('change', function() {
                                        document.getElementById('<%= hfRating.ClientID %>').value = this.value || this.getAttribute('value');
                                    });
                                });
                            })();
                        </script>
                    </fieldset>
                    <div class="form-group mb-3">
                        <label class="form-label">Review Title</label>
                        <asp:TextBox ID="txtReviewTitle" runat="server" CssClass="fk-input" MaxLength="150" placeholder="Summarise your experience"></asp:TextBox>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label">Review <span class="fk-text-danger">*</span></label>
                        <asp:TextBox ID="txtReviewComment" runat="server" CssClass="fk-input" TextMode="MultiLine" Rows="4" placeholder="Share details of your experience..."></asp:TextBox>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label">Photo (optional, jpg/png, max 2 MB)</label>
                        <asp:FileUpload ID="fuReviewPhoto" runat="server" CssClass="fk-input" accept=".jpg,.jpeg,.png" />
                    </div>
                    <asp:Button ID="btnSubmitReview" runat="server" Text="Submit Review" CssClass="fk-btn fk-btn-primary" OnClick="btnSubmitReview_Click" CausesValidation="false" />
                </asp:Panel>
            </div>
        </div>
    </section>

    <!-- Related Products -->
    <div class="fk-container mb-5 pdp-related-products">
        <h2 class="section-heading mb-3">Similar Products You Might Like</h2>
        <div class="product-grid">
            <asp:Repeater ID="rptRelated" runat="server" OnItemCommand="rptRelated_ItemCommand">
                <ItemTemplate>
                    <div class="fk-product-card">
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                            <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' 
                                 alt='<%# Eval("p_name") %>' class="product-img" onerror="this.src='../Images/default.jpg';" />
                        </a>
                        <div class="card-body">
                            <h3 class="product-name">
                                <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%# Eval("p_name") %></a>
                            </h3>
                            <div class="price-row">
                                <span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                            </div>
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>
    <asp:PlaceHolder ID="phRecentlyViewed" runat="server" Visible="false">
        <div class="fk-container mb-5">
            <h2 class="section-heading mb-3">Recently viewed</h2>
            <div class="product-grid">
                <asp:Repeater ID="rptRecentlyViewed" runat="server">
                    <ItemTemplate>
                        <div class="fk-product-card">
                            <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                                <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' alt='<%# Eval("p_name") %>' class="product-img" onerror="this.onerror=null;this.src='../Images/default.jpg';" />
                            </a>
                            <div class="card-body">
                                <h3 class="product-name"><a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%# Eval("p_name") %></a></h3>
                                <span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>
    </asp:PlaceHolder>
</asp:Content>
