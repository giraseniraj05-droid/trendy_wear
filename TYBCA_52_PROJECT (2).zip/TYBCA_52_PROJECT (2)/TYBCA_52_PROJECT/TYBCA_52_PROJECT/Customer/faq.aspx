<%@ Page Title="FAQ" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-card policy-content-panel faq-content-panel"><div class="fk-card-header"><h1 class="fk-card-title">Frequently asked questions</h1></div><div class="fk-card-body">
        <section class="faq-item"><h3>How do I place an order?</h3><p>Add available products to your cart, sign in, verify your email, and complete checkout.</p></section>
        <section class="faq-item"><h3>Can I change my order?</h3><p>Pending orders can be cancelled from My Orders. Contact support for help with orders already being prepared.</p></section>
        <section class="faq-item"><h3>How do I request a return or refund?</h3><p>For a delivered order, submit a request from My Orders within seven days of delivery. Requests are reviewed by the store team.</p></section>
        <section class="faq-item"><h3>How can I check delivery progress?</h3><p>Open My Orders to see the latest status and order history.</p></section>
        <section class="faq-item"><h3>What if an item is out of stock?</h3><p>Use the Notify me option on the product page and we will email you when it is available again.</p></section>
        <p><a href="<%= ResolveUrl("~/contact.aspx") %>" class="fk-link">Contact support</a></p>
    </div></div>
</asp:Content>
