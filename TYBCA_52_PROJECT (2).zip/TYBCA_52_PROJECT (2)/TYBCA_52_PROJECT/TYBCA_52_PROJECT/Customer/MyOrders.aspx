<%@ Page Title="My Orders & Tracking" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="MyOrders.aspx.vb" Inherits="TYBCA_52_PROJECT.MyOrders" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <!-- Header -->
    <div class="dash-header flex-between mb-4">
        <div>
            <h1 class="dash-title">📦 My Orders &amp; Delivery Tracker</h1>
            <p class="dash-subtitle">Track real-time delivery status, view past purchase history, and download invoice copies.</p>
        </div>
    </div>

    <!-- Orders Cards Container -->
    <div class="orders-list-container customer-orders-list">
        <asp:Repeater ID="rptMyOrders" runat="server" OnItemCommand="rptMyOrders_ItemCommand" OnItemDataBound="rptMyOrders_ItemDataBound">
            <ItemTemplate>
                <div class="fk-card order-tracking-card customer-order-card mb-4">
                    <!-- Order Header -->
                    <div class="fk-card-header flex-between align-center p-3 border-bottom">
                        <div>
                            <span class="text-xs fk-text-muted">Order ID:</span>
                            <strong class="text-sm ml-1">#<%# Eval("order_id") %></strong>
                            <span class="text-xs fk-text-muted ml-3">Placed on: <%# Eval("order_date", "{0:dd MMM yyyy HH:mm}") %></span>
                        </div>
                        <div>
                            <span class='<%# GetStatusBadgeClass(Eval("status")) %>'>
                                <%# Eval("status") %>
                            </span>
                        </div>
                    </div>

                    <!-- Order Details & Stepper -->
                    <div class="fk-card-body p-4">
                        <div class="grid-2-col gap-4">
                            <!-- Left: Product & Price -->
                            <div class="flex-gap align-center">
                                <div class="thumb-square-lg bg-light flex-center text-xl">
                                    👕
                                </div>
                                <div>
                                    <h3 class="order-item-title text-base font-bold m-0"><%# Eval("p_name") %></h3>
                                    <span class="text-xs fk-text-muted display-block">Size: <%# Eval("size") %></span>
                                    <span class="text-xs fk-text-muted display-block mb-1">Quantity: <%# Eval("qty") %> unit(s)</span>
                                    <span class="text-base font-bold fk-text-primary">Total: Rs <%# String.Format("{0:N0}", Eval("total_price")) %></span>
                                    <div class="mt-1 text-xs">
                                        <span class="fk-text-muted">Payment:</span> <strong><%# GetPaymentMethodDisplay(Eval("payment_type")) %></strong>
                                        &nbsp;&bull;&nbsp;
                                        <span class="fk-text-muted">Payment Status:</span>
                                        <span class='<%# GetPaymentStatusBadgeClass(Eval("payment_status")) %>'>
                                            <%# Eval("payment_status") %>
                                        </span>
                                    </div>
                                    <span class="text-xs fk-text-muted display-block mt-1">
                                        Deliver to: <%# Eval("address") %>, <%# Eval("city") %> (<%# Eval("pincode") %>)
                                    </span>
                                </div>
                            </div>

                            <!-- Right: Visual Order Progress Tracker Stepper -->
                            <div class="order-stepper-wrap">
                                <h4 class="text-sm mb-2">Order status history</h4>
                                <asp:Repeater ID="rptStatusHistory" runat="server">
                                    <ItemTemplate>
                                        <div class="order-history-item">
                                            <strong><%#: Eval("Status") %></strong>
                                            <span class="fk-text-muted text-xs"><%# Eval("CreatedOn", "{0:dd MMM yyyy HH:mm}") %></span>
                                            <p class="fk-text-muted text-xs m-0"><%#: Eval("Notes") %></p>
                                        </div>
                                    </ItemTemplate>
                                </asp:Repeater>
                                <div class="order-stepper">
                                    <div class='<%# GetStepClass(Eval("status"), 1) %>'>
                                        <div class="step-icon">1</div>
                                        <span class="step-label">Placed</span>
                                    </div>
                                    <div class='<%# GetStepClass(Eval("status"), 2) %>'>
                                        <div class="step-icon">2</div>
                                        <span class="step-label">Confirmed</span>
                                    </div>
                                    <div class='<%# GetStepClass(Eval("status"), 3) %>'>
                                        <div class="step-icon">3</div>
                                        <span class="step-label">Shipped</span>
                                    </div>
                                    <div class='<%# GetStepClass(Eval("status"), 4) %>'>
                                        <div class="step-icon">4</div>
                                        <span class="step-label">Delivered</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Footer Actions -->
                    <div class="fk-card-footer flex-between align-center p-3 border-top bg-light">
                        <div class="text-xs fk-text-muted">
                            Need help with this order? Contact Support
                        </div>
                        <div class="flex-gap">
                            <div>
                                <asp:TextBox ID="txtReturnReason" runat="server" CssClass="fk-input text-sm" MaxLength="1000" placeholder="Return reason" Visible='<%# CanRequestReturn(Eval("status"), Eval("delivered_on"), Eval("return_status")) %>'></asp:TextBox>
                                <asp:LinkButton ID="btnRequestReturn" runat="server" CommandName="RequestReturn" CommandArgument='<%# Eval("order_id") %>' CssClass="fk-btn-sm fk-btn-warning" Visible='<%# CanRequestReturn(Eval("status"), Eval("delivered_on"), Eval("return_status")) %>'>Request return/refund</asp:LinkButton>
                                <span class="text-xs fk-text-muted"><%# If(IsDBNull(Eval("return_status")), "", "Return request: " & Server.HtmlEncode(Convert.ToString(Eval("return_status")))) %></span>
                            </div>
                            <a href='<%# ResolveUrl("~/Customer/invoice.aspx?id=" & Eval("order_id")) %>' class="fk-btn-sm fk-btn-outline" target="_blank">
                                📄 Invoice
                            </a>
                            <asp:LinkButton ID="btnCancelOrder" runat="server" CommandName="CancelOrder" CommandArgument='<%# Eval("order_id") %>' 
                                            CssClass="fk-btn-sm fk-btn-danger" OnClientClick="return confirm('Are you sure you want to cancel this pending order?');"
                                            Visible='<%# Eval("status").ToString().ToLower() = "pending" %>'>
                                ❌ Cancel Order
                            </asp:LinkButton>
                        </div>
                    </div>
                </div>
            </ItemTemplate>
        </asp:Repeater>

        <asp:PlaceHolder ID="phEmptyOrders" runat="server" Visible="false">
            <div class="fk-card p-5 text-center">
                <div class="empty-icon text-xxl mb-2">📦</div>
                <h3>No Orders Found</h3>
                <p class="fk-text-muted">You haven't placed any orders yet.</p>
                <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-primary mt-3">Start Shopping</a>
            </div>
        </asp:PlaceHolder>
    </div>
</asp:Content>
