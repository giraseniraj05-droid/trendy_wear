<%@ Page Title="Return Policy" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-card policy-content-panel"><div class="fk-card-header"><h1 class="fk-card-title">Return and refund policy</h1></div><div class="fk-card-body">
        <p>You may request a return or refund within seven days of the order being marked delivered. Open <strong>My Orders</strong>, enter a short reason, and submit the request for review.</p>
        <p>Each order can have one request. The store team will approve or reject it and email you the decision. Approved requests are marked refunded in your order payment status. Cash refunds may require support to arrange the actual payment.</p>
        <p>Items should be unused and in their original condition. Contact support if an item arrived damaged or incorrect.</p>
        <p><a href="<%= ResolveUrl("~/Customer/MyOrders.aspx") %>" class="fk-link">Go to My Orders</a></p>
    </div></div>
</asp:Content>
