Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports TYBCA_52_PROJECT.Helpers

Public Class SearchSuggestions
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Response.ContentType = "application/json"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim query As String = If(Request.QueryString("q"), "").Trim()
        Dim suggestions As New List(Of String)()
        If query.Length >= 2 AndAlso query.Length <= 80 Then
            Dim results As DataTable = Db.ExecuteQuery("SELECT TOP 8 ProductName FROM addproduct1 WHERE IsActive = 1 AND ProductName LIKE @Query ORDER BY CASE WHEN ProductName LIKE @Prefix THEN 0 ELSE 1 END, ProductName",
                                                       Db.CreateParam("@Query", SqlDbType.NVarChar, "%" & query & "%", 255),
                                                       Db.CreateParam("@Prefix", SqlDbType.NVarChar, query & "%", 255))
            For Each row As DataRow In results.Rows
                suggestions.Add(Convert.ToString(row("ProductName")))
            Next
        End If
        Response.Write(New JavaScriptSerializer().Serialize(suggestions))
        Context.ApplicationInstance.CompleteRequest()
    End Sub
End Class
