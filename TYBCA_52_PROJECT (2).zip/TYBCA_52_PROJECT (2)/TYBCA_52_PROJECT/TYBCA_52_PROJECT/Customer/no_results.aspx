<%@ Page Title="Search Help" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="no_results.aspx.vb" Inherits="TYBCA_52_PROJECT.NoResults" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-card p-5 text-center empty-results-card">
        <div class="empty-icon text-xxl mb-2">🔎</div>
        <h1>No matching products</h1>
        <p class="fk-text-muted">We couldn't find results for <strong><asp:Literal ID="litQuery" runat="server"></asp:Literal></strong>. Try a shorter phrase, a different spelling, or browse a category.</p>
        <div class="flex-gap justify-center mt-3">
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-primary">Browse all products</a>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Men") %>" class="fk-btn fk-btn-outline">Men</a>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Women") %>" class="fk-btn fk-btn-outline">Women</a>
            <a href="<%= ResolveUrl("~/Customer/search_product.aspx?cat=Kids") %>" class="fk-btn fk-btn-outline">Kids</a>
        </div>
    </div>
</asp:Content>
