<%@ Page Title="Shop Clothing Collection" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="search_product.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm7" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="shop-layout shop-glass-layout">
        <!-- Left Filter Panel (Flipkart Style) -->
        <aside class="shop-sidebar shop-filter-sidebar">
            <div class="fk-card">
                <div class="fk-card-header flex-between">
                    <h3 class="fk-card-title">Filters</h3>
                    <asp:LinkButton ID="btnClearFilters" runat="server" CssClass="fk-link text-xs" OnClick="btnClearFilters_Click">Clear All</asp:LinkButton>
                </div>
                <div class="fk-card-body">
                    <!-- Search Box -->
                    <div class="filter-group mb-4">
                        <label class="filter-label">Search Keyword</label>
                        <asp:TextBox ID="txtKeyword" runat="server" CssClass="fk-input text-sm" placeholder="Search clothes..." list="productSuggestions"></asp:TextBox>
                        <datalist id="productSuggestions"></datalist>
                    </div>

                    <!-- Category Filter -->
                    <div class="filter-group mb-4">
                        <label class="filter-label">Category</label>
                        <asp:DropDownList ID="ddlCategoryFilter" runat="server" CssClass="fk-select text-sm" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                            <asp:ListItem Value="">All Categories</asp:ListItem>
                            <asp:ListItem Value="Men">Men's Wear</asp:ListItem>
                            <asp:ListItem Value="Women">Women's Fashion</asp:ListItem>
                            <asp:ListItem Value="Kids">Kids Wear</asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <!-- Price Range -->
                    <div class="filter-group mb-4">
                        <label class="filter-label">Price Range (Rs)</label>
                        <div class="grid-2-col flex-gap-sm">
                            <asp:TextBox ID="txtMinPrice" runat="server" CssClass="fk-input text-sm" placeholder="Min" TextMode="Number"></asp:TextBox>
                            <asp:TextBox ID="txtMaxPrice" runat="server" CssClass="fk-input text-sm" placeholder="Max" TextMode="Number"></asp:TextBox>
                        </div>
                    </div>

                    <!-- Sort By -->
                    <div class="filter-group mb-4">
                        <label class="filter-label">Sort By</label>
                        <asp:DropDownList ID="ddlSort" runat="server" CssClass="fk-select text-sm" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                            <asp:ListItem Value="newest">Newest Arrivals</asp:ListItem>
                            <asp:ListItem Value="price_asc">Price: Low to High</asp:ListItem>
                            <asp:ListItem Value="price_desc">Price: High to Low</asp:ListItem>
                            <asp:ListItem Value="discount">Highest Discount</asp:ListItem>
                            <asp:ListItem Value="rating">Top Rated</asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <asp:Button ID="btnApplyFilters" runat="server" Text="Apply Filters" CssClass="fk-btn fk-btn-primary width-100" OnClick="btnApplyFilters_Click" />
                </div>
            </div>
        </aside>

        <!-- Right Product Catalog Grid -->
        <main class="shop-catalog">
            <div class="fk-card mb-3">
                <div class="fk-card-body p-3 flex-between align-center">
                    <span class="fk-text-muted">Showing results for <strong><asp:Literal ID="litActiveFilterText" runat="server">All Clothing</asp:Literal></strong></span>
                    <span class="fk-text-muted text-sm"><asp:Literal ID="litResultCount" runat="server">0</asp:Literal> Items Found</span>
                </div>
            </div>

            <div class="product-grid">
                <asp:Repeater ID="rptShopProducts" runat="server" OnItemCommand="rptShopProducts_ItemCommand">
                    <ItemTemplate>
                        <div class="fk-product-card">
                            <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>' class="card-img-link">
                                <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("Image"))), "~/Images/default.jpg", "~/Uploads/" & Eval("Image"))) %>' 
                                     alt='<%# Eval("p_name") %>' class="product-img" onerror="this.src='../Images/default.jpg';" />
                                <span class="discount-badge"><%# GetDiscountPercentage(Eval("price"), Eval("OldPrice")) %>% OFF</span>
                            </a>

                            <div class="card-body">
                                <span class="product-cat"><%# Eval("category_name") %></span>
                                <h3 class="product-name">
                                    <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("p_id")) %>'><%# Eval("p_name") %></a>
                                </h3>
                                <div class="text-xs fk-text-muted mb-2">Size: <%# Eval("Size") %></div>

                                <div class="price-row">
                                    <span class="current-price">Rs <%# String.Format("{0:N0}", Eval("price")) %></span>
                                    <span class="old-price">Rs <%# String.Format("{0:N0}", Eval("OldPrice")) %></span>
                                </div>
                                <div class="fk-text-warning text-sm mb-2"><%# GetRatingSummary(Eval("AverageRating"), Eval("ReviewCount")) %></div>

                                <div class="stock-status mb-2">
                                    <span class='<%# GetStockClass(Eval("Stock")) %>'>
                                        <%# GetStockText(Eval("Stock")) %>
                                    </span>
                                </div>

                                <div class="card-actions">
                                    <asp:LinkButton ID="btnAddToCart" runat="server" CommandName="AddToCart" CommandArgument='<%# Eval("p_id") %>' Enabled='<%# Convert.ToInt32(Eval("Stock")) > 0 %>' CssClass="fk-btn fk-btn-cart flex-1">
                                        🛒 Add
                                    </asp:LinkButton>
                                    <asp:LinkButton ID="btnBuyNow" runat="server" CommandName="BuyNow" CommandArgument='<%# Eval("p_id") %>' Enabled='<%# Convert.ToInt32(Eval("Stock")) > 0 %>' CssClass="fk-btn fk-btn-buy flex-1">
                                        ⚡ Buy Now
                                    </asp:LinkButton>
                                </div>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>

            <div class="flex-between align-center mt-3 mb-3">
                <asp:Button ID="btnPrevious" runat="server" Text="Previous" CssClass="fk-btn-sm fk-btn-outline" OnClick="btnPrevious_Click" />
                <asp:Literal ID="litPageInfo" runat="server"></asp:Literal>
                <asp:Button ID="btnNext" runat="server" Text="Next" CssClass="fk-btn-sm fk-btn-outline" OnClick="btnNext_Click" />
            </div>

            <asp:PlaceHolder ID="phEmptyShop" runat="server" Visible="false">
                <div class="fk-card p-5 text-center empty-results-card">
                    <div class="empty-icon text-xxl mb-2">🔍</div>
                    <h3>No Clothes Found</h3>
                    <p class="fk-text-muted">We couldn't find any products matching your search criteria. Try adjusting filters.</p>
                    <a href="<%= ResolveUrl("~/Customer/no_results.aspx") %>?q=<%= Server.UrlEncode(txtKeyword.Text) %>" class="fk-link">Search tips and popular categories</a>
                </div>
            </asp:PlaceHolder>
        </main>
    </div>
    <script>
        (function () {
            var box = document.getElementById('<%= txtKeyword.ClientID %>');
            var list = document.getElementById('productSuggestions');
            if (!box || !list) return;
            var timer;
            box.addEventListener('input', function () {
                window.clearTimeout(timer);
                var query = box.value.trim();
                if (query.length < 2) { list.innerHTML = ''; return; }
                timer = window.setTimeout(function () {
                    var request = new XMLHttpRequest();
                    request.open('GET', '<%= ResolveUrl("~/Customer/search_suggestions.aspx") %>?q=' + encodeURIComponent(query), true);
                    request.onreadystatechange = function () {
                        if (request.readyState !== 4 || request.status !== 200) return;
                        try {
                            var suggestions = JSON.parse(request.responseText);
                            list.innerHTML = '';
                            suggestions.forEach(function (value) {
                                var option = document.createElement('option');
                                option.value = value;
                                list.appendChild(option);
                            });
                        } catch (e) { list.innerHTML = ''; }
                    };
                    request.send();
                }, 180);
            });
        }());
    </script>
</asp:Content>
