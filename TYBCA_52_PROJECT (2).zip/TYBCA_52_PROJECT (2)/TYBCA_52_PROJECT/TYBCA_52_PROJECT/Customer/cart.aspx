<%@ Page Title="Shopping Cart" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" CodeBehind="cart.aspx.vb" Inherits="TYBCA_52_PROJECT.CustomerCart" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="cart-layout cart-glass-layout">
        <!-- Left: Cart Items -->
        <div class="cart-items-section">
            <div class="fk-card mb-4 cart-items-card">
                <div class="fk-card-header flex-between align-center">
                    <h3 class="fk-card-title m-0">My Shopping Cart (<asp:Literal ID="litCartCount" runat="server">0</asp:Literal>)</h3>
                    <span class="text-xs fk-text-muted">Deliver to: <strong>India</strong></span>
                </div>
                <div class="fk-card-body p-0">
                    <asp:Repeater ID="rptCart" runat="server" OnItemCommand="rptCart_ItemCommand">
                        <ItemTemplate>
                            <div class="cart-item-row p-3">
                                <div class="cart-item-img-wrap">
                                    <img loading="lazy" decoding="async" src='<%# ResolveUrl(If(String.IsNullOrEmpty(Convert.ToString(Eval("ProductImage"))), "~/Images/default.jpg", "~/Uploads/" & Eval("ProductImage"))) %>' 
                                         alt='<%# Eval("ProductName") %>' class="cart-item-img" onerror="this.src='../Images/default.jpg';" />
                                </div>
                                <div class="cart-item-info flex-1">
                                    <h4 class="cart-item-title m-0">
                                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("ProductID")) %>'><%# Eval("ProductName") %></a>
                                    </h4>
                                    <span class="cart-item-cat text-xs fk-text-muted display-block mb-1"><%# Eval("Category") %></span>
                                    <span class="text-xs fk-text-muted display-block mb-1">Size: <%# Eval("Size") %></span>

                                    <div class="price-row mb-2">
                                        <span class="current-price text-lg font-bold">Rs <%# String.Format("{0:N0}", Eval("Price")) %></span>
                                        <span class="old-price text-sm text-mrp ml-2">Rs <%# String.Format("{0:N0}", Convert.ToDecimal(Eval("Price")) * 1.3) %></span>
                                        <span class="fk-text-success text-xs font-bold ml-2">23% OFF</span>
                                    </div>

                                    <div class="cart-qty-row flex-gap align-center">
                                        <asp:LinkButton ID="btnDec" runat="server" CommandName="UpdateQty" CommandArgument='<%# Eval("ProductID") & "|-1" %>' CssClass="qty-btn">-</asp:LinkButton>
                                        <span class="qty-val font-bold"><%# Eval("Quantity") %></span>
                                        <asp:LinkButton ID="btnInc" runat="server" CommandName="UpdateQty" CommandArgument='<%# Eval("ProductID") & "|1" %>' CssClass="qty-btn">+</asp:LinkButton>

                                        <asp:LinkButton ID="btnRemove" runat="server" CommandName="RemoveItem" CommandArgument='<%# Eval("ProductID") %>' CssClass="fk-btn-sm fk-btn-danger ml-3">
                                            REMOVE
                                        </asp:LinkButton>
                                    </div>
                                </div>
                            </div>
                        </ItemTemplate>
                    </asp:Repeater>

                    <asp:PlaceHolder ID="phEmptyCart" runat="server" Visible="false">
                        <div class="p-5 text-center">
                            <div class="empty-icon text-xxl mb-2">🛒</div>
                            <h3>Your Cart is Empty!</h3>
                            <p class="fk-text-muted">Explore our latest fashion collections and add items to your cart.</p>
                            <a href="<%= ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-primary mt-3">Shop Now</a>
                        </div>
                    </asp:PlaceHolder>
                </div>
            </div>
        </div>

        <!-- Right: Flipkart Style PRICE DETAILS Box -->
        <div class="cart-summary-section">
            <div class="fk-card cart-summary-card">
                <div class="fk-card-header">
                    <h3 class="fk-card-title text-muted uppercase text-xs font-bold m-0">PRICE DETAILS</h3>
                </div>
                <div class="fk-card-body p-3">
                    <div class="mb-3 cart-coupon-row">
                        <label class="form-label" for="couponCode">Coupon code</label>
                        <div class="flex-gap">
                            <asp:TextBox ID="txtCouponCode" runat="server" CssClass="fk-input" MaxLength="50" placeholder="Enter coupon code"></asp:TextBox>
                            <asp:Button ID="btnApplyCoupon" runat="server" Text="Apply" CssClass="fk-btn-sm fk-btn-outline" OnClick="btnApplyCoupon_Click" />
                        </div>
                        <asp:Label ID="lblCouponMessage" runat="server" CssClass="text-xs display-block mt-1"></asp:Label>
                        <asp:Button ID="btnRemoveCoupon" runat="server" Text="Remove coupon" CssClass="fk-link text-xs" OnClick="btnRemoveCoupon_Click" Visible="false" />
                    </div>
                    <div class="flex-between py-2 border-bottom">
                        <span>Price (<asp:Literal ID="litItemCount" runat="server">0</asp:Literal> items)</span>
                        <span>Rs <asp:Literal ID="litSubtotal" runat="server">0</asp:Literal></span>
                    </div>

                    <div class="flex-between py-2 border-bottom">
                        <span>Discount</span>
                        <span class="fk-text-success">- Rs <asp:Literal ID="litDiscount" runat="server">0</asp:Literal></span>
                    </div>
                    <div class="flex-between py-2 border-bottom">
                        <span>Coupon discount <asp:Literal ID="litCouponCode" runat="server"></asp:Literal></span>
                        <span class="fk-text-success">- Rs <asp:Literal ID="litCouponDiscount" runat="server">0</asp:Literal></span>
                    </div>

                    <div class="flex-between py-2 border-bottom">
                        <span>Delivery Charges</span>
                        <span>
                            <asp:Literal ID="litDeliveryFee" runat="server"><span class="fk-text-success">FREE</span></asp:Literal>
                        </span>
                    </div>

                    <div class="flex-between py-3 border-bottom font-bold text-lg">
                        <span>Total Amount</span>
                        <span class="fk-text-primary">Rs <asp:Literal ID="litGrandTotal" runat="server">0</asp:Literal></span>
                    </div>

                    <div class="py-2 mb-3">
                        <span class="fk-badge-green display-block p-2 text-center text-xs font-bold">
                            🎉 You will save Rs <asp:Literal ID="litSavedAmount" runat="server">0</asp:Literal> on this order!
                        </span>
                    </div>

                    <asp:Button ID="btnProceedCheckout" runat="server" Text="PLACE ORDER &rarr;" CssClass="fk-btn fk-btn-buy width-100 p-3 text-lg font-bold" OnClick="btnProceedCheckout_Click" />
                </div>
            </div>
        </div>
    </div>
</asp:Content>
