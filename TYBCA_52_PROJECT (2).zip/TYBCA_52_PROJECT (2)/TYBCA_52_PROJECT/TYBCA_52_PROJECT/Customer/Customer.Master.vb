Imports System

Public Class Customer
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Shared TopBar user control automatically manages user session greeting & cart badge
    End Sub
End Class