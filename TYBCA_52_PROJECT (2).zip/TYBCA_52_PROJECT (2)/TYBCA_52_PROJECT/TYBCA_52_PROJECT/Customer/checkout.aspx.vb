Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Models
Imports TYBCA_52_PROJECT.Services

Public Class checkout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
            Return
        End If

        If Not IsEmailVerified(userId) Then
            Session("EmailVerificationUserID") = userId
            Response.Redirect("~/verify_email.aspx")
            Return
        End If

        If Not IsPostBack Then
            LoadUserData(userId)
            LoadSavedAddresses(userId)
            BindOrderSummary()

            Dim upiItem As ListItem = rblPayment.Items.FindByValue("UPI")
            If upiItem IsNot Nothing Then
                upiItem.Enabled = False
                upiItem.Attributes.Add("disabled", "disabled")
            End If
        End If
    End Sub

    Private Sub LoadUserData(ByVal userId As Integer)
        Try
            Dim dt As DataTable = Db.ExecuteQuery("SELECT Username, FullName, Email, Mobileno, Address, City, Pincode FROM register WHERE UserID = @id", New SqlParameter("@id", userId))
            If dt.Rows.Count > 0 Then
                Dim row As DataRow = dt.Rows(0)
                txtFullName.Text = If(IsDBNull(row("FullName")) OrElse String.IsNullOrEmpty(row("FullName").ToString()), row("Username").ToString(), row("FullName").ToString())
                txtMobile.Text = If(IsDBNull(row("Mobileno")), "", row("Mobileno").ToString())
                txtAddress.Text = If(IsDBNull(row("Address")), "", row("Address").ToString())
                txtCity.Text = If(IsDBNull(row("City")), "", row("City").ToString())
                txtPincode.Text = If(IsDBNull(row("Pincode")), "", row("Pincode").ToString())
            End If
        Catch ex As Exception
            Logger.LogError("Error loading user checkout details", ex)
        End Try
    End Sub

    Private Sub LoadSavedAddresses(ByVal userId As Integer)
        Dim addresses As DataTable = Db.ExecuteQuery("SELECT AddressID, FullName, Mobile, AddressLine, City, Pincode, IsDefault FROM CustomerAddresses WHERE UserID = @UserID ORDER BY IsDefault DESC, AddressID DESC",
                                                    Db.CreateParam("@UserID", SqlDbType.Int, userId))
        ddlSavedAddress.Items.Clear()
        ddlSavedAddress.Items.Add(New ListItem("-- Enter address manually --", ""))
        For Each row As DataRow In addresses.Rows
            Dim label As String = Convert.ToString(row("FullName")) & " — " & Convert.ToString(row("AddressLine")) & ", " & Convert.ToString(row("City"))
            Dim optionItem As New ListItem(label, Convert.ToString(row("AddressID")))
            ddlSavedAddress.Items.Add(optionItem)
            If Convert.ToBoolean(row("IsDefault")) Then ddlSavedAddress.SelectedValue = optionItem.Value
        Next
        If Not String.IsNullOrEmpty(ddlSavedAddress.SelectedValue) Then ApplySavedAddress(userId, Convert.ToInt32(ddlSavedAddress.SelectedValue))
    End Sub

    Protected Sub ddlSavedAddress_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim addressId As Integer
        Dim userId As Integer
        If Integer.TryParse(Convert.ToString(Session("UserID")), userId) AndAlso
           Integer.TryParse(ddlSavedAddress.SelectedValue, addressId) Then ApplySavedAddress(userId, addressId)
    End Sub

    Private Sub ApplySavedAddress(ByVal userId As Integer, ByVal addressId As Integer)
        Dim address As DataTable = Db.ExecuteQuery("SELECT FullName, Mobile, AddressLine, City, Pincode FROM CustomerAddresses WHERE AddressID = @AddressID AND UserID = @UserID",
                                                   Db.CreateParam("@AddressID", SqlDbType.Int, addressId),
                                                   Db.CreateParam("@UserID", SqlDbType.Int, userId))
        If address.Rows.Count = 0 Then Return
        Dim row As DataRow = address.Rows(0)
        txtFullName.Text = Convert.ToString(row("FullName"))
        txtMobile.Text = Convert.ToString(row("Mobile"))
        txtAddress.Text = Convert.ToString(row("AddressLine"))
        txtCity.Text = Convert.ToString(row("City"))
        txtPincode.Text = Convert.ToString(row("Pincode"))
    End Sub

    Private Sub BindOrderSummary()
        Dim items As List(Of CartItem) = CartService.GetCart(Context)
        If items.Count = 0 Then
            Response.Redirect("~/Customer/search_product.aspx")
            Return
        End If

        rptSummary.DataSource = items
        rptSummary.DataBind()

        Dim subtotal As Decimal = 0
        Dim count As Integer = 0
        For Each item In items
            count += item.Quantity
            subtotal += (item.Price * item.Quantity)
        Next

        litSummaryCount.Text = count.ToString()
        litSubtotal.Text = String.Format("{0:N0}", subtotal)
        Dim couponDiscount As Decimal = CouponService.AppliedDiscount(Context, subtotal)
        litCouponDiscount.Text = String.Format("{0:N0}", couponDiscount)
        Dim couponCode As String = CouponService.AppliedCode(Context)
        litCouponCode.Text = If(String.IsNullOrEmpty(couponCode), "", "(" & HttpUtility.HtmlEncode(couponCode) & ")")
        litGrandTotal.Text = String.Format("{0:N0}", Math.Max(0D, subtotal - couponDiscount))
    End Sub

    Protected Sub btnPlaceOrder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPlaceOrder.Click
        If Not Page.IsValid Then Return

        Dim userId As Integer
        Dim items As List(Of CartItem) = CartService.GetCart(Context)

        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
            Return
        End If

        If Not IsEmailVerified(userId) Then
            Session("EmailVerificationUserID") = userId
            Response.Redirect("~/verify_email.aspx")
            Return
        End If

        If items.Count = 0 Then
            Toast.Show(Me, "Your cart is empty!", Toast.ToastType.Warning)
            Return
        End If

        ' Server-side payment validation: Reject UPI or unavailable/unsupported methods
        Dim selectedPayment As String = rblPayment.SelectedValue
        If String.IsNullOrEmpty(selectedPayment) OrElse
           selectedPayment.Equals(PaymentMethodNames.UPI, StringComparison.OrdinalIgnoreCase) OrElse
           Not PaymentService.IsMethodAvailable(selectedPayment) Then
            Toast.Show(Me, "UPI payment is coming soon and currently unavailable. Please select Cash on Delivery.", Toast.ToastType.Warning)
            Return
        End If

        If Not selectedPayment.Equals(PaymentMethodNames.COD, StringComparison.OrdinalIgnoreCase) Then
            Toast.Show(Me, "Selected payment method is invalid.", Toast.ToastType.Error)
            Return
        End If

        Dim initialPaymentStatus As String = PaymentStatusNames.Pending

        Try
            Dim totalAmount As Decimal = 0D
            Dim orderId As Integer
            For Each item In items
                totalAmount += item.Price * item.Quantity
            Next
            Dim couponCode As String = CouponService.AppliedCode(Context)
            Dim couponDiscount As Decimal = 0D
            If Not String.IsNullOrWhiteSpace(couponCode) Then
                Dim couponMessage As String = ""
                If Not CouponService.TryCalculate(couponCode, totalAmount, couponDiscount, couponMessage) Then
                    Session.Remove("AppliedCouponCode")
                    Session.Remove("AppliedCouponDiscount")
                    Toast.Show(Me, "The applied coupon is no longer valid. Please review your cart.", Toast.ToastType.Warning)
                    Return
                End If
            End If
            totalAmount = Math.Max(0D, totalAmount - couponDiscount)

            Using conn As SqlConnection = Db.GetConnection()
                Using transaction As SqlTransaction = conn.BeginTransaction()
                    Try
                        If Not String.IsNullOrWhiteSpace(couponCode) Then
                            Using couponCommand As New SqlCommand("UPDATE Coupons SET TimesUsed = TimesUsed + 1 WHERE UPPER(CouponCode) = @CouponCode AND IsActive = 1 AND ExpiryDate >= GETDATE() AND TimesUsed < UsageLimit", conn, transaction)
                                couponCommand.Parameters.AddWithValue("@CouponCode", couponCode)
                                If couponCommand.ExecuteNonQuery() <> 1 Then Throw New InvalidOperationException("The coupon is no longer available.")
                            End Using
                        End If
                        Dim insertOrder As String = "INSERT INTO orders (UserID, ShippingAddress, City, Pincode, PaymentType, Status, TotalAmount, PaymentStatus, DiscountAmount, CouponCode) " & _
                                                    "VALUES (@UserID, @Address, @City, @Pincode, @PaymentType, 'Pending', @TotalAmount, @PaymentStatus, @DiscountAmount, @CouponCode); SELECT CAST(SCOPE_IDENTITY() AS INT)"
                        Using cmd As New SqlCommand(insertOrder, conn, transaction)
                            cmd.Parameters.AddWithValue("@UserID", userId)
                            cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim())
                            cmd.Parameters.AddWithValue("@City", txtCity.Text.Trim())
                            cmd.Parameters.AddWithValue("@Pincode", txtPincode.Text.Trim())
                            cmd.Parameters.AddWithValue("@PaymentType", selectedPayment)
                            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount)
                            cmd.Parameters.AddWithValue("@PaymentStatus", initialPaymentStatus)
                            cmd.Parameters.AddWithValue("@DiscountAmount", couponDiscount)
                            cmd.Parameters.AddWithValue("@CouponCode", If(String.IsNullOrWhiteSpace(couponCode), CType(DBNull.Value, Object), couponCode))
                            orderId = Convert.ToInt32(cmd.ExecuteScalar())
                        End Using

                        Using historyCmd As New SqlCommand("INSERT INTO OrderStatusHistory (OrderID, Status, Notes, UpdatedBy) VALUES (@OrderID, 'Pending', 'Order placed', @UserID)", conn, transaction)
                            historyCmd.Parameters.AddWithValue("@OrderID", orderId)
                            historyCmd.Parameters.AddWithValue("@UserID", userId)
                            historyCmd.ExecuteNonQuery()
                        End Using

                        For Each item In items
                            Using stockCmd As New SqlCommand("UPDATE addproduct1 SET Stock = Stock - @Quantity WHERE ProductID = @ProductID AND IsActive = 1 AND Stock >= @Quantity", conn, transaction)
                                stockCmd.Parameters.AddWithValue("@Quantity", item.Quantity)
                                stockCmd.Parameters.AddWithValue("@ProductID", item.ProductID)
                                If stockCmd.ExecuteNonQuery() <> 1 Then
                                    Throw New InvalidOperationException("Insufficient stock for " & item.ProductName)
                                End If
                            End Using

                            Using detailCmd As New SqlCommand("INSERT INTO order_details (OrderID, ProductID, Quantity, Price, TotalPrice) VALUES (@OrderID, @ProductID, @Quantity, @Price, @TotalPrice)", conn, transaction)
                                detailCmd.Parameters.AddWithValue("@OrderID", orderId)
                                detailCmd.Parameters.AddWithValue("@ProductID", item.ProductID)
                                detailCmd.Parameters.AddWithValue("@Quantity", item.Quantity)
                                detailCmd.Parameters.AddWithValue("@Price", item.Price)
                                detailCmd.Parameters.AddWithValue("@TotalPrice", item.Price * item.Quantity)
                                detailCmd.ExecuteNonQuery()
                            End Using
                        Next

                        Using profileCmd As New SqlCommand("UPDATE register SET FullName = @FullName, Mobileno = @Mobile, Address = @Address, City = @City, Pincode = @Pincode WHERE UserID = @UserID", conn, transaction)
                            profileCmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim())
                            profileCmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim())
                            profileCmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim())
                            profileCmd.Parameters.AddWithValue("@City", txtCity.Text.Trim())
                            profileCmd.Parameters.AddWithValue("@Pincode", txtPincode.Text.Trim())
                            profileCmd.Parameters.AddWithValue("@UserID", userId)
                            profileCmd.ExecuteNonQuery()
                        End Using

                        transaction.Commit()
                    Catch
                        transaction.Rollback()
                        Throw
                    End Try
                End Using
            End Using

            Try
                Dim customer As DataTable = Db.ExecuteQuery("SELECT Username, FullName, Email FROM register WHERE UserID = @UserID",
                                                            Db.CreateParam("@UserID", SqlDbType.Int, userId))
                Dim orderFinancials As DataTable = Db.ExecuteQuery("SELECT ISNULL(DiscountAmount, 0) AS DiscountAmount, ISNULL(TotalAmount, 0) AS TotalAmount FROM orders WHERE OrderID = @OrderID",
                                                                    Db.CreateParam("@OrderID", SqlDbType.Int, orderId))
                Dim discountAmount As Decimal = If(orderFinancials.Rows.Count > 0, Convert.ToDecimal(orderFinancials.Rows(0)("DiscountAmount")), 0D)
                Dim finalTotal As Decimal = If(orderFinancials.Rows.Count > 0, Convert.ToDecimal(orderFinancials.Rows(0)("TotalAmount")), totalAmount)
                Dim customerName As String = If(customer.Rows.Count > 0,
                                                If(IsDBNull(customer.Rows(0)("FullName")), Convert.ToString(customer.Rows(0)("Username")), Convert.ToString(customer.Rows(0)("FullName"))),
                                                "")
                Dim safeAddress As String = HttpUtility.HtmlEncode(txtAddress.Text.Trim() & ", " & txtCity.Text.Trim() & " " & txtPincode.Text.Trim())
                Dim itemsHtml As New System.Text.StringBuilder()
                itemsHtml.Append("<table style='width:100%;border-collapse:collapse;'><tr><th align='left'>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>")
                For Each item In items
                    itemsHtml.Append("<tr><td>" & HttpUtility.HtmlEncode(item.ProductName) & "</td><td align='center'>" & item.Quantity.ToString() & "</td><td align='right'>Rs " & item.Price.ToString("N2") & "</td><td align='right'>Rs " & (item.Price * item.Quantity).ToString("N2") & "</td></tr>")
                Next
                itemsHtml.Append("</table><p>Discount: Rs " & discountAmount.ToString("N2") & "</p><p><strong>Total: Rs " & finalTotal.ToString("N2") & "</strong></p>")
                itemsHtml.Append("<p><strong>Payment Method:</strong> " & HttpUtility.HtmlEncode(PaymentService.GetPaymentMethodDisplay(selectedPayment)) & "</p>")
                itemsHtml.Append("<p><strong>Payment Status:</strong> " & HttpUtility.HtmlEncode(initialPaymentStatus) & "</p>")
                itemsHtml.Append("<p><strong>Shipping address:</strong> " & safeAddress & "</p>")
                If customer.Rows.Count > 0 Then
                    Mailer.SendAsync(Convert.ToString(customer.Rows(0)("Email")), "Order confirmation #" & orderId,
                                     Mailer.Wrap("Thank you for your order",
                                                 "<p>Hello " & HttpUtility.HtmlEncode(customerName) & ", your order #" & orderId.ToString() & " has been placed.</p>" & itemsHtml.ToString()),
                                     "OrderPlacedCustomer")
                End If
            Catch notificationEx As Exception
                Logger.LogError("Error preparing notifications for order " & orderId, notificationEx)
            End Try

            CartService.ClearCart(Context)
            Session.Remove("AppliedCouponCode")
            Session.Remove("AppliedCouponDiscount")
            Toast.Show(Me, "Order placed successfully!", Toast.ToastType.Success)
            Response.Redirect("~/Customer/order_thankyou.aspx?oid=" & orderId.ToString())

        Catch ex As Exception
            Logger.LogError("Error placing order", ex)
            Toast.Show(Me, "Unable to place the order. Please check your details and available stock, then try again.", Toast.ToastType.Error)
        End Try
    End Sub

    Private Function IsEmailVerified(ByVal userId As Integer) As Boolean
        Dim value As Object = Db.ExecuteScalar("SELECT EmailVerified FROM register WHERE UserID = @UserID",
                                               Db.CreateParam("@UserID", SqlDbType.Int, userId))
        Return value IsNot Nothing AndAlso Not IsDBNull(value) AndAlso Convert.ToBoolean(value)
    End Function
End Class
