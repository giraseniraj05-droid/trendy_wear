Imports System

Public Class NoResults
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then litQuery.Text = Server.HtmlEncode(If(Request.QueryString("q"), "").Trim())
    End Sub
End Class
