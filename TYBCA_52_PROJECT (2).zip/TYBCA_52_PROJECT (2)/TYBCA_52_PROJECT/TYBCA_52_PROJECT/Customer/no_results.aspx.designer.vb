Option Strict On
Option Explicit On

Partial Public Class NoResults
    Protected WithEvents litQuery As Global.System.Web.UI.WebControls.Literal
End Class
