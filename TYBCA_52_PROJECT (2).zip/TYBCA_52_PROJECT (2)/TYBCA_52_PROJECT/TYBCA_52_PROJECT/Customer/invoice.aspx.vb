Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class invoice
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If

        If Not IsPostBack Then
            Dim orderIdStr As String = Request.QueryString("id")
            Dim orderId As Integer
            If Not Integer.TryParse(orderIdStr, orderId) OrElse orderId <= 0 Then
                Response.Redirect("~/Customer/MyOrders.aspx", False)
                Return
            End If

            LoadInvoice(orderId)
        End If
    End Sub

    Private Sub LoadInvoice(ByVal orderID As Integer)
        Try
            Dim isAdmin As Boolean = String.Equals(Convert.ToString(Session("role")), "Admin", StringComparison.OrdinalIgnoreCase)
            Dim dtOrder As DataTable = Db.GetDataTable("SELECT o.*, r.Username, r.FullName FROM orders o INNER JOIN register r ON o.UserID = r.UserID " & _
                                                       "WHERE o.OrderID = @OrderID AND (@IsAdmin = 1 OR o.UserID = @UserID)",
                                                       New SqlParameter() {Db.CreateParam("@OrderID", SqlDbType.Int, orderID), _
                                                                           Db.CreateParam("@IsAdmin", SqlDbType.Bit, isAdmin), _
                                                                           Db.CreateParam("@UserID", SqlDbType.Int, Convert.ToInt32(Session("UserID")))})

            If dtOrder.Rows.Count = 0 Then
                Response.Redirect("~/Customer/MyOrders.aspx", False)
                Context.ApplicationInstance.CompleteRequest()
                Return
            Else
                Dim row As DataRow = dtOrder.Rows(0)
                litOrderID.Text = orderID.ToString()
                litDate.Text = Convert.ToDateTime(row("OrderDate")).ToString("dd-MMM-yyyy HH:mm")
                litCustomerName.Text = Server.HtmlEncode(If(Not IsDBNull(row("FullName")) AndAlso Not String.IsNullOrEmpty(row("FullName").ToString()), row("FullName").ToString(), row("Username").ToString()))
                litAddress.Text = Server.HtmlEncode(row("ShippingAddress").ToString())
                litCity.Text = Server.HtmlEncode(row("City").ToString())
                litPincode.Text = Server.HtmlEncode(row("Pincode").ToString())
                litPaymentType.Text = Server.HtmlEncode(PaymentService.GetPaymentMethodDisplay(If(Not IsDBNull(row("PaymentType")), row("PaymentType").ToString(), "COD")))
                litPaymentStatus.Text = Server.HtmlEncode(PaymentStatusNames.Normalize(If(Not IsDBNull(row("PaymentStatus")), row("PaymentStatus").ToString(), "Pending")))
                litTotal.Text = If(Not IsDBNull(row("TotalAmount")), Convert.ToDecimal(row("TotalAmount")).ToString("N2"), "0.00")
                litCouponCode.Text = If(IsDBNull(row("CouponCode")), "None", Server.HtmlEncode(Convert.ToString(row("CouponCode"))))
                litCouponDiscount.Text = If(IsDBNull(row("DiscountAmount")), "0.00", Convert.ToDecimal(row("DiscountAmount")).ToString("N2"))

                ' Items
                Dim dtItems As DataTable = Db.GetDataTable("SELECT od.*, p.ProductName, p.Size FROM order_details od INNER JOIN addproduct1 p ON od.ProductID = p.ProductID WHERE od.OrderID = @OrderID",
                                                           New SqlParameter() {Db.CreateParam("@OrderID", SqlDbType.Int, orderID)})
                rptInvoiceItems.DataSource = dtItems
                rptInvoiceItems.DataBind()
            End If
        Catch ex As Exception
            Logger.LogException(ex, "LoadInvoice error for OrderID: " & orderID)
        End Try
    End Sub
End Class
