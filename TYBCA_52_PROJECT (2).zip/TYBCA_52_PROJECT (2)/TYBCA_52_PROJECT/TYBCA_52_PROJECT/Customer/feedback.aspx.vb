Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Partial Class WebForm6
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If
    End Sub

    Protected Sub btnSubmitFeedback_Click(ByVal sender As Object, ByVal e As EventArgs)
        If Not Page.IsValid Then Return

        Dim userID As Integer
        Dim rating As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userID) OrElse userID <= 0 Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If
        If Not Integer.TryParse(ddlRating.SelectedValue, rating) OrElse rating < 1 OrElse rating > 5 Then
            Toast.ShowMessage(Me, "Please select a rating.", ToastType.Warning)
            Return
        End If

        Dim feedbackType As String = ddlFeedbackType.SelectedValue
        Dim comments As String = txtComments.Text.Trim()
        Dim recommend As Boolean = chkRecommend.Checked

        Try
            Dim query As String = "INSERT INTO feedback (UserID, Rating, FeedbackType, Comments, Recommend, DateSubmitted) " &
                                  "VALUES (@UserID, @Rating, @FeedbackType, @Comments, @Recommend, GETDATE())"

            Dim generalCommentParam As New SqlParameter("@Comments", SqlDbType.NVarChar, -1)
            generalCommentParam.Value = comments
            Dim params As SqlParameter() = New SqlParameter() {
                Db.CreateParam("@UserID", SqlDbType.Int, userID),
                Db.CreateParam("@Rating", SqlDbType.Int, rating),
                Db.CreateParam("@FeedbackType", SqlDbType.NVarChar, feedbackType, 50),
                generalCommentParam,
                Db.CreateParam("@Recommend", SqlDbType.Bit, recommend)
            }

            Db.ExecuteNonQuery(query, params)
            Try
                Dim email As Object = Db.ExecuteScalar("SELECT Email FROM register WHERE UserID = @UserID",
                                                       Db.CreateParam("@UserID", SqlDbType.Int, userID))
                If email IsNot Nothing AndAlso email IsNot DBNull.Value Then
                    Mailer.SendAsync(Convert.ToString(email), "Thanks for your feedback",
                                     Mailer.Wrap("Thanks for your feedback",
                                                 "<p>Thank you for sharing your feedback with Trendy Wear. We appreciate your time.</p>"),
                                     "GeneralFeedback")
                End If
            Catch notificationEx As Exception
                Logger.LogError("Error preparing general feedback thank-you email for UserID " & userID, notificationEx)
            End Try

            Toast.ShowMessage(Me, "Feedback submitted successfully!", ToastType.Success)
            ddlRating.SelectedIndex = 0
            ddlFeedbackType.SelectedIndex = 0
            txtComments.Text = ""
            chkRecommend.Checked = True
        Catch ex As Exception
            Logger.LogException(ex, "Error submitting feedback for UserID: " & userID)
            Toast.ShowMessage(Me, "An error occurred submitting feedback.", ToastType.Error)
        End Try
    End Sub
End Class
