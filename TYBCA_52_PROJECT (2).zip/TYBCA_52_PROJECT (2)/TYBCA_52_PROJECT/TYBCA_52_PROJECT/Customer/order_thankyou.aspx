<%@ Page Title="Order Confirmed – Rate Your Purchase" Language="VB" MasterPageFile="~/Customer/Customer.Master"
    AutoEventWireup="false" CodeBehind="order_thankyou.aspx.vb" Inherits="TYBCA_52_PROJECT.OrderThankyou" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-container thankyou-container">

        <%-- Thank you banner --%>
        <div class="thankyou-hero">
            <div class="tick">✅</div>
            <h1>Order Placed Successfully!</h1>
            <p class="fk-text-muted">
                Order #<strong><asp:Literal ID="litOrderID" runat="server"></asp:Literal></strong> —
                we'll deliver it soon. Please rate the products you just ordered.
            </p>
            <a href="<%=ResolveUrl("~/Customer/MyOrders.aspx") %>" class="fk-btn fk-btn-outline-primary mt-2">View My Orders</a>
        </div>

        <%-- Toast message area --%>
        <asp:Label ID="lblMsg" runat="server" CssClass="display-block mb-3"></asp:Label>

        <%-- One card per ordered product --%>
        <asp:Repeater ID="rptOrderProducts" runat="server">
            <ItemTemplate>
                <div class="product-review-card">
                    <div class="flex-gap align-center mb-3">
                        <img loading="lazy" decoding="async" src='<%# GetProductImageUrl(Eval("Image")) %>'
                             alt='<%# HttpUtility.HtmlAttributeEncode(Convert.ToString(Eval("ProductName"))) %>'
                             class="thankyou-product-image" onerror="this.onerror=null;this.src='../Images/default.jpg';" />
                        <div>
                            <h3 class="m-0"><%#: Eval("ProductName") %></h3>
                            <span class="fk-text-muted text-xs">Qty: <%# Eval("Quantity") %> &nbsp;|&nbsp; Rs <%# String.Format("{0:N0}", Eval("TotalPrice")) %></span>
                        </div>
                    </div>

                    <%-- If already reviewed --%>
                    <asp:Panel ID="pnlAlreadyReviewed" runat="server"
                               Visible='<%# Convert.ToBoolean(Eval("AlreadyReviewed")) %>'
                               CssClass="already-reviewed">
                        ✔ You've already submitted a review for this product.
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("ProductID").ToString()) %>'>View product</a>
                    </asp:Panel>

                    <%-- Review form --%>
                    <asp:Panel ID="pnlReviewForm" runat="server"
                               Visible='<%# Not Convert.ToBoolean(Eval("AlreadyReviewed")) %>'>
                        <fieldset class="mb-3 thankyou-rating-fieldset">
                            <legend class="form-label font-bold">Your Rating <span class="fk-text-danger">*</span></legend>
                            <div class="review-stars-input" role="radiogroup">
                                <%# GetStarRadios(Eval("ProductID")) %>
                            </div>
                        </fieldset>
                        <div class="form-group mb-2">
                            <asp:TextBox ID="txtTitle" runat="server" CssClass="fk-input" MaxLength="150"
                                         placeholder="Review title (optional)"></asp:TextBox>
                        </div>
                        <div class="form-group mb-3">
                            <asp:TextBox ID="txtComment" runat="server" CssClass="fk-input" TextMode="MultiLine"
                                         Rows="3" placeholder="Share your experience with this product..."></asp:TextBox>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label text-sm">Photo (optional, JPG/PNG, max 2 MB)</label>
                            <asp:FileUpload ID="fuPhoto" runat="server" CssClass="fk-input" accept=".jpg,.jpeg,.png" />
                        </div>
                        <asp:LinkButton ID="btnSubmit" runat="server"
                                        CommandName="SubmitReview"
                                        CommandArgument='<%# Eval("ProductID") %>'
                                        CssClass="fk-btn fk-btn-primary"
                                        CausesValidation="false"
                                        OnCommand="rptOrderProducts_ItemCommand">
                            Submit Review
                        </asp:LinkButton>
                        &nbsp;
                        <a href='<%# ResolveUrl("~/Customer/ProductDetails.aspx?id=" & Eval("ProductID").ToString()) %>'
                           class="fk-btn fk-btn-outline text-sm">Skip</a>
                    </asp:Panel>
                </div>
            </ItemTemplate>
        </asp:Repeater>

        <asp:PlaceHolder ID="phNoProducts" runat="server" Visible="false">
            <div class="fk-card p-4 text-center">
                <p class="fk-text-muted">No products found for this order.</p>
            </div>
        </asp:PlaceHolder>

        <div class="text-center mt-4 mb-5">
            <a href="<%=ResolveUrl("~/Customer/search_product.aspx") %>" class="fk-btn fk-btn-primary">Continue Shopping</a>
        </div>
    </div>
</asp:Content>

