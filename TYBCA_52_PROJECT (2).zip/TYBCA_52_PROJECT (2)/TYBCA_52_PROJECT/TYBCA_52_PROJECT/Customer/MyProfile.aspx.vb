Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers

Public Class MyProfile
    Inherits System.Web.UI.Page

    Private ReadOnly Property CurrentUserId As Integer
        Get
            Dim userId As Integer
            Integer.TryParse(Convert.ToString(Session("UserID")), userId)
            Return userId
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If CurrentUserId <= 0 Then
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/MyProfile.aspx"))
            Return
        End If
        If Not IsPostBack Then
            Dim profile As DataTable = Db.ExecuteQuery("SELECT FullName, Username, Mobileno FROM register WHERE UserID = @UserID",
                                                       Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
            If profile.Rows.Count > 0 Then
                txtName.Text = If(IsDBNull(profile.Rows(0)("FullName")) OrElse String.IsNullOrWhiteSpace(Convert.ToString(profile.Rows(0)("FullName"))),
                                  Convert.ToString(profile.Rows(0)("Username")), Convert.ToString(profile.Rows(0)("FullName")))
                txtMobile.Text = Convert.ToString(profile.Rows(0)("Mobileno"))
            End If
            BindAddresses()
        End If
    End Sub

    Protected Sub btnSaveProfile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSaveProfile.Click
        Dim name As String = txtName.Text.Trim()
        Dim mobile As String = txtMobile.Text.Trim()
        If String.IsNullOrWhiteSpace(name) OrElse Not System.Text.RegularExpressions.Regex.IsMatch(mobile, "^[0-9]{10}$") Then
            lblMessage.Text = "Enter your name and a valid 10-digit mobile number."
            Return
        End If

        Dim changePassword As Boolean = Not String.IsNullOrWhiteSpace(txtCurrentPassword.Text) OrElse
                                        Not String.IsNullOrWhiteSpace(txtNewPassword.Text) OrElse
                                        Not String.IsNullOrWhiteSpace(txtConfirmPassword.Text)
        Try
            If changePassword Then
                Dim account As DataTable = Db.ExecuteQuery("SELECT Password, PasswordHash, Salt FROM register WHERE UserID = @UserID",
                                                           Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
                If account.Rows.Count = 0 Then
                    lblMessage.Text = "Account not found."
                    Return
                End If
                Dim row As DataRow = account.Rows(0)
                Dim oldHash As String = If(IsDBNull(row("PasswordHash")), "", Convert.ToString(row("PasswordHash")))
                Dim oldSalt As String = If(IsDBNull(row("Salt")), "", Convert.ToString(row("Salt")))
                Dim currentValid As Boolean = If(String.IsNullOrEmpty(oldHash) OrElse String.IsNullOrEmpty(oldSalt),
                                                 Convert.ToString(row("Password")) = txtCurrentPassword.Text,
                                                 Security.VerifyPassword(txtCurrentPassword.Text, oldHash, oldSalt))
                Dim passwordError As String = Nothing
                If Not currentValid Then
                    lblMessage.Text = "Current password is incorrect."
                    Return
                End If
                If Not Security.ValidatePasswordRules(txtNewPassword.Text, passwordError) Then
                    lblMessage.Text = passwordError
                    Return
                End If
                If txtNewPassword.Text <> txtConfirmPassword.Text Then
                    lblMessage.Text = "The new password and confirmation do not match."
                    Return
                End If
                Dim newSalt As String = Security.GenerateSalt()
                Dim newHash As String = Security.HashPassword(txtNewPassword.Text, newSalt)
                Db.ExecuteNonQuery("UPDATE register SET FullName = @Name, Mobileno = @Mobile, Password = '', PasswordHash = @Hash, Salt = @Salt WHERE UserID = @UserID",
                                   Db.CreateParam("@Name", SqlDbType.NVarChar, name, 100),
                                   Db.CreateParam("@Mobile", SqlDbType.NVarChar, mobile, 15),
                                   Db.CreateParam("@Hash", SqlDbType.NVarChar, newHash, 255),
                                   Db.CreateParam("@Salt", SqlDbType.NVarChar, newSalt, 255),
                                   Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
            Else
                Db.ExecuteNonQuery("UPDATE register SET FullName = @Name, Mobileno = @Mobile WHERE UserID = @UserID",
                                   Db.CreateParam("@Name", SqlDbType.NVarChar, name, 100),
                                   Db.CreateParam("@Mobile", SqlDbType.NVarChar, mobile, 15),
                                   Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
            End If
            txtCurrentPassword.Text = ""
            txtNewPassword.Text = ""
            txtConfirmPassword.Text = ""
            lblMessage.Text = "Profile saved."
        Catch ex As Exception
            Logger.LogError("Error updating customer profile", ex)
            lblMessage.Text = "We could not save your profile. Please try again."
        End Try
    End Sub

    Protected Sub btnAddAddress_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddAddress.Click
        Dim mobile As String = txtAddressMobile.Text.Trim()
        Dim pincode As String = txtAddressPincode.Text.Trim()
        If String.IsNullOrWhiteSpace(txtAddressName.Text.Trim()) OrElse String.IsNullOrWhiteSpace(txtAddressLine.Text.Trim()) OrElse
           String.IsNullOrWhiteSpace(txtAddressCity.Text.Trim()) OrElse Not System.Text.RegularExpressions.Regex.IsMatch(mobile, "^[0-9]{10}$") OrElse
           Not System.Text.RegularExpressions.Regex.IsMatch(pincode, "^[0-9]{6}$") Then
            lblMessage.Text = "Complete all address fields and enter valid 10-digit mobile and 6-digit pincode."
            Return
        End If
        Try
            Using connection As SqlConnection = Db.GetConnection()
                Using transaction As SqlTransaction = connection.BeginTransaction()
                    If chkDefaultAddress.Checked Then
                        Using clearDefault As New SqlCommand("UPDATE CustomerAddresses SET IsDefault = 0 WHERE UserID = @UserID", connection, transaction)
                            clearDefault.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
                            clearDefault.ExecuteNonQuery()
                        End Using
                    End If
                    Using insertAddress As New SqlCommand("INSERT INTO CustomerAddresses (UserID, FullName, Mobile, AddressLine, City, Pincode, IsDefault) VALUES (@UserID, @Name, @Mobile, @Address, @City, @Pincode, @IsDefault)", connection, transaction)
                        insertAddress.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
                        insertAddress.Parameters.Add(Db.CreateParam("@Name", SqlDbType.NVarChar, txtAddressName.Text.Trim(), 100))
                        insertAddress.Parameters.Add(Db.CreateParam("@Mobile", SqlDbType.NVarChar, mobile, 15))
                        insertAddress.Parameters.Add(Db.CreateParam("@Address", SqlDbType.NVarChar, txtAddressLine.Text.Trim(), 255))
                        insertAddress.Parameters.Add(Db.CreateParam("@City", SqlDbType.NVarChar, txtAddressCity.Text.Trim(), 100))
                        insertAddress.Parameters.Add(Db.CreateParam("@Pincode", SqlDbType.NVarChar, pincode, 10))
                        insertAddress.Parameters.Add(Db.CreateParam("@IsDefault", SqlDbType.Bit, chkDefaultAddress.Checked))
                        insertAddress.ExecuteNonQuery()
                    End Using
                    transaction.Commit()
                End Using
            End Using
            txtAddressName.Text = ""
            txtAddressMobile.Text = ""
            txtAddressLine.Text = ""
            txtAddressCity.Text = ""
            txtAddressPincode.Text = ""
            chkDefaultAddress.Checked = False
            lblMessage.Text = "Delivery address saved."
            BindAddresses()
        Catch ex As Exception
            Logger.LogError("Error saving customer address", ex)
            lblMessage.Text = "We could not save the address. Please try again."
        End Try
    End Sub

    Protected Sub gvAddresses_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName <> "DeleteAddress" Then Return
        Dim addressId As Integer
        If Not Integer.TryParse(Convert.ToString(e.CommandArgument), addressId) Then Return
        Db.ExecuteNonQuery("DELETE FROM CustomerAddresses WHERE AddressID = @AddressID AND UserID = @UserID",
                           Db.CreateParam("@AddressID", SqlDbType.Int, addressId),
                           Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
        lblMessage.Text = "Delivery address removed."
        BindAddresses()
    End Sub

    Private Sub BindAddresses()
        gvAddresses.DataSource = Db.ExecuteQuery("SELECT AddressID, FullName, Mobile, AddressLine, City, Pincode, IsDefault FROM CustomerAddresses WHERE UserID = @UserID ORDER BY IsDefault DESC, AddressID DESC",
                                                 Db.CreateParam("@UserID", SqlDbType.Int, CurrentUserId))
        gvAddresses.DataBind()
    End Sub
End Class
