Imports System
Imports System.Collections.Generic
Imports TYBCA_52_PROJECT.Models
Imports TYBCA_52_PROJECT.Services
Imports TYBCA_52_PROJECT.Helpers

Public Class CustomerCart
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindCart()
        End If
    End Sub

    Private Sub BindCart()
        Dim items As List(Of CartItem) = CartService.GetCart(Context)
        rptCart.DataSource = items
        rptCart.DataBind()

        Dim count As Integer = 0
        Dim subtotal As Decimal = 0
        For Each item In items
            count += item.Quantity
            subtotal += (item.Price * item.Quantity)
        Next

        Dim mrpTotal As Decimal = subtotal * CDec(1.3)
        Dim discount As Decimal = mrpTotal - subtotal
        Dim deliveryFee As Decimal = If(subtotal >= 500 OrElse subtotal = 0, 0, 40)
        Dim grandTotal As Decimal = subtotal + deliveryFee
        Dim couponDiscount As Decimal = CouponService.AppliedDiscount(Context, subtotal)
        grandTotal = Math.Max(0D, grandTotal - couponDiscount)

        litCartCount.Text = count.ToString()
        litItemCount.Text = count.ToString()
        litSubtotal.Text = String.Format("{0:N0}", mrpTotal)
        litDiscount.Text = String.Format("{0:N0}", discount)
        litCouponDiscount.Text = String.Format("{0:N0}", couponDiscount)
        Dim appliedCode As String = CouponService.AppliedCode(Context)
        litCouponCode.Text = If(String.IsNullOrEmpty(appliedCode), "", "(" & Server.HtmlEncode(appliedCode) & ")")
        If Not String.IsNullOrEmpty(appliedCode) Then txtCouponCode.Text = appliedCode
        btnRemoveCoupon.Visible = Not String.IsNullOrEmpty(appliedCode)

        If deliveryFee = 0 Then
            litDeliveryFee.Text = "<span class='fk-text-success font-bold'>FREE</span>"
        Else
            litDeliveryFee.Text = "Rs " & String.Format("{0:N0}", deliveryFee)
        End If

        litGrandTotal.Text = String.Format("{0:N0}", grandTotal)
        litSavedAmount.Text = String.Format("{0:N0}", discount)

        phEmptyCart.Visible = (items.Count = 0)
        btnProceedCheckout.Enabled = (items.Count > 0)
    End Sub

    Protected Sub btnApplyCoupon_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim subtotal As Decimal = 0D
        For Each item As CartItem In CartService.GetCart(Context)
            subtotal += item.Price * item.Quantity
        Next
        Dim discount As Decimal
        Dim message As String = ""
        If CouponService.TryCalculate(txtCouponCode.Text, subtotal, discount, message) Then
            Session("AppliedCouponCode") = txtCouponCode.Text.Trim().ToUpperInvariant()
        Else
            Session.Remove("AppliedCouponCode")
        End If
        lblCouponMessage.Text = message
        BindCart()
    End Sub

    Protected Sub btnRemoveCoupon_Click(ByVal sender As Object, ByVal e As EventArgs)
        Session.Remove("AppliedCouponCode")
        Session.Remove("AppliedCouponDiscount")
        lblCouponMessage.Text = "Coupon removed."
        BindCart()
    End Sub

    Protected Sub rptCart_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If e.CommandName = "UpdateQty" Then
            Dim args() As String = Convert.ToString(e.CommandArgument).Split("|"c)
            If args.Length = 2 Then
                Dim productId As Integer = Convert.ToInt32(args(0))
                Dim delta As Integer = Convert.ToInt32(args(1))

                Dim cart As List(Of CartItem) = CartService.GetCart(Context)
                Dim item As CartItem = cart.Find(Function(c) c.ProductID = productId)
                If item IsNot Nothing Then
                    If delta > 0 Then
                        If Not CartService.TryAddToCart(Context, productId, delta) Then
                            Toast.Show(Me, "Only the currently available stock can be added to your cart.", Toast.ToastType.Warning)
                        End If
                    Else
                        item.Quantity += delta
                    End If
                    If item.Quantity <= 0 Then
                        cart.Remove(item)
                    End If
                    CartService.SaveCart(Context, cart)
                End If
                BindCart()
            End If

        ElseIf e.CommandName = "RemoveItem" Then
            Dim productId As Integer = Convert.ToInt32(e.CommandArgument)
            CartService.RemoveFromCart(Context, productId)
            Toast.Show(Me, "Item removed from cart.", Toast.ToastType.Info)
            BindCart()
        End If
    End Sub

    Protected Sub btnProceedCheckout_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim userId As Integer
        If Integer.TryParse(Convert.ToString(Session("UserID")), userId) AndAlso userId > 0 Then
            Response.Redirect("~/Customer/checkout.aspx")
        Else
            Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
        End If
    End Sub
End Class
