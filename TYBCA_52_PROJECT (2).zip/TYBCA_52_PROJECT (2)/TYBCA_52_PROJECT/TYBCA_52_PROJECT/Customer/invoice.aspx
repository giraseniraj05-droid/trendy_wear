<%@ Page Title="Order Invoice" Language="vb" AutoEventWireup="false" CodeBehind="invoice.aspx.vb" Inherits="TYBCA_52_PROJECT.invoice" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Invoice - Trendy Wear</title>
    <style>
        :root { --glass-bg: rgba(255,255,255,.08); --glass-bg-strong: rgba(255,255,255,.13); --glass-border: rgba(255,255,255,.18); --glass-blur: blur(16px) saturate(140%); --glass-shadow: 0 18px 48px rgba(0,0,0,.22); --accent: #B4F105; --accent-contrast: #10220a; --text-on-glass: #f4f8f2; --text-on-glass-muted: #c2d0c5; --radius-lg: 20px; --radius-md: 14px; }
        * { box-sizing: border-box; }
        body { min-height: 100vh; margin: 0; padding: clamp(12px, 3vw, 30px); color: var(--text-on-glass); background: linear-gradient(135deg, #051C12, #072F1F); font-family: 'Plus Jakarta Sans', 'Segoe UI', Arial, sans-serif; }
        .invoice-card { width: min(100%, 850px); margin: 0 auto; padding: clamp(18px, 4vw, 36px); border: 1px solid var(--glass-border); border-radius: var(--radius-lg); background: var(--glass-bg); box-shadow: var(--glass-shadow); -webkit-backdrop-filter: var(--glass-blur); backdrop-filter: var(--glass-blur); }
        .header { display: flex; justify-content: space-between; gap: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--glass-border); }
        .header h1 { margin: 0; color: var(--accent); }
        .header h3 { margin-top: 0; }
        .invoice-addresses { display: flex; justify-content: space-between; gap: 24px; margin-top: 20px; }
        .invoice-addresses > div { min-width: 0; overflow-wrap: anywhere; }
        .table { width: 100%; margin-top: 20px; border-collapse: collapse; color: var(--text-on-glass); }
        .table th, .table td { padding: 11px; border: 1px solid var(--glass-border); text-align: left; }
        .table th { background: var(--glass-bg-strong); }
        .text-right { text-align: right; }
        .invoice-print-actions { margin-bottom: 20px; text-align: right; }
        .invoice-head-meta { text-align: right; }
        .invoice-totals { margin-top: 20px; }
        .invoice-thanks { color: var(--text-on-glass-muted); font-size: .9rem; }
        .invoice-print-button { padding: 9px 16px; border: 1px solid var(--glass-border); border-radius: var(--radius-md); color: var(--accent-contrast); background: var(--accent); font: inherit; font-weight: 700; cursor: pointer; }
        @media (max-width: 600px) { .header, .invoice-addresses { flex-direction: column; } .invoice-addresses > div:last-child, .header > div:last-child { text-align: left !important; } .invoice-table-wrap { overflow-x: auto; } .table { min-width: 540px; } }
        @media print { body { min-height: 0; padding: 0; color: #000; background: #fff; font-family: Arial, sans-serif; } .invoice-card { width: 100%; padding: 0; border: 0; border-radius: 0; color: #000; background: #fff; box-shadow: none; -webkit-backdrop-filter: none; backdrop-filter: none; } .header h1 { color: #000; } .header, .table th, .table td { border-color: #999; color: #000; background: #fff; } .no-print { display: none !important; } .invoice-thanks { color: #000; } }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="invoice-card">
            <div class="no-print invoice-print-actions">
                <button type="button" onclick="window.print();" class="invoice-print-button">🖨️ Print Invoice</button>
            </div>

            <div class="header">
                <div>
                    <h1>Trendy Wear</h1>
                    <p>Official E-Commerce Tax Invoice</p>
                </div>
                <div class="invoice-head-meta">
                    <h3>Invoice #<asp:Literal ID="litOrderID" runat="server"></asp:Literal></h3>
                    <p>Date: <asp:Literal ID="litDate" runat="server"></asp:Literal></p>
                </div>
            </div>

            <div class="invoice-addresses">
                <div>
                    <strong>Customer Shipping Address:</strong><br />
                    <asp:Literal ID="litCustomerName" runat="server"></asp:Literal><br />
                    <asp:Literal ID="litAddress" runat="server"></asp:Literal><br />
                    <asp:Literal ID="litCity" runat="server"></asp:Literal> - <asp:Literal ID="litPincode" runat="server"></asp:Literal><br />
                    <strong>Payment Method:</strong> <asp:Literal ID="litPaymentType" runat="server"></asp:Literal><br />
                    <strong>Payment Status:</strong> <asp:Literal ID="litPaymentStatus" runat="server"></asp:Literal>
                </div>
                <div>
                    <strong>Store Details:</strong><br />
                    Trendy Wear Store Pvt. Ltd.<br />
                    Email: support@trendywear.com<br />
                    Phone: +91 98765 43210
                </div>
            </div>

            <div class="invoice-table-wrap"><table class="table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <asp:Repeater ID="rptInvoiceItems" runat="server">
                        <ItemTemplate>
                            <tr>
                                <td><%# Eval("ProductName") %><br /><small>Size: <%# Eval("Size") %></small></td>
                                <td>₹<%# Convert.ToDecimal(Eval("Price")).ToString("N2") %></td>
                                <td><%# Eval("Quantity") %></td>
                                <td>₹<%# Convert.ToDecimal(Eval("TotalPrice")).ToString("N2") %></td>
                            </tr>
                        </ItemTemplate>
                    </asp:Repeater>
                </tbody>
            </table></div>

            <div class="text-right invoice-totals">
                <p>Coupon: <asp:Literal ID="litCouponCode" runat="server"></asp:Literal></p>
                <p>Coupon discount: - ₹<asp:Literal ID="litCouponDiscount" runat="server">0.00</asp:Literal></p>
                <h4>Total Amount Paid: ₹<asp:Literal ID="litTotal" runat="server"></asp:Literal></h4>
                <p class="invoice-thanks">Thank you for shopping with Trendy Wear!</p>
            </div>
        </div>
    </form>
</body>
</html>
