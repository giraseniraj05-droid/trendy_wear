Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class WebForm7
    Inherits System.Web.UI.Page

    Private Const ProductPageSize As Integer = 12

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' Check QueryString arguments
            Dim qCat As String = Request.QueryString("cat")
            Dim qSearch As String = Request.QueryString("q")
            Dim qSort As String = Request.QueryString("sort")
            Dim requestedPage As Integer
            If Integer.TryParse(Request.QueryString("page"), requestedPage) AndAlso requestedPage > 0 Then ViewState("ShopPage") = requestedPage

            If Not String.IsNullOrEmpty(qCat) AndAlso ddlCategoryFilter.Items.FindByValue(qCat) IsNot Nothing Then
                ddlCategoryFilter.SelectedValue = qCat
            End If

            If Not String.IsNullOrEmpty(qSearch) Then
                txtKeyword.Text = qSearch
            End If

            If Not String.IsNullOrEmpty(qSort) AndAlso ddlSort.Items.FindByValue(qSort) IsNot Nothing Then
                ddlSort.SelectedValue = qSort
            End If

            LoadProducts()
        End If
    End Sub

    Private Sub LoadProducts()
        Try
            Dim sql As String = "SELECT ProductID AS p_id, ProductName AS p_name, Category AS category_name, Price AS price, " & _
                                "ISNULL(OldPrice, Price * 1.3) AS OldPrice, Size, Stock, ProductImage AS Image, " & _
                                "(SELECT ISNULL(AVG(CAST(rv.Rating AS DECIMAL(10,2))), 0) FROM Reviews rv WHERE rv.ProductID = addproduct1.ProductID AND rv.IsApproved = 1) AS AverageRating, " & _
                                "(SELECT COUNT(*) FROM Reviews rv WHERE rv.ProductID = addproduct1.ProductID AND rv.IsApproved = 1) AS ReviewCount " & _
                                "FROM addproduct1 WHERE IsActive = 1 "
            Dim params As New List(Of SqlParameter)()

            Dim cat As String = ddlCategoryFilter.SelectedValue
            Dim keyword As String = txtKeyword.Text.Trim()
            Dim minPriceStr As String = txtMinPrice.Text.Trim()
            Dim maxPriceStr As String = txtMaxPrice.Text.Trim()
            Dim sortChoice As String = ddlSort.SelectedValue

            If Not String.IsNullOrEmpty(cat) Then
                sql &= " AND Category = @cat "
                params.Add(New SqlParameter("@cat", cat))
            End If

            If Not String.IsNullOrEmpty(keyword) Then
                sql &= " AND (ProductName LIKE @q OR Category LIKE @q OR Description LIKE @q) "
                params.Add(New SqlParameter("@q", "%" & keyword & "%"))
            End If

            Dim minP As Decimal
            If Decimal.TryParse(minPriceStr, minP) AndAlso minP > 0 Then
                sql &= " AND price >= @minP "
                params.Add(New SqlParameter("@minP", minP))
            End If

            Dim maxP As Decimal
            If Decimal.TryParse(maxPriceStr, maxP) AndAlso maxP > 0 Then
                sql &= " AND price <= @maxP "
                params.Add(New SqlParameter("@maxP", maxP))
            End If

            Dim countSql As String = "SELECT COUNT(*) " & sql.Substring(sql.IndexOf("FROM addproduct1", StringComparison.Ordinal))
            Dim totalCount As Integer = Convert.ToInt32(Db.ExecuteScalar(countSql, params.ToArray()))
            Dim totalPages As Integer = Math.Max(1, CInt(Math.Ceiling(totalCount / CDbl(ProductPageSize))))
            Dim pageIndex As Integer = If(ViewState("ShopPage") Is Nothing, 1, Convert.ToInt32(ViewState("ShopPage")))
            pageIndex = Math.Max(1, Math.Min(pageIndex, totalPages))
            ViewState("ShopPage") = pageIndex

            Select Case sortChoice
                Case "price_asc"
                    sql &= " ORDER BY Price ASC"
                Case "price_desc"
                    sql &= " ORDER BY Price DESC"
                Case "discount"
                    sql &= " ORDER BY (ISNULL(OldPrice, Price * 1.3) - Price) DESC"
                Case "rating"
                    sql &= " ORDER BY AverageRating DESC, ReviewCount DESC, ProductID DESC"
                Case Else
                    sql &= " ORDER BY ProductID DESC"
            End Select

            sql &= " OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY"
            params.Add(New SqlParameter("@Offset", (pageIndex - 1) * ProductPageSize))
            params.Add(New SqlParameter("@PageSize", ProductPageSize))
            Dim dt As DataTable = Db.ExecuteQuery(sql, params.ToArray())
            rptShopProducts.DataSource = dt
            rptShopProducts.DataBind()

            litResultCount.Text = totalCount.ToString()
            phEmptyShop.Visible = (dt.Rows.Count = 0)
            btnPrevious.Enabled = (pageIndex > 1)
            btnNext.Enabled = (pageIndex < totalPages)
            litPageInfo.Text = "Page " & pageIndex.ToString() & " of " & totalPages.ToString()

            Dim filterSummary As String = If(String.IsNullOrEmpty(cat), "All Products", cat & " Collection")
            If Not String.IsNullOrEmpty(keyword) Then filterSummary &= " matching """ & keyword & """"
            litActiveFilterText.Text = Server.HtmlEncode(filterSummary)
        Catch ex As Exception
            Logger.LogError("Error searching products", ex)
        End Try
    End Sub

    Protected Sub Filter_Changed(ByVal sender As Object, ByVal e As EventArgs)
        ViewState("ShopPage") = 1
        LoadProducts()
    End Sub

    Protected Sub btnApplyFilters_Click(ByVal sender As Object, ByVal e As EventArgs)
        ViewState("ShopPage") = 1
        LoadProducts()
    End Sub

    Protected Sub btnPrevious_Click(ByVal sender As Object, ByVal e As EventArgs)
        ViewState("ShopPage") = Math.Max(1, Convert.ToInt32(If(ViewState("ShopPage"), 1)) - 1)
        LoadProducts()
    End Sub

    Protected Sub btnNext_Click(ByVal sender As Object, ByVal e As EventArgs)
        ViewState("ShopPage") = Convert.ToInt32(If(ViewState("ShopPage"), 1)) + 1
        LoadProducts()
    End Sub

    Protected Sub btnClearFilters_Click(ByVal sender As Object, ByVal e As EventArgs)
        txtKeyword.Text = ""
        ddlCategoryFilter.SelectedIndex = 0
        txtMinPrice.Text = ""
        txtMaxPrice.Text = ""
        ddlSort.SelectedIndex = 0
        ViewState("ShopPage") = 1
        LoadProducts()
    End Sub

    Protected Sub rptShopProducts_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim productId As Integer = Convert.ToInt32(e.CommandArgument)

        If e.CommandName = "AddToCart" Then
            If CartService.TryAddToCart(Context, productId, 1) Then
                Toast.Show(Me, "Item added to cart!", Toast.ToastType.Success)
            Else
                Toast.Show(Me, "This item is out of stock or the available quantity is already in your cart.", Toast.ToastType.Warning)
            End If
            LoadProducts()

        ElseIf e.CommandName = "BuyNow" Then
            If Not CartService.TryAddToCart(Context, productId, 1) Then
                Toast.Show(Me, "This item is out of stock or the available quantity is already in your cart.", Toast.ToastType.Warning)
                Return
            End If
            Dim userId As Integer
            If Integer.TryParse(Convert.ToString(Session("UserID")), userId) AndAlso userId > 0 Then
                Response.Redirect("~/Customer/checkout.aspx")
            Else
                Response.Redirect("~/login.aspx?ReturnUrl=" & Server.UrlEncode("Customer/checkout.aspx"))
            End If
        End If
    End Sub

    Public Function GetDiscountPercentage(ByVal priceVal As Object, ByVal oldPriceVal As Object) As String
        Try
            Dim price As Decimal = Convert.ToDecimal(priceVal)
            Dim oldPrice As Decimal = Convert.ToDecimal(oldPriceVal)
            If oldPrice > price Then
                Dim discount As Integer = CInt(((oldPrice - price) / oldPrice) * 100)
                Return discount.ToString()
            End If
        Catch ex As Exception
        End Try
        Return "20"
    End Function

    Public Function GetRatingSummary(ByVal averageValue As Object, ByVal countValue As Object) As String
        Dim average As Decimal = Convert.ToDecimal(averageValue)
        Dim count As Integer = Convert.ToInt32(countValue)
        Dim stars As Integer = CInt(Math.Round(average, MidpointRounding.AwayFromZero))
        Return New String("★"c, stars) & New String("☆"c, 5 - stars) & " (" & count.ToString() & ")"
    End Function

    Public Function GetStockClass(ByVal stockVal As Object) As String
        Try
            Dim s As Integer = Convert.ToInt32(stockVal)
            If s <= 0 Then Return "fk-text-danger font-bold"
            If s <= 5 Then Return "fk-text-warning font-bold"
            Return "fk-text-success font-bold"
        Catch
            Return "fk-text-success"
        End Try
    End Function

    Public Function GetStockText(ByVal stockVal As Object) As String
        Try
            Dim s As Integer = Convert.ToInt32(stockVal)
            If s <= 0 Then Return "Out of Stock"
            If s <= 5 Then Return "Only " & s & " left in stock!"
            Return "In Stock"
        Catch
            Return "In Stock"
        End Try
    End Function
End Class
