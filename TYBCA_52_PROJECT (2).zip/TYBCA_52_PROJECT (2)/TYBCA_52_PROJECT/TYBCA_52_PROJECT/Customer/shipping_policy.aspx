<%@ Page Title="Shipping Policy" Language="VB" MasterPageFile="~/Customer/Customer.Master" AutoEventWireup="false" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server"></asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-card policy-content-panel"><div class="fk-card-header"><h1 class="fk-card-title">Shipping policy</h1></div><div class="fk-card-body">
        <p>We deliver to serviceable Indian pincodes. Estimated delivery dates shown on product pages are estimates and may change based on location and courier availability.</p>
        <p>Shipping charges, if any, are shown in the cart before you place your order. You can follow order progress in My Orders.</p>
        <p>For a delivery issue, contact support with your order number.</p>
        <p><a href="<%= ResolveUrl("~/Customer/MyOrders.aspx") %>" class="fk-link">Track an order</a></p>
    </div></div>
</asp:Content>
