Imports System.Data
Imports System.Data.SqlClient
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Services

Public Class wishlist
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim userId As Integer
        If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then
            Response.Redirect("~/login.aspx", False)
            Context.ApplicationInstance.CompleteRequest()
            Return
        End If

        If Not IsPostBack Then
            LoadWishlist()
        End If
    End Sub

    Private Sub LoadWishlist()
        Try
            Dim userId As Integer
            If Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then Return
            Dim query As String = "SELECT w.WishlistID, p.ProductID, p.ProductName, p.Price, p.ProductImage " &
                                  "FROM Wishlist w INNER JOIN addproduct1 p ON w.ProductID = p.ProductID " &
                                  "WHERE w.UserID = @UserID ORDER BY w.AddedOn DESC"

            Dim dt As DataTable = Db.GetDataTable(query, New SqlParameter() {Db.CreateParam("@UserID", SqlDbType.Int, userId)})
            rptWishlist.DataSource = dt
            rptWishlist.DataBind()

            If dt.Rows.Count = 0 Then
                lblMsg.Text = "Your wishlist is currently empty."
                lblMsg.Visible = True
            Else
                lblMsg.Visible = False
            End If
        Catch ex As Exception
            Logger.LogException(ex, "Error loading wishlist")
        End Try
    End Sub

    Protected Sub btnAddToCart_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim productId As String = CType(sender, Button).CommandArgument
        Dim id As Integer
        If Integer.TryParse(productId, id) AndAlso CartService.TryAddToCart(Context, id, 1) Then
            Toast.ShowMessage(Me, "Product added to cart!", ToastType.Success)
        Else
            Toast.ShowMessage(Me, "This item is out of stock or unavailable.", ToastType.Warning)
        End If
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim wishlistId As Integer
        Dim userId As Integer
        If Not Integer.TryParse(CType(sender, Button).CommandArgument, wishlistId) OrElse wishlistId <= 0 OrElse
           Not Integer.TryParse(Convert.ToString(Session("UserID")), userId) OrElse userId <= 0 Then Return
        Db.ExecuteNonQuery("DELETE FROM Wishlist WHERE WishlistID = @WishlistID AND UserID = @UserID",
                          New SqlParameter() {Db.CreateParam("@WishlistID", SqlDbType.Int, wishlistId),
                                              Db.CreateParam("@UserID", SqlDbType.Int, userId)})
        LoadWishlist()
        Toast.ShowMessage(Me, "Item removed from wishlist.", ToastType.Info)
    End Sub
End Class
