<%@ Page Title="Feedback" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customer/Customer.Master" CodeBehind="feedback.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm6" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="fk-container customer-feedback">
        <h1 class="section-heading mb-3">General Feedback</h1>
        <p class="fk-text-muted mb-3">
            Want to review a specific product? Visit the product page from your
            <a href="~/Customer/myorders.aspx">order history</a> and leave a review there.
        </p>

        <div class="fk-card mt-5 feedback-form-card">
            <div class="fk-card-header"><h2 class="fk-card-title">General feedback</h2></div>
            <div class="fk-card-body">
                <div class="feedback-section">
                    <label class="form-label">Rating</label>
                    <asp:DropDownList ID="ddlRating" runat="server" CssClass="fk-select">
                        <asp:ListItem Text="Select Rating" Value="" />
                        <asp:ListItem Text="1 Star â˜…" Value="1" />
                        <asp:ListItem Text="2 Stars â˜…â˜…" Value="2" />
                        <asp:ListItem Text="3 Stars â˜…â˜…â˜…" Value="3" />
                        <asp:ListItem Text="4 Stars â˜…â˜…â˜…â˜…" Value="4" />
                        <asp:ListItem Text="5 Stars â˜…â˜…â˜…â˜…â˜…" Value="5" />
                    </asp:DropDownList>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="Please select a rating." Display="Dynamic" InitialValue="" ControlToValidate="ddlRating" CssClass="text-danger-sm" />
                </div>
                <div class="feedback-section mt-3">
                    <label class="form-label">Feedback type</label>
                    <asp:DropDownList ID="ddlFeedbackType" runat="server" CssClass="fk-select">
                        <asp:ListItem Text="General Feedback" Value="General"></asp:ListItem>
                        <asp:ListItem Text="Complaint" Value="Complaint"></asp:ListItem>
                        <asp:ListItem Text="Suggestion" Value="Suggestion"></asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="feedback-section mt-3">
                    <label class="form-label">Comments</label>
                    <asp:TextBox ID="txtComments" runat="server" CssClass="fk-input" TextMode="MultiLine" Rows="4" Placeholder="Write your comments here..."></asp:TextBox>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ErrorMessage="Please enter a message." Display="Dynamic" ControlToValidate="txtComments" CssClass="text-danger-sm" />
                </div>
                <div class="feedback-section mt-3 mb-3">
                    <asp:CheckBox ID="chkRecommend" runat="server" Text=" Would you recommend Trendy Wear to others?" Checked="true" />
                </div>
                <asp:Button ID="btnSubmitFeedback" runat="server" Text="Submit general feedback" CssClass="fk-btn fk-btn-primary" OnClick="btnSubmitFeedback_Click" />
            </div>
        </div>
    </div>
</asp:Content>
