<%@ Page Language="VB" AutoEventWireup="false" CodeBehind="search_suggestions.aspx.vb" Inherits="TYBCA_52_PROJECT.SearchSuggestions" %>
