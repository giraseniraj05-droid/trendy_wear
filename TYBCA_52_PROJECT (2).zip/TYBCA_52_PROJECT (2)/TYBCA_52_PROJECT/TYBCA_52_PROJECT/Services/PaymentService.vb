Imports System
Imports System.Collections.Generic

Namespace Services
    Public Enum PaymentStatus
        Pending
        Paid
        Failed
        Refunded
    End Enum

    Public Class PaymentStatusNames
        Public Const Pending As String = "Pending"
        Public Const Paid As String = "Paid"
        Public Const Failed As String = "Failed"
        Public Const Refunded As String = "Refunded"

        Public Shared ReadOnly Property All As String()
            Get
                Return New String() {Pending, Paid, Failed, Refunded}
            End Get
        End Property

        Public Shared Function IsValid(ByVal status As String) As Boolean
            If String.IsNullOrWhiteSpace(status) Then Return False
            For Each s In All
                If s.Equals(status.Trim(), StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Public Shared Function Normalize(ByVal status As String) As String
            If String.IsNullOrWhiteSpace(status) Then Return Pending
            For Each s In All
                If s.Equals(status.Trim(), StringComparison.OrdinalIgnoreCase) Then Return s
            Next
            Return Pending
        End Function
    End Class

    Public Class PaymentMethodNames
        Public Const COD As String = "COD"
        Public Const UPI As String = "UPI"
    End Class

    Public Class PaymentResult
        Public Property Success As Boolean
        Public Property Status As String
        Public Property TransactionId As String
        Public Property ErrorMessage As String

        Public Sub New(ByVal isSuccess As Boolean, ByVal statusValue As String, Optional ByVal transId As String = "", Optional ByVal errMsg As String = "")
            Me.Success = isSuccess
            Me.Status = statusValue
            Me.TransactionId = transId
            Me.ErrorMessage = errMsg
        End Sub
    End Class

    Public Interface IPaymentMethod
        ReadOnly Property MethodCode As String
        ReadOnly Property DisplayName As String
        ReadOnly Property IsAvailable As Boolean
        ReadOnly Property InitialStatus As String
        Function ProcessPayment(ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult
    End Interface

    Public Class CodPaymentMethod
        Implements IPaymentMethod

        Public ReadOnly Property MethodCode As String Implements IPaymentMethod.MethodCode
            Get
                Return PaymentMethodNames.COD
            End Get
        End Property

        Public ReadOnly Property DisplayName As String Implements IPaymentMethod.DisplayName
            Get
                Return "Cash on Delivery"
            End Get
        End Property

        Public ReadOnly Property IsAvailable As Boolean Implements IPaymentMethod.IsAvailable
            Get
                Return True
            End Get
        End Property

        Public ReadOnly Property InitialStatus As String Implements IPaymentMethod.InitialStatus
            Get
                Return PaymentStatusNames.Pending
            End Get
        End Property

        Public Function ProcessPayment(ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult Implements IPaymentMethod.ProcessPayment
            Return New PaymentResult(True, PaymentStatusNames.Pending, "COD-" & orderId.ToString())
        End Function
    End Class

    Public Class UpiPaymentMethod
        Implements IPaymentMethod

        Public ReadOnly Property MethodCode As String Implements IPaymentMethod.MethodCode
            Get
                Return PaymentMethodNames.UPI
            End Get
        End Property

        Public ReadOnly Property DisplayName As String Implements IPaymentMethod.DisplayName
            Get
                Return "UPI"
            End Get
        End Property

        Public ReadOnly Property IsAvailable As Boolean Implements IPaymentMethod.IsAvailable
            Get
                ' UPI is not live yet
                Return False
            End Get
        End Property

        Public ReadOnly Property InitialStatus As String Implements IPaymentMethod.InitialStatus
            Get
                Return PaymentStatusNames.Pending
            End Get
        End Property

        Public Function ProcessPayment(ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult Implements IPaymentMethod.ProcessPayment
            ' Reject payment attempt because UPI is not live yet
            Throw New InvalidOperationException("UPI payment gateway is not live yet.")
        End Function
    End Class

    Public Class PaymentService
        Private Shared ReadOnly PaymentHandlers As New Dictionary(Of String, IPaymentMethod)(StringComparer.OrdinalIgnoreCase) From {
            {PaymentMethodNames.COD, New CodPaymentMethod()},
            {PaymentMethodNames.UPI, New UpiPaymentMethod()}
        }

        Public Shared Function GetPaymentMethod(ByVal methodCode As String) As IPaymentMethod
            If String.IsNullOrWhiteSpace(methodCode) Then Return Nothing
            Dim handler As IPaymentMethod = Nothing
            PaymentHandlers.TryGetValue(methodCode.Trim(), handler)
            Return handler
        End Function

        Public Shared Function IsMethodAvailable(ByVal methodCode As String) As Boolean
            Dim handler As IPaymentMethod = GetPaymentMethod(methodCode)
            Return handler IsNot Nothing AndAlso handler.IsAvailable
        End Function

        Public Shared Function ProcessCodPayment(ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult
            Dim handler = New CodPaymentMethod()
            Return handler.ProcessPayment(orderId, amount)
        End Function

        Public Shared Function ProcessUpiPayment(ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult
            Dim handler = New UpiPaymentMethod()
            If Not handler.IsAvailable Then
                Return New PaymentResult(False, PaymentStatusNames.Failed, "", "UPI payment is coming soon and currently unavailable.")
            End If
            Return handler.ProcessPayment(orderId, amount)
        End Function

        Public Shared Function ProcessPayment(ByVal methodCode As String, ByVal orderId As Integer, ByVal amount As Decimal) As PaymentResult
            If String.Equals(methodCode, PaymentMethodNames.COD, StringComparison.OrdinalIgnoreCase) Then
                Return ProcessCodPayment(orderId, amount)
            ElseIf String.Equals(methodCode, PaymentMethodNames.UPI, StringComparison.OrdinalIgnoreCase) Then
                Return ProcessUpiPayment(orderId, amount)
            Else
                Return New PaymentResult(False, PaymentStatusNames.Failed, "", "Unsupported payment method: " & methodCode)
            End If
        End Function

        Public Shared Function GetPaymentMethodDisplay(ByVal methodCode As String) As String
            If String.IsNullOrWhiteSpace(methodCode) Then Return "Unknown"
            Dim handler = GetPaymentMethod(methodCode)
            If handler IsNot Nothing Then Return handler.DisplayName
            If methodCode.Equals("COD", StringComparison.OrdinalIgnoreCase) Then Return "Cash on Delivery"
            Return methodCode
        End Function
    End Class
End Namespace

