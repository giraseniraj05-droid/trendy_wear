Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers
Imports TYBCA_52_PROJECT.Models

Namespace Services
    Public Class CartService
        Public Shared Function GetCart(Optional ByVal context As HttpContext = Nothing) As List(Of CartItem)
            If context Is Nothing Then context = HttpContext.Current
            If context Is Nothing OrElse context.Session Is Nothing Then Return New List(Of CartItem)()

            If context.Session("CartList") Is Nothing Then
                context.Session("CartList") = New List(Of CartItem)()
            End If
            Return CType(context.Session("CartList"), List(Of CartItem))
        End Function

        Public Shared Sub SaveCart(ByVal context As HttpContext, ByVal items As List(Of CartItem))
            If context Is Nothing Then context = HttpContext.Current
            If context IsNot Nothing AndAlso context.Session IsNot Nothing Then
                context.Session("CartList") = items
            End If
        End Sub

        Public Shared Sub AddToCart(ByVal context As HttpContext, ByVal productId As Integer, ByVal qty As Integer)
            TryAddToCart(context, productId, qty)
        End Sub

        Public Shared Function TryAddToCart(ByVal context As HttpContext, ByVal productId As Integer, ByVal qty As Integer) As Boolean
            If qty <= 0 Then Return False
            Dim cart As List(Of CartItem) = GetCart(context)
            Dim existing As CartItem = cart.Find(Function(c) c.ProductID = productId)
            Try
                Dim dt As DataTable = Db.ExecuteQuery("SELECT ProductID AS p_id, ProductName AS p_name, Category AS category_name, Size, Price AS price, ProductImage AS Image, Stock " & _
                                                      "FROM addproduct1 WHERE ProductID = @id AND IsActive = 1", New SqlParameter("@id", productId))
                If dt.Rows.Count = 0 Then Return False
                Dim row As DataRow = dt.Rows(0)
                Dim stock As Integer = Convert.ToInt32(row("Stock"))
                Dim requestedQuantity As Integer = qty + If(existing Is Nothing, 0, existing.Quantity)
                If stock <= 0 OrElse requestedQuantity > stock Then Return False
                If existing IsNot Nothing Then
                    existing.Quantity = requestedQuantity
                    existing.Price = Convert.ToDecimal(row("price"))
                Else
                    cart.Add(New CartItem() With {
                        .ProductID = productId,
                        .ProductName = row("p_name").ToString(),
                        .Category = row("category_name").ToString(),
                        .Size = row("Size").ToString(),
                        .Price = Convert.ToDecimal(row("price")),
                        .Quantity = qty,
                        .ProductImage = If(IsDBNull(row("Image")), "default.jpg", row("Image").ToString())
                    })
                End If
                SaveCart(context, cart)
                Return True
            Catch ex As Exception
                Logger.LogError("Error adding to cart", ex)
                Return False
            End Try
        End Function

        Public Shared Sub AddToCart(ByVal productId As Integer, Optional ByVal qty As Integer = 1)
            AddToCart(HttpContext.Current, productId, qty)
        End Sub

        Public Shared Sub AddToCart(ByVal productId As String, Optional ByVal qty As Integer = 1)
            Dim id As Integer = 0
            Integer.TryParse(productId, id)
            AddToCart(HttpContext.Current, id, qty)
        End Sub

        Public Shared Sub RemoveFromCart(ByVal context As HttpContext, ByVal productId As Integer)
            Dim cart As List(Of CartItem) = GetCart(context)
            cart.RemoveAll(Function(c) c.ProductID = productId)
            SaveCart(context, cart)
        End Sub

        Public Shared Sub ClearCart(Optional ByVal context As HttpContext = Nothing)
            If context Is Nothing Then context = HttpContext.Current
            If context IsNot Nothing AndAlso context.Session IsNot Nothing Then
                context.Session("CartList") = New List(Of CartItem)()
            End If
        End Sub

        Public Shared Function GetCartItemCount(Optional ByVal context As HttpContext = Nothing) As Integer
            Dim cart As List(Of CartItem) = GetCart(context)
            Dim total As Integer = 0
            For Each item In cart
                total += item.Quantity
            Next
            Return total
        End Function
    End Class
End Namespace
