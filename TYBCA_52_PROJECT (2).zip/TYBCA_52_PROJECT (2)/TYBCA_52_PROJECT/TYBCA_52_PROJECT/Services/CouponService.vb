Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Namespace Services
    Public Class CouponService
        Public Shared Function TryCalculate(ByVal code As String, ByVal subtotal As Decimal, ByRef discount As Decimal, ByRef message As String) As Boolean
            discount = 0D
            message = ""
            code = If(code, "").Trim().ToUpperInvariant()
            If code.Length = 0 Then
                message = "Enter a coupon code."
                Return False
            End If
            Dim coupon As DataTable = Db.ExecuteQuery("SELECT CouponCode, DiscountType, DiscountValue, MinOrderAmount, MaxDiscountAmount FROM Coupons WHERE UPPER(CouponCode) = @Code AND IsActive = 1 AND ExpiryDate >= GETDATE() AND TimesUsed < UsageLimit",
                                                     Db.CreateParam("@Code", SqlDbType.NVarChar, code, 50))
            If coupon.Rows.Count = 0 Then
                message = "That coupon is invalid, expired, disabled, or fully used."
                Return False
            End If
            Dim row As DataRow = coupon.Rows(0)
            If subtotal < Convert.ToDecimal(row("MinOrderAmount")) Then
                message = "This coupon requires a minimum order of Rs " & Convert.ToDecimal(row("MinOrderAmount")).ToString("N0") & "."
                Return False
            End If
            Dim value As Decimal = Convert.ToDecimal(row("DiscountValue"))
            If String.Equals(Convert.ToString(row("DiscountType")), "Percentage", StringComparison.OrdinalIgnoreCase) Then
                discount = subtotal * value / 100D
            Else
                discount = value
            End If
            If Not IsDBNull(row("MaxDiscountAmount")) Then discount = Math.Min(discount, Convert.ToDecimal(row("MaxDiscountAmount")))
            discount = Math.Max(0D, Math.Min(subtotal, Decimal.Round(discount, 2)))
            message = "Coupon " & code & " applied. You save Rs " & discount.ToString("N2") & "."
            Return discount > 0D
        End Function

        Public Shared Function AppliedCode(ByVal context As HttpContext) As String
            If context Is Nothing OrElse context.Session Is Nothing Then Return ""
            Return Convert.ToString(context.Session("AppliedCouponCode"))
        End Function

        Public Shared Function AppliedDiscount(ByVal context As HttpContext, ByVal subtotal As Decimal) As Decimal
            Dim code As String = AppliedCode(context)
            If String.IsNullOrWhiteSpace(code) Then Return 0D
            Dim discount As Decimal
            Dim message As String = ""
            If Not TryCalculate(code, subtotal, discount, message) Then
                context.Session.Remove("AppliedCouponCode")
                Return 0D
            End If
            context.Session("AppliedCouponDiscount") = discount
            Return discount
        End Function
    End Class
End Namespace
