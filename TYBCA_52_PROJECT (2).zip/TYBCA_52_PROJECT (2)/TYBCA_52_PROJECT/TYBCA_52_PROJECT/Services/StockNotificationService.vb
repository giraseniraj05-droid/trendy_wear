Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Namespace Services
    Public Class StockNotificationService
        Public Shared Function Subscribe(ByVal productId As Integer, ByVal email As String) As Boolean
            email = If(email, "").Trim()
            If Not System.Text.RegularExpressions.Regex.IsMatch(email, "^[^\s@]+@[^\s@]+\.[^\s@]+$") Then Return False
            Dim result As Integer = Db.ExecuteNonQuery(
                "IF EXISTS (SELECT 1 FROM addproduct1 WHERE ProductID = @ProductID AND IsActive = 1 AND Stock = 0) " &
                "BEGIN IF EXISTS (SELECT 1 FROM StockAlerts WHERE ProductID = @ProductID AND Email = @Email) UPDATE StockAlerts SET IsNotified = 0, CreatedAt = GETDATE() WHERE ProductID = @ProductID AND Email = @Email " &
                "ELSE INSERT INTO StockAlerts (ProductID, Email) VALUES (@ProductID, @Email) END",
                Db.CreateParam("@ProductID", SqlDbType.Int, productId),
                Db.CreateParam("@Email", SqlDbType.NVarChar, email, 255))
            Return result > 0
        End Function

        Public Shared Sub NotifyIfBackInStock(ByVal productId As Integer, ByVal page As System.Web.UI.Page)
            Try
                Dim product As DataTable = Db.ExecuteQuery("SELECT ProductName, Stock FROM addproduct1 WHERE ProductID = @ProductID AND IsActive = 1",
                                                           Db.CreateParam("@ProductID", SqlDbType.Int, productId))
                If product.Rows.Count = 0 OrElse Convert.ToInt32(product.Rows(0)("Stock")) <= 0 Then Return
                Dim alerts As DataTable = Db.GetDataTable("UPDATE StockAlerts SET IsNotified = 1 OUTPUT inserted.Email WHERE ProductID = @ProductID AND IsNotified = 0",
                                                          Db.CreateParam("@ProductID", SqlDbType.Int, productId))
                Dim name As String = HttpUtility.HtmlEncode(Convert.ToString(product.Rows(0)("ProductName")))
                Dim url As String = page.Request.Url.GetLeftPart(UriPartial.Authority) & page.ResolveUrl("~/Customer/ProductDetails.aspx?id=" & productId.ToString())
                For Each alert As DataRow In alerts.Rows
                    Mailer.SendAsync(Convert.ToString(alert("Email")), "Back in stock: " & Convert.ToString(product.Rows(0)("ProductName")),
                                     Mailer.Wrap("Back in stock", "<p>" & name & " is available again.</p><p><a href='" & HttpUtility.HtmlAttributeEncode(url) & "'>Shop now</a></p>"),
                                     "BackInStock")
                Next
            Catch ex As Exception
                Logger.LogError("Error sending back-in-stock notices for ProductID " & productId.ToString(), ex)
            End Try
        End Sub
    End Class
End Namespace
