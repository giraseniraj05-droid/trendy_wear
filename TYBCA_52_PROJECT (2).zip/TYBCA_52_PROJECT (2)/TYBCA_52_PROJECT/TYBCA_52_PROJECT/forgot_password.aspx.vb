Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class WebForm8
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblMsg.Text = ""
        End If
    End Sub

    Protected Sub btnSendReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSendReset.Click
        If Not Page.IsValid Then Return

        Dim inputStr As String = txtEmailOrUser.Text.Trim()
        lblMsg.Text = ""

        Const NeutralNotice As String = "If an account exists, a code has been sent."

        Try
            ' 1. Check if user exists
            Dim dt As DataTable = Db.ExecuteQuery(
                "SELECT UserID, Username, Email FROM register WHERE Username = @i OR Email = @i",
                New SqlParameter("@i", inputStr))

            If dt.Rows.Count = 0 Then
                ' Don't reveal account non-existence: always show the same neutral message
                ShowNeutralSuccess(inputStr, NeutralNotice)
                Return
            End If

            Dim row As DataRow = dt.Rows(0)
            Dim userId As Integer = Convert.ToInt32(row("UserID"))
            Dim username As String = Convert.ToString(row("Username"))
            Dim userEmail As String = Convert.ToString(row("Email"))

            ' 2. Check Resend Cooldown (60 seconds) per account
            Dim recentCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM PasswordResets WHERE UserID = @UserID AND CreatedAt >= DATEADD(second, -60, GETDATE())",
                Db.CreateParam("@UserID", SqlDbType.Int, userId)))

            If recentCount > 0 Then
                ' In cooldown: do not generate new code or email, show neutral message
                ShowNeutralSuccess(inputStr, NeutralNotice)
                Return
            End If

            ' 3. Check Limit of 5 requests per hour per account
            Dim hourlyCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM PasswordResets WHERE UserID = @UserID AND CreatedAt >= DATEADD(hour, -1, GETDATE())",
                Db.CreateParam("@UserID", SqlDbType.Int, userId)))

            If hourlyCount >= 5 Then
                ' Hourly limit exceeded: do not generate new code or email, show neutral message
                ShowNeutralSuccess(inputStr, NeutralNotice)
                Return
            End If

            ' 4. Invalidate any existing unused reset codes for this account
            Db.ExecuteNonQuery(
                "UPDATE PasswordResets SET IsUsed = 1 WHERE UserID = @UserID AND IsUsed = 0",
                Db.CreateParam("@UserID", SqlDbType.Int, userId))

            ' 5. Generate random 6-digit code with RNGCryptoServiceProvider (not Random)
            Dim code As String = Security.GenerateSixDigitCode()
            Dim tokenHash As String = Security.HashResetCode(code)

            ' 6. Store only a HASH in PasswordResets, expire in 10 minutes, Attempts = 0
            Db.ExecuteNonQuery(
                "INSERT INTO PasswordResets (UserID, TokenHash, ExpiresAt, IsUsed, CreatedAt, Attempts) VALUES (@UserID, @TokenHash, DATEADD(minute, 10, GETDATE()), 0, GETDATE(), 0)",
                Db.CreateParam("@UserID", SqlDbType.Int, userId),
                Db.CreateParam("@TokenHash", SqlDbType.NVarChar, tokenHash, 255))

            ' 7. Email the 6-digit code
            Dim safeUsername As String = HttpUtility.HtmlEncode(username)
            Dim emailBody As String = Mailer.Wrap(
                "Reset your password",
                "<p>Hello " & safeUsername & ",</p>" & _
                "<p>You recently requested to reset your password for your Trendy Wear account. Your 6-digit verification code is:</p>" & _
                "<div style='font-size:32px;font-weight:bold;letter-spacing:8px;padding:16px;background:#f0f4f8;text-align:center;margin:20px 0;border-radius:8px;color:#253044;'>" & code & "</div>" & _
                "<p>This code will expire in <strong>10 minutes</strong>. For your security, please do not share this code with anyone.</p>" & _
                "<p>If you did not request this code, you can safely ignore this email.</p>")

            Mailer.SendAsync(userEmail, "Your Password Reset Code - Trendy Wear", emailBody, "PasswordReset")

            ' 8. Store reset context in session and show neutral success message
            Session("ResetUserId") = userId
            ShowNeutralSuccess(inputStr, NeutralNotice)

        Catch ex As Exception
            Logger.LogError("Forgot password error", ex)
            ' Even on unexpected error, show the neutral message to prevent error-based enumeration
            ShowNeutralSuccess(inputStr, NeutralNotice)
        End Try
    End Sub

    Private Sub ShowNeutralSuccess(ByVal inputStr As String, ByVal notice As String)
        Session("ResetIdentifier") = inputStr
        Session("ResetNotice") = notice
        lblMsg.Text = notice
        lblMsg.CssClass = "text-success-sm display-block text-center mb-3"
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "RedirectReset", "setTimeout(function() { window.location.href='reset_password.aspx'; }, 2000);", True)
    End Sub
End Class
