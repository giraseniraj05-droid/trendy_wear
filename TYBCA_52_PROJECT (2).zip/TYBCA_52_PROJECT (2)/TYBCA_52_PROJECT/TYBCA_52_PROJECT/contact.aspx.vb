Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports TYBCA_52_PROJECT.Helpers

Public Class contact
    Inherits System.Web.UI.Page

    Private Const ContactInbox As String = "giraseniraj05@gmail.com"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblMsg.Visible = False
        End If
    End Sub

    Protected Sub btnSend_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSend.Click
        If Not Page.IsValid Then Return

        Dim name As String = txtName.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim subject As String = txtSubject.Text.Trim()
        Dim message As String = txtMessage.Text.Trim()

        Try
            Dim query As String = "INSERT INTO ContactMessages (Name, Email, Subject, Message, CreatedOn) VALUES (@Name, @Email, @Subject, @Message, GETDATE())"
            Dim params As SqlParameter() = New SqlParameter() {
                Db.CreateParam("@Name", SqlDbType.NVarChar, name, 100),
                Db.CreateParam("@Email", SqlDbType.NVarChar, email, 255),
                Db.CreateParam("@Subject", SqlDbType.NVarChar, subject, 200),
                Db.CreateParam("@Message", SqlDbType.NVarChar, message, -1)
            }

            Db.ExecuteNonQuery(query, params)

            Dim safeName As String = HttpUtility.HtmlEncode(name)
            Dim safeSubject As String = HttpUtility.HtmlEncode(subject)
            Dim safeMessage As String = HttpUtility.HtmlEncode(message).Replace(vbCrLf, "<br/>").Replace(vbLf, "<br/>")
            Dim emailSent As Boolean = Mailer.SendEmail(ContactInbox, "New contact message",
                             Mailer.Wrap("New contact message",
                                         "<p><strong>Name:</strong> " & safeName & "</p><p><strong>Email:</strong> " & HttpUtility.HtmlEncode(email) & "</p><p><strong>Subject:</strong> " & safeSubject & "</p><p>" & safeMessage & "</p>"),
                             "ContactForm", True)

            If emailSent Then
                lblMsg.Text = "Thank you! Your message was sent to our team."
                lblMsg.CssClass = "alert alert-success d-block mb-3"
            Else
                lblMsg.Text = "Your message was saved, but email delivery failed. Please contact giraseniraj05@gmail.com or call 6352092774."
                lblMsg.CssClass = "alert alert-warning d-block mb-3"
            End If
            lblMsg.Visible = True

            txtName.Text = ""
            txtEmail.Text = ""
            txtSubject.Text = ""
            txtMessage.Text = ""

        Catch ex As Exception
            Logger.LogException(ex, "Contact Us form error")
            lblMsg.Text = "Failed to send message. Please try again later."
            lblMsg.CssClass = "alert alert-danger d-block mb-3"
            lblMsg.Visible = True
        End Try
    End Sub
End Class
