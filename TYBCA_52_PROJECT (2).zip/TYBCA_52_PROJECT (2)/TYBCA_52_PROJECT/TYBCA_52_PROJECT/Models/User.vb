Namespace Models
    Public Class User
        Public Property UserID As Integer
        Public Property Username As String
        Public Property Email As String
        Public Property MobileNo As String
        Public Property FullName As String
        Public Property Address As String
        Public Property City As String
        Public Property Pincode As String
        Public Property Role As String
        Public Property IsActive As Boolean
        Public Property CreatedOn As DateTime
    End Class
End Namespace
