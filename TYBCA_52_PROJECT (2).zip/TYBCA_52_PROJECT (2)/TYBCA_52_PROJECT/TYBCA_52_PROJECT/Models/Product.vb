Namespace Models
    Public Class Product
        Public Property ProductID As Integer
        Public Property ProductName As String
        Public Property Category As String
        Public Property CategoryID As Nullable(Of Integer)
        Public Property Size As String
        Public Property Price As Decimal
        Public Property OldPrice As Nullable(Of Decimal)
        Public Property Description As String
        Public Property ProductImage As String
        Public Property Stock As Integer
        Public Property IsActive As Boolean
        Public Property IsFeatured As Boolean
        Public Property Brand As String
        Public Property Color As String
        Public Property Rating As Double
    End Class
End Namespace
