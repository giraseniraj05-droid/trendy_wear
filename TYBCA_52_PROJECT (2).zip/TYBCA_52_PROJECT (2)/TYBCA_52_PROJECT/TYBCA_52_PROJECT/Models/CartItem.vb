Namespace Models
    Public Class CartItem
        Public Property ProductID As Integer
        Public Property ProductName As String
        Public Property Category As String
        Public Property Size As String
        Public Property Price As Decimal
        Public Property ProductImage As String
        Public Property Quantity As Integer

        Public ReadOnly Property TotalPrice As Decimal
            Get
                Return Price * Quantity
            End Get
        End Property
    End Class
End Namespace
