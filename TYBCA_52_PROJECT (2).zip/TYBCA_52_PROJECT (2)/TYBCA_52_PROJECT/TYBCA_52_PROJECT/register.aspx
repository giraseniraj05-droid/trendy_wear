<%@ Page Title="Sign Up - Create Account" Language="VB" MasterPageFile="~/navbar.Master" AutoEventWireup="false" CodeBehind="register.aspx.vb" Inherits="TYBCA_52_PROJECT.WebForm11" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="auth-container">
        <div class="fk-card auth-card">
            <!-- Left Banner -->
            <div class="auth-banner-col">
                <h2 class="auth-banner-title">Looks like you're new here!</h2>
                <p class="auth-banner-sub">Sign up with your mobile number to get started</p>
                <img src="<%= ResolveUrl("~/Images/default.jpg") %>" alt="Register Banner" class="auth-banner-img" />
            </div>

            <!-- Right Form -->
            <div class="auth-form-col">
                <div class="form-group mb-3">
                    <label class="form-label">Full Name / Username <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtUsername" runat="server" CssClass="fk-input" placeholder="Enter Full Name or Username"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvUsername" runat="server" ControlToValidate="txtUsername" ErrorMessage="Username is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Email Address <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtEmail" runat="server" CssClass="fk-input" placeholder="name@example.com" TextMode="Email"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                    <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ValidationExpression="^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$" ErrorMessage="Enter a valid email address" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">10-Digit Mobile Number <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtMobile" runat="server" CssClass="fk-input" placeholder="9876543210" MaxLength="10"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvMobile" runat="server" ControlToValidate="txtMobile" ErrorMessage="Mobile number is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                    <asp:RegularExpressionValidator ID="revMobile" runat="server" ControlToValidate="txtMobile" ValidationExpression="^[0-9]{10}$" ErrorMessage="Enter a 10-digit mobile number" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtPassword" runat="server" CssClass="fk-input" TextMode="Password" placeholder="Minimum 6 characters"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword" ErrorMessage="Password is required" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                    <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="fk-input" TextMode="Password" placeholder="Re-enter password"></asp:TextBox>
                    <asp:CompareValidator ID="cvPassword" runat="server" ControlToValidate="txtConfirmPassword" ControlToCompare="txtPassword" ErrorMessage="Passwords do not match" CssClass="text-danger-sm" Display="Dynamic" ValidationGroup="RegisterForm" />
                </div>

                <asp:Label ID="lblMsg" runat="server" CssClass="text-danger-sm display-block mb-3"></asp:Label>

                <asp:Button ID="btnRegister" runat="server" Text="CONTINUE &amp; CREATE ACCOUNT" CssClass="fk-btn fk-btn-buy width-100 p-3 text-base font-bold mb-3" ValidationGroup="RegisterForm" OnClick="btnRegister_Click" />

                <div class="text-center text-sm mt-3">
                    Existing User? <a href="<%= ResolveUrl("~/login.aspx") %>" class="fk-link font-bold">Log in to your account</a>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
