Imports System
Imports System.IO
Imports System.Web
Imports System.Text.RegularExpressions

Namespace Helpers
    Public Class Logger
        Public Shared Sub LogException(ByVal ex As Exception, Optional ByVal contextMessage As String = "")
            Try
                Dim logDir As String = If(HttpContext.Current IsNot Nothing, HttpContext.Current.Server.MapPath("~/App_Data/Logs/"), AppDomain.CurrentDomain.BaseDirectory & "\App_Data\Logs\")
                If Not Directory.Exists(logDir) Then
                    Directory.CreateDirectory(logDir)
                End If
                Dim logFile As String = Path.Combine(logDir, DateTime.Now.ToString("yyyy-MM-dd") & ".log")
                Dim safeContext As String = SanitizeForLog(contextMessage)
                Dim safeError As String = SanitizeForLog(ex.Message)
                Dim safeStack As String = SanitizeForLog(ex.StackTrace)
                Dim msg As String = String.Format("[{0:HH:mm:ss}] {1} Error: {2}{3}Stack Trace: {4}{5}",
                                                  DateTime.Now,
                                                  safeContext,
                                                  safeError,
                                                  Environment.NewLine,
                                                  safeStack,
                                                  Environment.NewLine & New String("-"c, 50) & Environment.NewLine)
                File.AppendAllText(logFile, msg)
            Catch
            End Try
        End Sub

        Public Shared Sub LogError(ByVal contextMessage As String, ByVal ex As Exception)
            LogException(ex, contextMessage)
        End Sub

        Public Shared Function SanitizeForLog(ByVal value As String) As String
            If String.IsNullOrEmpty(value) Then Return value
            Return Regex.Replace(value, "(?i)(password|passwd|pwd|token|verification[_ -]?code|reset[_ -]?code|\botp\b|\bcode\b|secret)(\s*[:=]\s*)[^\s&,;]+", "$1$2[REDACTED]")
        End Function
    End Class
End Namespace
