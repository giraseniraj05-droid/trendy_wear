Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Text
Imports System.Web

Namespace Helpers
    Public Class Db
        Public Shared Function GetConnectionString() As String
            Dim dockerConnectionString As String = Environment.GetEnvironmentVariable("TRENDYWEAR_DB_CONNECTION")
            If Not String.IsNullOrWhiteSpace(dockerConnectionString) Then
                Return dockerConnectionString
            End If

            ' On shared IIS hosting, keep the provider connection string in the
            ' private appSettings file (secrets.config) instead of committing it.
            Dim hostedConnectionString As String = ConfigurationManager.AppSettings("TrendyWearDbConnection")
            If Not String.IsNullOrWhiteSpace(hostedConnectionString) Then
                Return hostedConnectionString
            End If

            Dim connStr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
            Dim context As HttpContext = HttpContext.Current
            If context IsNot Nothing AndAlso Not context.Request.IsLocal AndAlso
               connStr.IndexOf("(LocalDB)", StringComparison.OrdinalIgnoreCase) >= 0 Then
                Throw New ConfigurationErrorsException("The hosted site is using a local-only database. Add the Somee SQL connection string as TrendyWearDbConnection in secrets.config.")
            End If
            Return connStr
        End Function

        Public Shared Function GetConnection() As SqlConnection
            Dim conn As New SqlConnection(GetConnectionString())
            conn.Open()
            Return conn
        End Function

        Public Shared Function ExecuteNonQuery(ByVal query As String, ParamArray parameters As SqlParameter()) As Integer
            Using conn As SqlConnection = GetConnection()
                Using cmd As New SqlCommand(query, conn)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        cmd.Parameters.AddRange(parameters)
                    End If
                    Return cmd.ExecuteNonQuery()
                End Using
            End Using
        End Function

        Public Shared Function ExecuteScalar(ByVal query As String, ParamArray parameters As SqlParameter()) As Object
            Using conn As SqlConnection = GetConnection()
                Using cmd As New SqlCommand(query, conn)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        cmd.Parameters.AddRange(parameters)
                    End If
                    Return cmd.ExecuteScalar()
                End Using
            End Using
        End Function

        Public Shared Function GetDataTable(ByVal query As String, ParamArray parameters As SqlParameter()) As DataTable
            Using conn As SqlConnection = GetConnection()
                Using cmd As New SqlCommand(query, conn)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        cmd.Parameters.AddRange(parameters)
                    End If
                    Dim dt As New DataTable()
                    Using da As New SqlDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                    Return dt
                End Using
            End Using
        End Function

        Public Shared Function ExecuteQuery(ByVal query As String, ParamArray parameters As SqlParameter()) As DataTable
            Return GetDataTable(query, parameters)
        End Function

        Public Shared Function CreateParam(ByVal name As String, ByVal dbType As SqlDbType, ByVal value As Object, Optional ByVal size As Integer = 0) As SqlParameter
            Dim param As New SqlParameter(name, dbType)
            If size > 0 Then
                param.Size = size
            End If
            param.Value = If(value IsNot Nothing, value, DBNull.Value)
            Return param
        End Function

        Public Shared Sub EnsureSchema()
            Try
                Dim queries As String() = New String() {
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Role') ALTER TABLE [dbo].[register] ADD [Role] NVARCHAR(20) NOT NULL DEFAULT 'User';",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'PasswordHash') ALTER TABLE [dbo].[register] ADD [PasswordHash] NVARCHAR(255) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Salt') ALTER TABLE [dbo].[register] ADD [Salt] NVARCHAR(255) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'FullName') ALTER TABLE [dbo].[register] ADD [FullName] NVARCHAR(100) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Address') ALTER TABLE [dbo].[register] ADD [Address] NVARCHAR(255) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'City') ALTER TABLE [dbo].[register] ADD [City] NVARCHAR(100) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'Pincode') ALTER TABLE [dbo].[register] ADD [Pincode] NVARCHAR(10) NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'CreatedOn') ALTER TABLE [dbo].[register] ADD [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE();",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'IsActive') ALTER TABLE [dbo].[register] ADD [IsActive] BIT NOT NULL DEFAULT 1;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'EmailVerified') ALTER TABLE [dbo].[register] ADD [EmailVerified] BIT NOT NULL CONSTRAINT [DF_register_EmailVerified] DEFAULT 1;",
                    "IF OBJECT_ID(N'[dbo].[CustomerAddresses]', N'U') IS NULL CREATE TABLE [dbo].[CustomerAddresses] ([AddressID] INT IDENTITY(1,1) PRIMARY KEY, [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register]([UserID]) ON DELETE CASCADE, [FullName] NVARCHAR(100) NOT NULL, [Mobile] NVARCHAR(15) NOT NULL, [AddressLine] NVARCHAR(255) NOT NULL, [City] NVARCHAR(100) NOT NULL, [Pincode] NVARCHAR(10) NOT NULL, [IsDefault] BIT NOT NULL DEFAULT 0, [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE());",
                    "IF OBJECT_ID(N'[dbo].[OrderReturnRequests]', N'U') IS NULL CREATE TABLE [dbo].[OrderReturnRequests] ([ReturnRequestID] INT IDENTITY(1,1) PRIMARY KEY, [OrderID] INT NOT NULL UNIQUE FOREIGN KEY REFERENCES [dbo].[orders]([OrderID]), [UserID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[register]([UserID]), [Reason] NVARCHAR(1000) NOT NULL, [RequestStatus] NVARCHAR(20) NOT NULL DEFAULT 'Pending', [AdminNotes] NVARCHAR(1000) NULL, [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE(), [UpdatedAt] DATETIME NULL);",
                    "IF OBJECT_ID(N'[dbo].[StockAlerts]', N'U') IS NULL CREATE TABLE [dbo].[StockAlerts] ([StockAlertID] INT IDENTITY(1,1) PRIMARY KEY, [ProductID] INT NOT NULL FOREIGN KEY REFERENCES [dbo].[addproduct1]([ProductID]) ON DELETE CASCADE, [Email] NVARCHAR(255) NOT NULL, [IsNotified] BIT NOT NULL DEFAULT 0, [CreatedAt] DATETIME NOT NULL DEFAULT GETDATE(), CONSTRAINT [UQ_StockAlerts_ProductEmail] UNIQUE ([ProductID], [Email]));",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'FailedAttempts') ALTER TABLE [dbo].[register] ADD [FailedAttempts] INT NOT NULL DEFAULT 0;",
                    "IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[register]') AND name = N'LockoutEnd') ALTER TABLE [dbo].[register] ADD [LockoutEnd] DATETIME NULL;",
                    "IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Add_Product') CREATE TABLE [dbo].[Add_Product] ([p_id] INT IDENTITY(1,1) PRIMARY KEY, [p_name] NVARCHAR(255) NOT NULL, [category_name] NVARCHAR(100) NOT NULL, [price] DECIMAL(10,2) NOT NULL, [OldPrice] DECIMAL(10,2) NULL, [Stock] INT NOT NULL DEFAULT 50, [details] NVARCHAR(MAX) NULL, [Image] NVARCHAR(255) NULL, [IsActive] BIT NOT NULL DEFAULT 1);",
                    "IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'order_details') CREATE TABLE [dbo].[order_details] ([order_id] INT IDENTITY(1,1) PRIMARY KEY, [u_name] NVARCHAR(100) NOT NULL, [mobile] NVARCHAR(20) NULL, [address] NVARCHAR(255) NULL, [city] NVARCHAR(100) NULL, [pincode] NVARCHAR(10) NULL, [p_name] NVARCHAR(255) NOT NULL, [qty] INT NOT NULL DEFAULT 1, [total_price] DECIMAL(10,2) NOT NULL, [order_date] DATETIME NOT NULL DEFAULT GETDATE(), [status] NVARCHAR(50) NOT NULL DEFAULT 'Pending');",
                    "IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'feedback') CREATE TABLE [dbo].[feedback] ([f_id] INT IDENTITY(1,1) PRIMARY KEY, [u_name] NVARCHAR(100) NOT NULL, [email] NVARCHAR(255) NULL, [rating] INT NOT NULL DEFAULT 5, [message] NVARCHAR(MAX) NOT NULL, [created_at] DATETIME NOT NULL DEFAULT GETDATE());",
                    "IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'SiteSettings') CREATE TABLE [dbo].[SiteSettings] ([SettingKey] NVARCHAR(100) PRIMARY KEY, [SettingValue] NVARCHAR(MAX) NOT NULL, [UpdatedOn] DATETIME NOT NULL DEFAULT GETDATE());",
                    "IF EXISTS (SELECT 1 FROM register WHERE Username = 'admin' AND Password = 'admin123' AND PasswordHash = 'tY9x3A2Y4mZk7nQ8pL5rU2wX9vB3cM1dE6fG8hI0jK4=' AND Salt = 'c2FsdF90cmVuZHl3ZWFy') UPDATE register SET Password = '', PasswordHash = 'x9xJmL4P1lw/PEH65SIXzTnQ4P6SYFF637y0TM5JbYw=' WHERE Username = 'admin' AND Password = 'admin123' AND PasswordHash = 'tY9x3A2Y4mZk7nQ8pL5rU2wX9vB3cM1dE6fG8hI0jK4=';",
                    "IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[PasswordResets]') AND name = N'Attempts') ALTER TABLE [dbo].[PasswordResets] ADD [Attempts] INT NOT NULL CONSTRAINT [DF_PasswordResets_Attempts] DEFAULT 0;",
                    "IF NOT EXISTS (SELECT 1 FROM register WHERE Role = 'Admin' OR Username = 'admin') INSERT INTO register (Username, Password, Email, Mobileno, Role, PasswordHash, Salt, IsActive, CreatedOn) VALUES ('admin', '', 'admin@trendywear.com', '9876543210', 'Admin', 'x9xJmL4P1lw/PEH65SIXzTnQ4P6SYFF637y0TM5JbYw=', 'c2FsdF90cmVuZHl3ZWFy', 1, GETDATE());",
                    "IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'ReviewImage') ALTER TABLE [dbo].[Reviews] ADD [ReviewImage] NVARCHAR(255) NULL;",
                    "IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'HelpfulCount') ALTER TABLE [dbo].[Reviews] ADD [HelpfulCount] INT NOT NULL CONSTRAINT [DF_Reviews_HelpfulCount] DEFAULT 0;",
                    "IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'AdminReply') ALTER TABLE [dbo].[Reviews] ADD [AdminReply] NVARCHAR(MAX) NULL;",
                    "IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'[dbo].[Reviews]') AND name=N'ReplyOn') ALTER TABLE [dbo].[Reviews] ADD [ReplyOn] DATETIME NULL;",
                    "IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name=N'ReviewHelpful') CREATE TABLE [dbo].[ReviewHelpful] ([HelpfulID] INT IDENTITY(1,1) PRIMARY KEY, [ReviewID] INT NOT NULL REFERENCES [dbo].[Reviews](ReviewID) ON DELETE CASCADE, [UserID] INT NOT NULL REFERENCES [dbo].[register](UserID), [CreatedOn] DATETIME NOT NULL DEFAULT GETDATE(), CONSTRAINT [UQ_ReviewHelpful_UserReview] UNIQUE (ReviewID, UserID));"
                }

                ' Keep the compatibility checks, but send them as one SQL batch
                ' over one connection. Opening a fresh remote SQL connection for
                ' every check made hosted application startup unnecessarily slow.
                Dim schemaBatch As New StringBuilder()
                For Each q In queries
                    schemaBatch.Append("BEGIN TRY ").Append(q).Append(" END TRY BEGIN CATCH END CATCH;")
                Next

                Using conn As SqlConnection = GetConnection()
                    Using cmd As New SqlCommand(schemaBatch.ToString(), conn)
                        cmd.CommandTimeout = 60
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                Logger.LogException(ex, "EnsureSchema Error")
            End Try
        End Sub
    End Class
End Namespace
