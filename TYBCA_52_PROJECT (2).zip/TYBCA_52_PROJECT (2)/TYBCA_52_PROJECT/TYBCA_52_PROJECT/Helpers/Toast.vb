Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace Helpers
    Public Enum ToastType
        Success
        [Error]
        ErrorType
        Warning
        Info
    End Enum

    Public Class Toast
        Public Enum ToastType
            Success
            [Error]
            ErrorType
            Warning
            Info
        End Enum

        Public Shared Sub Show(ByVal page As Page, ByVal message As String, Optional ByVal type As Helpers.ToastType = Helpers.ToastType.Success)
            ShowMessage(page, message, type)
        End Sub

        Public Shared Sub ShowMessage(ByVal page As Page, ByVal message As String, ByVal type As Helpers.ToastType, Optional ByVal labelControl As Label = Nothing)
            Dim safeMessage As String = HttpUtility.JavaScriptStringEncode(message)
            If labelControl IsNot Nothing Then
                labelControl.Text = HttpUtility.HtmlEncode(message)
                Select Case type
                    Case Helpers.ToastType.Success
                        labelControl.CssClass = "alert alert-success"
                    Case Helpers.ToastType.Error, Helpers.ToastType.ErrorType
                        labelControl.CssClass = "alert alert-danger"
                    Case Helpers.ToastType.Warning
                        labelControl.CssClass = "alert alert-warning"
                    Case Helpers.ToastType.Info
                        labelControl.CssClass = "alert alert-info"
                End Select
                labelControl.Visible = True
            Else
                Dim scriptKey As String = "ToastScript_" & Guid.NewGuid().ToString("N")
                Dim typeStr As String = type.ToString().ToLower()
                If type = Helpers.ToastType.ErrorType Then typeStr = "error"
                Dim script As String = String.Format("if(window.showToast){{ showToast('{0}','{1}'); }} else {{ console.log('{0}'); }}", safeMessage, typeStr)
                ScriptManager.RegisterStartupScript(page, page.GetType(), scriptKey, script, True)
            End If
        End Sub
    End Class
End Namespace
