Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net
Imports System.Net.Mail
Imports System.Text
Imports System.Web

Namespace Helpers
    Public Class Mailer
        Public Shared Function SendEmail(ByVal toEmail As String, ByVal subject As String, ByVal body As String, Optional ByVal isHtml As Boolean = True) As Boolean
            Return SendEmail(toEmail, subject, body, "General", isHtml)
        End Function

        Public Shared Function SendEmail(ByVal toEmail As String, ByVal subject As String, ByVal body As String, ByVal emailType As String, Optional ByVal isHtml As Boolean = True) As Boolean
            Dim success As Boolean = False
            Dim errorMessage As String = Nothing
            Try
                Dim host As String = ConfigurationManager.AppSettings("SmtpHost")
                Dim portStr As String = ConfigurationManager.AppSettings("SmtpPort")
                Dim port As Integer
                If String.IsNullOrWhiteSpace(host) OrElse Not Integer.TryParse(portStr, port) Then
                    Throw New ConfigurationErrorsException("SMTP host and port must be configured in Web.config.")
                End If

                Dim fromEmail As String = ConfigurationManager.AppSettings("SmtpFrom")
                If String.IsNullOrWhiteSpace(fromEmail) Then
                    Throw New ConfigurationErrorsException("SMTP sender must be configured in Web.config.")
                End If

                Dim username As String = ConfigurationManager.AppSettings("SmtpUsername")
                Dim password As String = ConfigurationManager.AppSettings("SmtpPassword")
                If String.IsNullOrWhiteSpace(username) OrElse String.IsNullOrWhiteSpace(password) Then
                    Throw New ConfigurationErrorsException("SMTP username and Gmail App Password must be configured in secrets.config.")
                End If
                password = password.Replace(" ", "").Replace(vbTab, "").Replace(vbCr, "").Replace(vbLf, "")
                If password.Length <> 16 Then
                    Throw New ConfigurationErrorsException("Gmail App Password in secrets.config must contain all 16 characters. Spaces are optional.")
                End If

                Using mail As New MailMessage()
                    mail.From = New MailAddress(fromEmail, "Trendy Wear Store")
                    mail.To.Add(toEmail)
                    mail.Subject = subject
                    mail.Body = body
                    mail.IsBodyHtml = isHtml

                    Using client As New SmtpClient(host, port)
                        client.EnableSsl = True
                        client.UseDefaultCredentials = False
                        client.Credentials = New NetworkCredential(username, password)
                        client.Timeout = 15000
                        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol Or CType(3072, SecurityProtocolType)
                        client.Send(mail)
                        success = True
                    End Using
                End Using
            Catch ex As Exception
                errorMessage = GetErrorDetails(ex)
                Logger.LogException(ex, "SendEmail to " & toEmail)
            Finally
                LogEmailResult(toEmail, subject, emailType, success, errorMessage)
            End Try
            Return success
        End Function

        Private Shared Function GetErrorDetails(ByVal ex As Exception) As String
            Dim details As New StringBuilder()
            Dim current As Exception = ex
            While current IsNot Nothing
                If details.Length > 0 Then details.Append(" | ")
                details.Append(current.GetType().Name).Append(": ").Append(current.Message)
                Dim smtpError As SmtpException = TryCast(current, SmtpException)
                If smtpError IsNot Nothing Then
                    details.Append(" (SMTP status ").Append(smtpError.StatusCode.ToString()).Append(")")
                End If
                current = current.InnerException
            End While
            Return details.ToString()
        End Function

        Private Shared Sub LogEmailResult(ByVal toEmail As String, ByVal subject As String, ByVal emailType As String, ByVal success As Boolean, ByVal errorMessage As String)
            Try
                Dim errorParam As New SqlParameter("@Error", SqlDbType.NVarChar, -1)
                errorParam.Value = If(String.IsNullOrEmpty(errorMessage), CType(DBNull.Value, Object), Logger.SanitizeForLog(errorMessage))
                Db.ExecuteNonQuery("INSERT INTO EmailLog (ToEmail, Subject, Type, Success, [Error], CreatedOn) VALUES (@ToEmail, @Subject, @Type, @Success, @Error, GETDATE())",
                                   Db.CreateParam("@ToEmail", SqlDbType.NVarChar, toEmail, 255),
                                   Db.CreateParam("@Subject", SqlDbType.NVarChar, subject, 255),
                                   Db.CreateParam("@Type", SqlDbType.NVarChar, emailType, 100),
                                   Db.CreateParam("@Success", SqlDbType.Bit, success),
                                   errorParam)
            Catch ex As Exception
                Logger.LogException(ex, "Log email result for " & toEmail)
            End Try
        End Sub

        Public Shared Function Wrap(ByVal title As String, ByVal bodyHtml As String) As String
            Dim safeTitle As String = HttpUtility.HtmlEncode(title)
            Dim html As New StringBuilder()
            html.Append("<!doctype html><html><body style='margin:0;background:#f4f6f8;font-family:Arial,sans-serif;color:#253044;padding:24px;'>")
            html.Append("<div style='max-width:620px;margin:0 auto;background:#fff;border:1px solid #e5e9ef;border-radius:12px;overflow:hidden;'>")
            html.Append("<div style='background:#253044;color:#fff;padding:22px 28px;font-size:22px;font-weight:bold;'>Trendy Wear</div>")
            html.Append("<div style='padding:28px;'><h1 style='font-size:22px;margin:0 0 18px;'>" & safeTitle & "</h1>")
            html.Append(bodyHtml)
            html.Append("</div><div style='border-top:1px solid #e5e9ef;padding:18px 28px;color:#687386;font-size:13px;'>")
            html.Append("Trendy Wear &middot; <a href='mailto:giraseniraj05@gmail.com'>giraseniraj05@gmail.com</a> &middot; <a href='tel:6352092774'>6352092774</a>")
            html.Append("</div></div></body></html>")
            Return html.ToString()
        End Function

        Public Shared Sub SendAsync(ByVal toEmail As String, ByVal subject As String, ByVal html As String, Optional ByVal emailType As String = "General")
            If String.IsNullOrWhiteSpace(toEmail) Then Return
            Dim normalizedEmail As String = toEmail.Trim()
            Try
                Dim address As New MailAddress(normalizedEmail)
                If Not String.Equals(address.Address, normalizedEmail, StringComparison.OrdinalIgnoreCase) Then Return
            Catch
                Return
            End Try

            ' Finish the SMTP operation inside the ASP.NET request. Fire-and-forget
            ' ThreadPool work can be dropped when shared IIS hosting recycles the
            ' application, which made verification and order emails unreliable.
            SendEmail(normalizedEmail, subject, html, emailType, True)
        End Sub

        Public Shared Function SendTestEmail(ByVal toEmail As String) As Boolean
            Dim body As String = Wrap("Test email",
                                      "<p>This test message confirms that Trendy Wear can send email using the current SMTP settings.</p>")
            Return SendEmail(toEmail, "Trendy Wear email test", body, "Test", True)
        End Function

        Public Shared Function SendMail(ByVal toEmail As String, ByVal subject As String, ByVal body As String) As Boolean
            Return SendEmail(toEmail, subject, body, True)
        End Function
    End Class
End Namespace
