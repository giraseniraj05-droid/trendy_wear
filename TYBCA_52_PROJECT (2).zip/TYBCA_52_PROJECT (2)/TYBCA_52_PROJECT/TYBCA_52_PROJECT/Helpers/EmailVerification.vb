Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web

Namespace Helpers
    Public Class EmailVerification
        Public Shared Function SendVerificationEmail(ByVal userId As Integer, ByVal username As String, ByVal email As String) As Boolean
            Dim recentTokenCount As Integer = Convert.ToInt32(Db.ExecuteScalar(
                "SELECT COUNT(*) FROM EmailVerificationTokens WHERE UserID = @UserID AND CreatedAt >= DATEADD(second, -60, GETDATE())",
                Db.CreateParam("@UserID", SqlDbType.Int, userId)))
            If recentTokenCount > 0 Then Return False

            Dim code As String = Security.GenerateSixDigitCode()
            Dim codeHash As String = Security.HashPassword(code, Security.VerificationTokenSalt)
            Db.ExecuteNonQuery("BEGIN TRANSACTION; UPDATE EmailVerificationTokens SET IsUsed = 1 WHERE UserID = @UserID AND IsUsed = 0; " & _
                               "INSERT INTO EmailVerificationTokens (UserID, TokenHash, ExpiresAt, IsUsed, CreatedAt) VALUES (@UserID, @TokenHash, DATEADD(minute, 10, GETDATE()), 0, GETDATE()); COMMIT TRANSACTION;",
                               Db.CreateParam("@UserID", SqlDbType.Int, userId),
                               Db.CreateParam("@TokenHash", SqlDbType.NVarChar, codeHash, 255))

            Dim safeUsername As String = HttpUtility.HtmlEncode(username)
            Dim emailSent As Boolean = Mailer.SendEmail(email, "Your Trendy Wear verification code",
                             Mailer.Wrap("Verify your email address",
                                         "<p>Hello " & safeUsername & ",</p><p>Enter this code to verify your email address. It expires in 10 minutes.</p><p style='font-size:28px;font-weight:bold;letter-spacing:6px;'>" & code & "</p>"),
                             "EmailVerification", True)
            If Not emailSent Then
                Db.ExecuteNonQuery("UPDATE EmailVerificationTokens SET IsUsed = 1 WHERE UserID = @UserID AND TokenHash = @TokenHash AND IsUsed = 0",
                                   Db.CreateParam("@UserID", SqlDbType.Int, userId),
                                   Db.CreateParam("@TokenHash", SqlDbType.NVarChar, codeHash, 255))
                Throw New InvalidOperationException("The verification email could not be delivered.")
            End If
            Return True
        End Function

        Public Shared Function VerifyCode(ByVal userId As Integer, ByVal code As String) As Boolean
            If String.IsNullOrWhiteSpace(code) OrElse code.Length <> 6 OrElse Not System.Text.RegularExpressions.Regex.IsMatch(code, "^[0-9]{6}$") Then Return False
            Dim codeHash As String = Security.HashPassword(code, Security.VerificationTokenSalt)
            Using connection As SqlConnection = Db.GetConnection()
                Using transaction As SqlTransaction = connection.BeginTransaction()
                    Using tokenCommand As New SqlCommand("SELECT TOP 1 VerificationID FROM EmailVerificationTokens WHERE UserID = @UserID AND TokenHash = @TokenHash AND IsUsed = 0 AND ExpiresAt >= GETDATE() ORDER BY CreatedAt DESC", connection, transaction)
                        tokenCommand.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, userId))
                        tokenCommand.Parameters.Add(Db.CreateParam("@TokenHash", SqlDbType.NVarChar, codeHash, 255))
                        Dim verificationId As Object = tokenCommand.ExecuteScalar()
                        If verificationId Is Nothing Then
                            transaction.Rollback()
                            Return False
                        End If
                        Using userCommand As New SqlCommand("UPDATE register SET EmailVerified = 1 WHERE UserID = @UserID", connection, transaction)
                            userCommand.Parameters.Add(Db.CreateParam("@UserID", SqlDbType.Int, userId))
                            If userCommand.ExecuteNonQuery() <> 1 Then
                                transaction.Rollback()
                                Return False
                            End If
                        End Using
                        Using usedCommand As New SqlCommand("UPDATE EmailVerificationTokens SET IsUsed = 1 WHERE VerificationID = @VerificationID", connection, transaction)
                            usedCommand.Parameters.Add(Db.CreateParam("@VerificationID", SqlDbType.Int, Convert.ToInt32(verificationId)))
                            usedCommand.ExecuteNonQuery()
                        End Using
                        transaction.Commit()
                    End Using
                End Using
            End Using
            Return True
        End Function
    End Class
End Namespace
