Imports System
Imports System.Security.Cryptography
Imports System.Text

Namespace Helpers
    Public Class Security
        Private Const Iterations As Integer = 100000
        Private Const SaltSize As Integer = 16 ' 128 bits
        Private Const KeySize As Integer = 32  ' 256 bits
        Public Const ResetTokenSalt As String = "VHJlbmR5V2VhclJlc2V0U2FsdA=="
        Public Const VerificationTokenSalt As String = "VHJlbmR5V2VhckVtYWlsVmVyaWZ5U2FsdA=="

        Public Shared Function GenerateSalt() As String
            Dim saltBytes(SaltSize - 1) As Byte
            Using rng As RandomNumberGenerator = RandomNumberGenerator.Create()
                rng.GetBytes(saltBytes)
            End Using
            Return Convert.ToBase64String(saltBytes)
        End Function

        Public Shared Function HashPassword(ByVal password As String, ByVal saltBase64 As String) As String
            Dim saltBytes As Byte() = Convert.FromBase64String(saltBase64)
            Using pbkdf2 As New Rfc2898DeriveBytes(password, saltBytes, Iterations)
                Dim keyBytes As Byte() = pbkdf2.GetBytes(KeySize)
                Return Convert.ToBase64String(keyBytes)
            End Using
        End Function

        Public Shared Function VerifyPassword(ByVal password As String, ByVal storedHash As String, ByVal storedSalt As String) As Boolean
            If String.IsNullOrEmpty(storedHash) OrElse String.IsNullOrEmpty(storedSalt) Then
                Return False
            End If
            Dim computedHash As String = HashPassword(password, storedSalt)
            Return SlowEquals(computedHash, storedHash)
        End Function

        Public Shared Function GenerateRandomToken() As String
            Dim tokenBytes(31) As Byte
            Using rng As RandomNumberGenerator = RandomNumberGenerator.Create()
                rng.GetBytes(tokenBytes)
            End Using
            Return Convert.ToBase64String(tokenBytes).Replace("+", "").Replace("/", "").Replace("=", "")
        End Function

        Public Shared Function IsLocalReturnUrl(ByVal returnUrl As String) As Boolean
            If String.IsNullOrWhiteSpace(returnUrl) Then Return False
            If returnUrl.IndexOfAny(New Char() {ControlChars.Cr, ControlChars.Lf, ChrW(0)}) >= 0 OrElse returnUrl.IndexOf(ChrW(92)) >= 0 Then Return False
            Dim normalizedUrl As String = returnUrl.ToLowerInvariant()
            If normalizedUrl.Contains("%2f") OrElse normalizedUrl.Contains("%5c") OrElse normalizedUrl.Contains("%0d") OrElse normalizedUrl.Contains("%0a") Then Return False
            If returnUrl.StartsWith("~/", StringComparison.Ordinal) Then
                Return returnUrl.Length > 2 AndAlso returnUrl(2) <> "/"c AndAlso returnUrl(2) <> ChrW(92)
            End If
            If returnUrl.StartsWith("/", StringComparison.Ordinal) Then
                Return returnUrl.Length = 1 OrElse (returnUrl(1) <> "/"c AndAlso returnUrl(1) <> ChrW(92))
            End If
            Return False
        End Function

        Public Shared Function GenerateSixDigitCode() As String
            Dim codeChars(5) As Char
            Using rng As New RNGCryptoServiceProvider()
                Dim bytes(0) As Byte
                Dim i As Integer = 0
                While i < 6
                    rng.GetBytes(bytes)
                    Dim b As Byte = bytes(0)
                    ' 250 is evenly divisible by 10 (25 each), preventing modulo bias
                    If b < 250 Then
                        codeChars(i) = ChrW(AscW("0"c) + (b Mod 10))
                        i += 1
                    End If
                End While
            End Using
            Return New String(codeChars)
        End Function

        Public Shared Function HashResetCode(ByVal code As String) As String
            Return HashPassword(code, ResetTokenSalt)
        End Function

        Public Shared Function VerifyResetCode(ByVal code As String, ByVal storedHash As String) As Boolean
            If String.IsNullOrEmpty(code) OrElse String.IsNullOrEmpty(storedHash) Then
                Return False
            End If
            Dim computedHash As String = HashResetCode(code)
            Return SlowEquals(computedHash, storedHash)
        End Function

        Public Shared Function ValidatePasswordRules(ByVal password As String, ByRef errorMessage As String) As Boolean
            If String.IsNullOrWhiteSpace(password) Then
                errorMessage = "Password is required."
                Return False
            End If
            If password.Length < 6 Then
                errorMessage = "Password must be at least 6 characters long."
                Return False
            End If
            errorMessage = String.Empty
            Return True
        End Function

        Public Shared Function SlowEquals(ByVal a As String, ByVal b As String) As Boolean
            Dim diff As UInteger = CUInt(a.Length) Xor CUInt(b.Length)
            Dim i As Integer = 0
            While i < a.Length AndAlso i < b.Length
                diff = diff Or CUInt(AscW(a(i)) Xor AscW(b(i)))
                i += 1
            End While
            Return diff = 0
        End Function
    End Class
End Namespace
